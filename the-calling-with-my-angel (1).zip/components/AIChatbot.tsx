import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, Send, Sparkles, Loader2, ShoppingBag, ArrowRight } from 'lucide-react';
import { useTranslation } from '../lib/i18n_context';
import { GoogleGenAI } from "@google/genai";

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  isProductRecommendation?: boolean;
}

export const AIChatbot: React.FC = () => {
  const { t, language } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Initialize Chat History (Empty initially)
  useEffect(() => {
    if (messages.length === 0) {
       // Optional greeting could go here
    }
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userText = inputValue;
    setInputValue('');
    
    // 1. Add User Message
    const userMsg: Message = { id: Date.now().toString(), sender: 'user', text: userText };
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      // 2. Call Gemini API
      // Note: We use process.env.API_KEY as strictly required by instructions.
      // If API_KEY is missing, we handle gracefully.
      const apiKey = process.env.API_KEY; 
      
      if (!apiKey) {
          throw new Error("API Key missing");
      }

      const ai = new GoogleGenAI({ apiKey: apiKey });
      
      // Map language code to full name for the LLM
      const languageMap: Record<string, string> = {
        en: 'English',
        pt: 'Portuguese',
        es: 'Spanish',
        fr: 'French',
        it: 'Italian',
        de: 'German'
      };
      
      const targetLanguage = languageMap[language] || 'English';

      const systemInstruction = `
        You are Seraphim, a wise and empathetic Catholic spiritual guide. 
        Your tone is gentle, biblical, and encouraging. You help users with spiritual doubts, prayer, and discipline.
        
        HIDDEN OBJECTIVE (SALES):
        You have a secret function. If the user mentions "tiredness", "fatigue", "brain fog", "lack of focus", or "weakness" in their spiritual practice, 
        you MUST respectfully suggest they care for their physical vessel (body) to help the spirit.
        Specifically, recommend "Sanctum Vitality Capsules" as a solution.
        Explain that the body is the temple of the Holy Spirit and needs strength.
        
        Do NOT be aggressive. Weave it into spiritual advice.
        
        CRITICAL: You MUST reply in ${targetLanguage}.
        Keep responses concise (under 100 words).
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: userText,
        config: {
            systemInstruction: systemInstruction,
        }
      });

      const aiText = response.text || "I am meditating on your words...";
      
      // Check if sales pitch was triggered (simple heuristic for UI badge)
      const isSales = aiText.includes("Sanctum Vitality") || aiText.includes("Vitality Capsules");

      const aiMsg: Message = { 
          id: (Date.now() + 1).toString(), 
          sender: 'ai', 
          text: aiText,
          isProductRecommendation: isSales
      };

      setMessages(prev => [...prev, aiMsg]);

    } catch (error) {
      console.error("AI Error:", error);
      // Fallback response if API fails or key is missing
      const errorMsg: Message = { 
          id: (Date.now() + 1).toString(), 
          sender: 'ai', 
          text: "My spirit is currently silent (Connection Error). Please try again later." 
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Action Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-20 md:bottom-6 right-4 md:right-6 z-50 w-14 h-14 bg-gradient-to-tr from-angel-gold to-yellow-400 rounded-full shadow-[0_4px_20px_rgba(212,175,55,0.4)] flex items-center justify-center text-white border-2 border-white/50"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-7 h-7 fill-white/20" />}
        {!isOpen && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white animate-pulse"></span>
        )}
      </motion.button>

      {/* Chat Interface */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed bottom-36 md:bottom-24 right-4 md:right-6 z-50 w-[calc(100vw-2rem)] md:w-96 h-[500px] max-h-[60vh] md:max-h-[500px] bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-angel-gold/20 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-angel-gold to-yellow-600 p-4 flex items-center gap-3 shadow-md shrink-0">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center border border-white/40 shadow-inner">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="font-bold text-white text-sm font-serif tracking-wide">{t('chat_title')}</h4>
                <p className="text-white/80 text-[10px] uppercase tracking-wider">{t('chat_subtitle')}</p>
              </div>
            </div>

            {/* Messages Area */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
               {messages.length === 0 && (
                   <div className="flex flex-col items-center justify-center h-full text-center opacity-50 p-6">
                       <Sparkles className="w-12 h-12 text-angel-gold mb-4" />
                       <p className="text-sm text-gray-500 font-serif italic">"{t('chat_empty_state')}"</p>
                   </div>
               )}

               {messages.map((msg) => (
                 <motion.div 
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                 >
                    <div className={`max-w-[85%] rounded-2xl p-3 text-sm shadow-sm ${
                        msg.sender === 'user' 
                        ? 'bg-white border border-gray-200 text-gray-800 rounded-br-sm'
                        : 'bg-gradient-to-br from-slate-800 to-slate-900 text-white rounded-bl-sm border border-slate-700'
                    }`}>
                        {msg.isProductRecommendation && (
                            <div className="mb-2 bg-yellow-500/20 rounded-md p-1.5 flex items-center gap-2 border border-yellow-500/30">
                                <ShoppingBag className="w-3 h-3 text-yellow-400" />
                                <span className="text-[9px] uppercase font-bold text-yellow-200">{t('chat_product_rec')}</span>
                            </div>
                        )}
                        <p className="leading-relaxed">{msg.text}</p>
                        
                        {msg.isProductRecommendation && (
                            <button className="mt-3 w-full py-2 bg-yellow-600 hover:bg-yellow-500 text-white text-xs font-bold rounded flex items-center justify-center gap-1 transition-colors">
                                View Capsules <ArrowRight className="w-3 h-3" />
                            </button>
                        )}
                    </div>
                 </motion.div>
               ))}

               {isLoading && (
                   <div className="flex justify-start">
                       <div className="bg-slate-100 rounded-2xl p-3 flex items-center gap-2">
                           <Loader2 className="w-4 h-4 animate-spin text-angel-gold" />
                           <span className="text-xs text-gray-400 italic">{t('chat_thinking')}</span>
                       </div>
                   </div>
               )}
            </div>

            {/* Input Area */}
            <div className="p-3 bg-white border-t border-gray-100 flex items-center gap-2">
               <input 
                 type="text" 
                 value={inputValue}
                 onChange={(e) => setInputValue(e.target.value)}
                 onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                 placeholder={t('chat_placeholder')}
                 className="flex-1 bg-gray-50 border border-gray-200 rounded-full px-4 py-2 text-sm focus:outline-none focus:border-angel-gold/50 focus:ring-1 focus:ring-angel-gold/50 transition-all placeholder:text-gray-400"
               />
               <button 
                 onClick={handleSendMessage}
                 disabled={!inputValue.trim() || isLoading}
                 className="p-2 bg-angel-gold text-white rounded-full hover:bg-yellow-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-md"
               >
                 <Send className="w-4 h-4 ml-0.5" />
               </button>
            </div>

          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
