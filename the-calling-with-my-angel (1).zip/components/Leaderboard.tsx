
import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { motion, AnimatePresence } from 'framer-motion';
import { Crown, ChevronDown, ChevronUp, User } from 'lucide-react';
import { useTranslation } from '../lib/i18n_context';
import { getRank } from '../lib/gamification';

interface IntercessorRank {
  intercessor_id: string;
  name: string;
  avatar_url: string | null;
  count: number;
}

export const Leaderboard: React.FC = () => {
  const { t } = useTranslation();
  const [rankings, setRankings] = useState<IntercessorRank[]>([]);
  const [isOpen, setIsOpen] = useState(true); // For mobile accordion

  useEffect(() => {
    fetchLeaderboard();
  }, []);

  const fetchLeaderboard = async () => {
    try {
      // Try to call the RPC function
      const { data, error } = await supabase.rpc('get_top_intercessors', { limit_count: 10 });

      if (error) {
        // Fallback Mock Data
        setRankings([
            { intercessor_id: '1', name: 'Gabriel S.', avatar_url: null, count: 142 },
            { intercessor_id: '2', name: 'Maria C.', avatar_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100', count: 98 },
            { intercessor_id: '3', name: 'John D.', avatar_url: null, count: 87 },
            { intercessor_id: '4', name: 'Sarah L.', avatar_url: null, count: 65 },
            { intercessor_id: '5', name: 'Peter K.', avatar_url: null, count: 42 },
        ]);
      } else {
        setRankings(data || []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const TopThree = rankings.slice(0, 3);
  const RunnersUp = rankings.slice(3);

  return (
    <div className="bg-white/60 backdrop-blur-md rounded-2xl border border-white shadow-lg overflow-hidden flex flex-col">
      {/* Header (Accordion Toggle on Mobile) */}
      <div 
        className="p-5 bg-gradient-to-r from-gray-50 to-white border-b border-gray-100 flex items-center justify-between cursor-pointer md:cursor-default shrink-0"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-yellow-100 rounded-lg">
             <Crown className="w-5 h-5 text-yellow-600" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-gray-900">{t('comm_guardians')}</h3>
            <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">{t('comm_top_intercessors')}</p>
          </div>
        </div>
        <div className="md:hidden text-gray-400">
           {isOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </div>
      </div>

      <AnimatePresence initial={false}>
        {(isOpen || window.innerWidth >= 768) && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="p-6 pb-8"> {/* Added extra bottom padding to fix visual cut-off */}
              
              {/* TOP 3 PODIUM */}
              <div className="flex justify-center items-end gap-4 mb-8 h-40">
                {/* 2nd Place */}
                {TopThree[1] && (
                  <div className="flex flex-col items-center">
                    <div className="w-14 h-14 rounded-full border-2 border-gray-300 shadow-lg p-0.5 relative mb-2">
                       <img 
                          src={TopThree[1].avatar_url || `https://ui-avatars.com/api/?name=${TopThree[1].name}&background=e5e7eb`} 
                          className="w-full h-full rounded-full object-cover" 
                          alt="2nd"
                       />
                       <div className="absolute -bottom-2 -right-1 w-6 h-6 bg-gray-300 rounded-full flex items-center justify-center text-xs font-bold text-white border-2 border-white shadow-sm">2</div>
                    </div>
                    
                    {/* Name + Medal */}
                    <div className="flex items-center gap-1">
                        <span className="text-xs font-bold text-gray-600 truncate max-w-[80px]">{TopThree[1].name}</span>
                        {(() => {
                            const { rank } = getRank(TopThree[1].count);
                            return (
                                <div className={`w-3 h-3 rounded-full ${rank.bg} flex items-center justify-center shrink-0`}>
                                    <rank.icon className={`w-2 h-2 ${rank.color}`} />
                                </div>
                            );
                        })()}
                    </div>

                    <span className="text-[10px] font-bold text-angel-gold">{TopThree[1].count}</span>
                    <div className="w-12 h-16 bg-gray-100 rounded-t-lg mt-2 opacity-50"></div>
                  </div>
                )}

                {/* 1st Place */}
                {TopThree[0] && (
                  <div className="flex flex-col items-center z-10">
                    <Crown className="w-6 h-6 text-yellow-500 mb-1 animate-bounce" style={{ animationDuration: '3s' }} />
                    <div className="w-20 h-20 rounded-full border-4 border-yellow-400 shadow-gold-glow p-1 relative mb-2 bg-white">
                       <img 
                          src={TopThree[0].avatar_url || `https://ui-avatars.com/api/?name=${TopThree[0].name}&background=fcd34d`} 
                          className="w-full h-full rounded-full object-cover" 
                          alt="1st"
                       />
                       <div className="absolute -bottom-2 -right-1 w-7 h-7 bg-yellow-400 rounded-full flex items-center justify-center text-sm font-bold text-white border-2 border-white shadow-sm">1</div>
                    </div>
                    
                    {/* Name + Medal */}
                    <div className="flex items-center gap-1">
                        <span className="text-sm font-bold text-gray-800 truncate max-w-[100px]">{TopThree[0].name}</span>
                        {(() => {
                            const { rank } = getRank(TopThree[0].count);
                            return (
                                <div className={`w-4 h-4 rounded-full ${rank.bg} flex items-center justify-center shrink-0`}>
                                    <rank.icon className={`w-2.5 h-2.5 ${rank.color}`} />
                                </div>
                            );
                        })()}
                    </div>

                    <span className="text-xs font-bold text-angel-gold">{TopThree[0].count}</span>
                    <div className="w-16 h-24 bg-gradient-to-t from-yellow-50 to-white border-x border-t border-yellow-100 rounded-t-lg mt-2"></div>
                  </div>
                )}

                {/* 3rd Place */}
                {TopThree[2] && (
                  <div className="flex flex-col items-center">
                    <div className="w-14 h-14 rounded-full border-2 border-orange-300 shadow-lg p-0.5 relative mb-2">
                       <img 
                          src={TopThree[2].avatar_url || `https://ui-avatars.com/api/?name=${TopThree[2].name}&background=fed7aa`} 
                          className="w-full h-full rounded-full object-cover" 
                          alt="3rd"
                       />
                       <div className="absolute -bottom-2 -right-1 w-6 h-6 bg-orange-300 rounded-full flex items-center justify-center text-xs font-bold text-white border-2 border-white shadow-sm">3</div>
                    </div>
                    
                    {/* Name + Medal */}
                    <div className="flex items-center gap-1">
                        <span className="text-xs font-bold text-gray-600 truncate max-w-[80px]">{TopThree[2].name}</span>
                        {(() => {
                            const { rank } = getRank(TopThree[2].count);
                            return (
                                <div className={`w-3 h-3 rounded-full ${rank.bg} flex items-center justify-center shrink-0`}>
                                    <rank.icon className={`w-2 h-2 ${rank.color}`} />
                                </div>
                            );
                        })()}
                    </div>

                    <span className="text-[10px] font-bold text-angel-gold">{TopThree[2].count}</span>
                    <div className="w-12 h-12 bg-orange-50 rounded-t-lg mt-2 opacity-50"></div>
                  </div>
                )}
              </div>

              {/* LIST VIEW (4-10) */}
              <div className="space-y-3">
                {RunnersUp.map((user, index) => {
                  const { rank } = getRank(user.count);
                  return (
                    <div key={user.intercessor_id} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg transition-colors group">
                      <div className="flex items-center gap-3">
                        <span className="w-5 text-center text-xs font-bold text-gray-400">#{index + 4}</span>
                        <div className="w-8 h-8 rounded-full bg-gray-200 overflow-hidden">
                          {user.avatar_url ? (
                            <img src={user.avatar_url} className="w-full h-full object-cover" />
                          ) : (
                            <User className="w-full h-full p-1.5 text-gray-400" />
                          )}
                        </div>
                        <span className="text-sm font-medium text-gray-700">{user.name}</span>
                        <div className={`w-4 h-4 rounded-full ${rank.bg} flex items-center justify-center`}>
                            <rank.icon className={`w-2.5 h-2.5 ${rank.color}`} />
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                          <span className="text-xs font-bold text-gray-400 bg-gray-100 px-2 py-1 rounded-full">{user.count}</span>
                      </div>
                    </div>
                  );
                })}
                
                {RunnersUp.length === 0 && (
                   <p className="text-center text-xs text-gray-400 py-4 italic">{t('comm_be_first')}</p>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
