import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from '../lib/i18n_context';
import { LanguageCode } from '../types';
import { ChevronDown } from 'lucide-react';

interface LanguageOption {
  code: LanguageCode;
  label: string;
  flag: string;
}

export const LanguageSwitcher: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { language, setLanguage } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const languages: LanguageOption[] = [
    { code: 'en', label: 'English', flag: '🇺🇸' },
    { code: 'pt', label: 'Português', flag: '🇧🇷' },
    { code: 'es', label: 'Español', flag: '🇪🇸' },
    { code: 'fr', label: 'Français', flag: '🇫🇷' },
    { code: 'it', label: 'Italiano', flag: '🇮🇹' },
    { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
  ];

  const currentLang = languages.find(l => l.code === language) || languages[0];

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/40 backdrop-blur-md border border-white/50 hover:bg-white/60 transition-all shadow-sm group"
      >
        <span className="text-lg leading-none filter drop-shadow-sm">{currentLang.flag}</span>
        <span className="font-sans font-bold text-xs text-gray-700 uppercase tracking-wide group-hover:text-angel-gold transition-colors">
          {currentLang.code}
        </span>
        <ChevronDown className={`w-3 h-3 text-gray-500 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white/90 backdrop-blur-xl rounded-xl shadow-xl border border-white/50 py-2 animate-in fade-in zoom-in-95 duration-200 z-[60]">
          {languages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => {
                setLanguage(lang.code);
                setIsOpen(false);
              }}
              className={`w-full text-left px-4 py-2.5 text-sm flex items-center gap-3 hover:bg-angel-gold/10 transition-colors
                ${language === lang.code ? 'text-angel-gold font-bold bg-angel-gold/5' : 'text-gray-700'}
              `}
            >
              <span className="text-lg">{lang.flag}</span>
              <span className="font-medium">{lang.label}</span>
              {language === lang.code && (
                <span className="ml-auto text-xs font-bold text-angel-gold">✓</span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};