
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Sparkles, Loader2, Shield, Plus, Ghost } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import { formatDistanceToNow } from 'date-fns';
import { ptBR, es, fr, it, de } from 'date-fns/locale';
import { useTranslation } from '../lib/i18n_context';
import { getRank } from '../lib/gamification';

// Locale Map for Date-FNS
const localeMap: Record<string, any> = {
  pt: ptBR,
  es: es,
  fr: fr,
  it: it,
  de: de,
  en: undefined // date-fns defaults to English
};

// --- Types ---
interface PrayerRequest {
  id: string;
  user_id: string;
  content: string;
  intercessors_count: number;
  is_anonymous: boolean;
  created_at: string;
  profiles?: {
    name: string;
    avatar_url: string | null;
    intercessions_count: number;
  };
  hasInterceded?: boolean; 
}

// --- Single Card Component ---
const PrayerCard: React.FC<{ request: PrayerRequest, currentUserId: string }> = ({ request, currentUserId }) => {
  const { t, language } = useTranslation();
  const [hasInterceded, setHasInterceded] = useState(request.hasInterceded || false);
  const [count, setCount] = useState(request.intercessors_count);
  const [isAnimating, setIsAnimating] = useState(false);

  const handleIntercede = async () => {
    if (hasInterceded) return;

    // 1. Optimistic Update with Explosion Effect
    setHasInterceded(true);
    setCount(prev => prev + 1);
    setIsAnimating(true);
    
    setTimeout(() => setIsAnimating(false), 1500);

    // 2. Real DB Call
    try {
      // Insert intercession record
      const { error } = await supabase
        .from('prayer_intercessions')
        .insert({
          prayer_id: request.id,
          intercessor_id: currentUserId
        });

      if (error) {
        // Unique constraint violation means already interceded
        if (error.code === '23505') return; 
        throw error;
      }
      
      toast.success(t('comm_btn_sent'), {
          description: t('journey_toast_desc'),
          icon: <Sparkles className="w-4 h-4 text-angel-gold" />,
          style: { border: '1px solid #D4AF37' }
      });

    } catch (error) {
      console.error(error);
      setHasInterceded(false);
      setCount(prev => prev - 1);
      toast.error("Could not send prayer. Please try again.");
    }
  };

  const displayName = request.is_anonymous ? t('comm_anonymous_user') : (request.profiles?.name || 'Unknown');
  
  // DATE-FNS LOCALIZATION FIX
  let displayTime = 'Just now';
  try {
     displayTime = formatDistanceToNow(new Date(request.created_at), { 
         addSuffix: true,
         locale: localeMap[language] 
     });
  } catch (e) {}
  
  const avatarUrl = request.profiles?.avatar_url;
  
  // Calculate Rank for Badge
  const userRankCount = request.profiles?.intercessions_count || 0;
  const { rank } = getRank(userRankCount);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card rounded-2xl p-6 mb-5 relative overflow-hidden group border-white/60 hover:border-angel-gold/30 transition-all duration-500"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
            <div className={`w-11 h-11 rounded-full border border-white shadow-sm flex items-center justify-center overflow-hidden ${request.is_anonymous ? 'bg-slate-800' : 'bg-gray-100'}`}>
            {request.is_anonymous ? (
                <Ghost className="w-5 h-5 text-slate-400" />
            ) : avatarUrl ? (
                <img src={avatarUrl} alt={displayName} className="w-full h-full object-cover" />
            ) : (
                <Shield className="w-5 h-5 text-gray-300" />
            )}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h4 className={`font-serif font-bold text-base ${request.is_anonymous ? 'text-slate-600 italic' : 'text-gray-900'}`}>{displayName}</h4>
                
                {/* MEDAL BADGE NEXT TO NAME */}
                {!request.is_anonymous && (
                  <div className={`w-4 h-4 rounded-full ${rank.bg} flex items-center justify-center ${rank.shadow || ''}`} title={t(rank.titleKey)}>
                     <rank.icon className={`w-2.5 h-2.5 ${rank.color}`} />
                  </div>
                )}
              </div>
              <span className="text-[10px] uppercase tracking-wider text-gray-400 font-bold">{displayTime}</span>
            </div>
        </div>
      </div>

      {/* Body */}
      <p className="font-serif text-xl text-gray-800 italic leading-relaxed mb-6 pl-4 border-l-2 border-angel-gold/20">
        "{request.content}"
      </p>

      {/* Footer / Actions */}
      <div className="flex items-center justify-between border-t border-gray-100/50 pt-4 mt-2">
        <div className="flex items-center gap-2 text-xs text-gray-500 font-bold uppercase tracking-wide">
          <span className="text-angel-gold bg-angel-gold/10 px-2 py-0.5 rounded-full">{count}</span> 
          <span>{t('comm_intercessors')}</span>
        </div>

        <button
          onClick={handleIntercede}
          disabled={hasInterceded}
          className={`
            relative flex items-center gap-2 px-5 py-2.5 rounded-full transition-all duration-500 overflow-hidden
            ${hasInterceded 
              ? 'bg-gradient-to-r from-angel-gold to-yellow-500 text-white shadow-gold-glow cursor-default' 
              : 'bg-white border border-gray-200 text-gray-600 hover:border-angel-gold hover:text-angel-gold hover:shadow-lg'}
          `}
        >
          {/* Background Flash Animation */}
          <AnimatePresence>
            {isAnimating && (
               <motion.div 
                 initial={{ opacity: 0.8, scale: 0 }}
                 animate={{ opacity: 0, scale: 4 }}
                 transition={{ duration: 0.6 }}
                 className="absolute inset-0 bg-white rounded-full z-0"
               />
            )}
          </AnimatePresence>
          
          <Heart className={`w-4 h-4 z-10 transition-transform duration-300 ${hasInterceded ? 'fill-white scale-110' : ''}`} />
          <span className="text-xs font-bold z-10 uppercase tracking-wider">{hasInterceded ? t('comm_btn_sent') : t('comm_btn_pray')}</span>
          
          {/* Particle Explosion */}
          <AnimatePresence>
            {isAnimating && (
              <>
                {[...Array(6)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
                    animate={{ 
                      x: Math.random() * 60 - 30, 
                      y: Math.random() * -60 - 20, 
                      opacity: 0, 
                      scale: 0 
                    }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="absolute top-1/2 left-1/2 w-1.5 h-1.5 bg-yellow-300 rounded-full z-20"
                  />
                ))}
              </>
            )}
          </AnimatePresence>
        </button>
      </div>
    </motion.div>
  );
};

// --- Main Feed Component ---
export const PrayerFeed: React.FC = () => {
  const { t } = useTranslation();
  const [prayers, setPrayers] = useState<PrayerRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [newPrayer, setNewPrayer] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string>('');

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
        if (data.user) setCurrentUserId(data.user.id);
    });
    fetchPrayers();
  }, []);

  const fetchPrayers = async () => {
    try {
      // Fetch prayers with profile data
      const { data, error } = await supabase
        .from('prayer_requests')
        .select(`
          *,
          profiles:user_id (name, avatar_url, intercessions_count)
        `)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
         console.error("Error fetching prayers:", error);
         // Don't crash UI, just show empty
      } else {
         setPrayers(data || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitPrayer = async () => {
    if (!newPrayer.trim()) return;
    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Please log in to submit a prayer.");

      // DEFENSIVE PROGRAMMING: Ensure Profile Exists
      const { data: profileCheck } = await supabase.from('profiles').select('id, name, avatar_url, intercessions_count').eq('id', user.id).maybeSingle();
      
      let userProfile = profileCheck;

      if (!profileCheck) {
         // Create profile on the fly if missing
         const { data: newProfile, error: profileError } = await supabase.from('profiles').insert({ 
           id: user.id,
           name: user.email?.split('@')[0] || 'Soul',
           preferred_language: 'en'
         }).select().single();
         
         if (!profileError) userProfile = newProfile;
      }

      // INSERT PRAYER
      const { data: insertedData, error } = await supabase
        .from('prayer_requests')
        .insert({
          user_id: user.id,
          content: newPrayer.trim(),
          intercessors_count: 0,
          is_anonymous: isAnonymous
        })
        .select()
        .single();

      if (error) throw error;

      if (insertedData) {
        // Construct the full object for the UI without re-fetching
        const newRequestWithProfile: PrayerRequest = {
          ...insertedData,
          profiles: {
            name: userProfile?.name || 'Anonymous',
            avatar_url: userProfile?.avatar_url || null,
            intercessions_count: userProfile?.intercessions_count || 0
          }
        };

        setPrayers(prev => [newRequestWithProfile, ...prev]);
        setNewPrayer('');
        setIsAnonymous(false);
        toast.success(t('comm_btn_sent'), {
           icon: <Sparkles className="w-4 h-4 text-angel-gold" />
        });
      }

    } catch (error: any) {
      console.error("Post error:", error);
      toast.error(error.message || "Could not post prayer");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto pb-24 px-4 md:px-0">
       <div className="text-center mb-8 pt-6">
          <div className="w-12 h-1 bg-angel-gold mx-auto mb-4 rounded-full opacity-50"></div>
          <h2 className="font-serif text-4xl font-bold text-gray-900 mb-3 tracking-tight">{t('comm_wall_title')}</h2>
          <p className="text-gray-500 text-sm font-sans max-w-md mx-auto leading-relaxed">
            {t('comm_wall_sub')}
          </p>
       </div>

       {/* CREATE PRAYER FORM */}
       <div className="glass-card rounded-xl p-4 mb-10 shadow-sm border border-angel-gold/20 relative">
          <textarea
            value={newPrayer}
            onChange={(e) => setNewPrayer(e.target.value)}
            placeholder={t('comm_placeholder')}
            className="w-full bg-white/50 rounded-lg p-3 text-gray-800 placeholder:text-gray-400 focus:outline-none focus:ring-1 focus:ring-angel-gold resize-none text-sm font-serif"
            rows={3}
          />
          <div className="flex justify-between items-center mt-3">
            <div className="flex items-center gap-2">
                <input 
                  type="checkbox" 
                  id="anon-check"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="rounded border-gray-300 text-angel-gold focus:ring-angel-gold"
                />
                <label htmlFor="anon-check" className="text-xs text-gray-500 font-bold uppercase tracking-wide cursor-pointer select-none">
                    {t('comm_anonymous')}
                </label>
            </div>

            <button
              onClick={handleSubmitPrayer}
              disabled={isSubmitting || !newPrayer.trim()}
              className="bg-angel-gold hover:bg-yellow-600 text-white px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
            >
              {isSubmitting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />}
              {t('comm_ask_btn')}
            </button>
          </div>
       </div>

       <div>
          {loading ? (
             <div className="flex justify-center py-12">
               <Loader2 className="w-8 h-8 text-angel-gold animate-spin opacity-50" />
             </div>
          ) : prayers.length === 0 ? (
            <div className="text-center py-16 glass-card rounded-xl border-dashed border-2 border-gray-300">
               <Sparkles className="w-10 h-10 text-gray-300 mx-auto mb-3" />
               <p className="text-gray-400 italic font-serif text-lg">{t('comm_empty_wall')}</p>
            </div>
          ) : (
             prayers.map(request => (
               <PrayerCard key={request.id} request={request} currentUserId={currentUserId} />
             ))
          )}
       </div>
    </div>
  );
};
