
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, Clock, Flame, X, CheckCircle, BellRing } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import { playAngelicChord } from '../lib/audio';
import { triggerDivineCelebration } from '../lib/confetti';
import { format } from 'date-fns';
import { useTranslation } from '../lib/i18n_context';

const QUOTE_KEYS = [
  "prayer_quote_1",
  "prayer_quote_2",
  "prayer_quote_3",
  "prayer_quote_4",
  "prayer_quote_5",
];

export const PrayerCircle: React.FC = () => {
  const { t } = useTranslation();
  const [activeUsers, setActiveUsers] = useState(12); // Baseline fallback
  const [isPrayerModalOpen, setPrayerModalOpen] = useState(false);
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes in seconds
  const [isActive, setIsActive] = useState(false);
  const [quoteIndex, setQuoteIndex] = useState(0);
  const [completed, setCompleted] = useState(false);
  
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // 1. Realtime Presence Logic
  useEffect(() => {
    const channel = supabase.channel('online-prayer-room', {
      config: {
        presence: { key: 'user' },
      },
    });

    channel
      .on('presence', { event: 'sync' }, () => {
        const newState = channel.presenceState();
        // Calculate distinct users roughly or just count keys
        const count = Object.keys(newState).length;
        setActiveUsers(Math.max(12, count + 10)); // Add baseline to make it feel alive for MVP
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await channel.track({ online_at: new Date().toISOString() });
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // 2. Timer Logic
  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isActive) {
      handleComplete();
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, timeLeft]);

  // 3. Quote Rotation
  useEffect(() => {
    if (isActive) {
      const quoteInterval = setInterval(() => {
        setQuoteIndex((prev) => (prev + 1) % QUOTE_KEYS.length);
      }, 30000); // Change quote every 30s
      return () => clearInterval(quoteInterval);
    }
  }, [isActive]);

  const startPrayer = () => {
    setPrayerModalOpen(true);
    setIsActive(true);
    setTimeLeft(300); // Reset to 5m
    setCompleted(false);
    playAngelicChord();
  };

  const handleComplete = async () => {
    setIsActive(false);
    if (timerRef.current) clearInterval(timerRef.current);
    setCompleted(true);
    triggerDivineCelebration();
    playAngelicChord();
    
    // Auto-mark Checklist Task ID 1 (Morning Prayer)
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const today = format(new Date(), 'yyyy-MM-dd');
        
        // 1. Get current log
        const { data: existingLog } = await supabase
          .from('daily_checklist_logs')
          .select('tasks_completed')
          .eq('user_id', user.id)
          .eq('log_date', today)
          .maybeSingle();
        
        const currentTasks = existingLog?.tasks_completed || [];
        
        // 2. Add ID 1 if not exists
        if (!currentTasks.includes(1)) {
          await supabase.from('daily_checklist_logs').upsert({
            user_id: user.id,
            log_date: today,
            tasks_completed: [...currentTasks, 1]
          }, { onConflict: 'user_id, log_date' });
          
          toast.success(t('msg_discipline'), {
             description: t('msg_offering_accepted'),
             icon: <CheckCircle className="w-4 h-4 text-green-500" />
          });
        }
      }
    } catch (e) {
      console.error("Failed to auto-log prayer", e);
    }
  };

  const closePrayer = () => {
    setPrayerModalOpen(false);
    setIsActive(false);
    setTimeLeft(300);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progress = ((300 - timeLeft) / 300) * 100;
  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <>
      {/* HERO WIDGET */}
      <div className="glass-card rounded-2xl p-6 mb-8 border border-angel-gold/20 relative overflow-hidden">
        {/* Background Ambience */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-200/10 rounded-full blur-3xl -mr-16 -mt-16"></div>
        
        <div className="flex flex-col md:flex-row items-center justify-between relative z-10 gap-6">
          <div className="flex items-center gap-4">
             <div className="w-16 h-16 rounded-full bg-gradient-to-br from-angel-gold to-yellow-600 flex items-center justify-center shadow-gold-glow animate-pulse-slow">
                <Flame className="w-8 h-8 text-white" />
             </div>
             <div>
               <h2 className="font-serif text-2xl font-bold text-gray-900">{t('comm_prayer_circle')}</h2>
               <div className="flex items-center gap-2 mt-1">
                 <span className="relative flex h-2.5 w-2.5">
                   <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                   <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500"></span>
                 </span>
                 <p className="text-xs font-sans font-bold text-gray-500 uppercase tracking-widest">
                   {activeUsers} {t('comm_angels_now')}
                 </p>
               </div>
             </div>
          </div>

          <button 
            onClick={startPrayer}
            className="w-full md:w-auto px-8 py-3 bg-white border border-angel-gold text-angel-dark font-serif font-bold rounded-full shadow-lg hover:bg-angel-gold hover:text-white transition-all duration-300 flex items-center justify-center gap-3 group"
          >
            <Clock className="w-5 h-5 group-hover:rotate-12 transition-transform" />
            {t('comm_btn_enter')}
          </button>
        </div>
      </div>

      {/* IMMERSIVE MODAL */}
      <AnimatePresence>
        {isPrayerModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-stone-900/95 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative w-full h-full md:h-auto md:max-w-2xl md:aspect-square flex flex-col items-center justify-center text-center p-8"
            >
              <button 
                onClick={closePrayer} 
                className="absolute top-8 right-8 text-stone-500 hover:text-white transition-colors"
              >
                <X className="w-8 h-8" />
              </button>

              {/* Central Visual */}
              <div className="relative w-64 h-64 mb-12 flex items-center justify-center">
                 {/* Progress Ring */}
                 <svg className="absolute w-full h-full transform -rotate-90">
                    <circle
                      cx="128" cy="128" r={radius}
                      stroke="#44403c" // stone-700
                      strokeWidth="2"
                      fill="transparent"
                    />
                    <motion.circle
                      initial={{ strokeDashoffset: circumference }}
                      animate={{ strokeDashoffset }}
                      transition={{ duration: 1, ease: "linear" }}
                      cx="128" cy="128" r={radius}
                      stroke="#D4AF37"
                      strokeWidth="4"
                      fill="transparent"
                      strokeDasharray={circumference}
                      strokeLinecap="round"
                      className="shadow-gold-glow"
                    />
                 </svg>

                 {/* Icon / Countdown */}
                 <div className="absolute inset-0 flex flex-col items-center justify-center">
                    {completed ? (
                      <motion.div 
                        initial={{ scale: 0 }} 
                        animate={{ scale: 1 }}
                        className="text-angel-gold"
                      >
                         <BellRing className="w-16 h-16 mb-2" />
                         <span className="text-xl font-serif">{t('comm_amen')}</span>
                      </motion.div>
                    ) : (
                      <>
                        <span className="font-serif text-5xl text-white font-bold tracking-tighter">
                          {formatTime(timeLeft)}
                        </span>
                        <span className="text-xs text-stone-400 uppercase tracking-widest mt-2">{t('comm_remains')}</span>
                      </>
                    )}
                 </div>
              </div>

              {/* Dynamic Quote */}
              <div className="h-24 max-w-lg mx-auto">
                <AnimatePresence mode='wait'>
                  <motion.p
                    key={quoteIndex}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="font-serif text-xl md:text-2xl text-stone-300 italic leading-relaxed"
                  >
                    "{t(QUOTE_KEYS[quoteIndex])}"
                  </motion.p>
                </AnimatePresence>
              </div>

              {completed && (
                <motion.button
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  onClick={closePrayer}
                  className="mt-8 px-8 py-3 bg-angel-gold text-stone-900 font-bold rounded-full hover:bg-white transition-colors"
                >
                  {t('comm_return')}
                </motion.button>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
