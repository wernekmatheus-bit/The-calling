import React from 'react';
import { useTranslation } from '../lib/i18n_context';
import { LogOut } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { LanguageSwitcher } from './LanguageSwitcher';

interface NavbarProps {
  isAuthenticated: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ isAuthenticated }) => {
  const { t } = useTranslation();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    window.location.reload();
  };

  return (
    <nav className="fixed top-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-angel-gold/20 shadow-sm h-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center justify-between">
        
        {/* Brand */}
        <div className="flex items-center gap-2">
           <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-angel-gold to-yellow-300 flex items-center justify-center shadow-md">
             <span className="text-white font-serif font-bold text-lg">A</span>
           </div>
           <span className="font-serif font-bold text-gray-800 tracking-wide hidden sm:block">The Calling</span>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          
          <LanguageSwitcher />

          {/* User Actions */}
          {isAuthenticated && (
            <div className="flex items-center gap-4 border-l border-gray-200 pl-4">
               <button onClick={handleLogout} className="text-gray-500 hover:text-red-500 transition-colors" title={t('logout')}>
                 <LogOut className="h-5 w-5" />
               </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};