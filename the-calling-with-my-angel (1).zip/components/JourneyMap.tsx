
import React, { useEffect, useRef, useMemo } from 'react';
import { Flame, Lock, CheckCircle2, Hourglass, Star, Cloud, Sun, Moon } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTranslation } from '../lib/i18n_context';

interface JourneyMapProps {
  currentLevel: number;
  totalSteps?: number;
  onDayClick: (day: number) => void;
  isCooldown: boolean;
  hoursRemaining: number;
}

export const JourneyMap: React.FC<JourneyMapProps> = ({ 
  currentLevel, 
  totalSteps = 45,
  onDayClick,
  isCooldown,
  hoursRemaining
}) => {
  const { t } = useTranslation();
  const containerRef = useRef<HTMLDivElement>(null);
  const activeRef = useRef<HTMLDivElement>(null);

  // Configuration for the S-Curve
  const STEP_HEIGHT = 120; // Increased spacing for grandeur
  const AMPLITUDE = 100;   
  const FREQUENCY = 0.4;   
  const CENTER_X = 200;    
  
  const { pathData, nodes } = useMemo(() => {
    let d = `M ${CENTER_X} 50`; 
    const nodeCoords = [];

    for (let i = 0; i < totalSteps; i++) {
      const y = (i * STEP_HEIGHT) + 80;
      const x = CENTER_X + (Math.sin(i * FREQUENCY) * AMPLITUDE);
      
      const nextY = ((i + 1) * STEP_HEIGHT) + 80;
      const nextX = CENTER_X + (Math.sin((i + 1) * FREQUENCY) * AMPLITUDE);
      const cpY = (y + nextY) / 2;
      
      if (i < totalSteps - 1) {
         d += ` Q ${x} ${cpY}, ${nextX} ${nextY}`;
      }

      nodeCoords.push({ x, y, id: i + 1 });
    }

    return { pathData: d, nodes: nodeCoords };
  }, [totalSteps]);

  useEffect(() => {
    if (activeRef.current) {
      activeRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [currentLevel]);

  return (
    <div className="w-full relative overflow-hidden flex justify-center bg-[#0a0a0a]" ref={containerRef}>
      
      {/* 1. IMMERSIVE BACKGROUND */}
      <div className="absolute inset-0 z-0">
         {/* Base Image - UPDATED */}
         <img 
            src="https://images.unsplash.com/photo-1536514072410-50c81833285a?q=80&w=2070&auto=format&fit=crop" 
            alt="Heavenly Background" 
            className="w-full h-full object-cover opacity-30 fixed"
         />
         <div className="absolute inset-0 bg-gradient-to-b from-slate-900/90 via-slate-900/60 to-slate-900/90"></div>
         
         {/* Ethereal Glows */}
         <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-angel-gold/20 rounded-full blur-[100px] animate-pulse-slow"></div>
         <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-[100px]"></div>
      </div>

      {/* 2. SCROLLABLE CONTAINER */}
      <div className="relative w-[400px] z-10 py-20" style={{ height: totalSteps * STEP_HEIGHT + 200 }}>
        
        {/* The Golden Path (SVG) */}
        <svg 
          className="absolute top-0 left-0 w-full h-full pointer-events-none"
          viewBox={`0 0 400 ${totalSteps * STEP_HEIGHT + 200}`}
        >
          {/* Outer Glow */}
          <path 
            d={pathData} 
            fill="none" 
            stroke="#D4AF37" 
            strokeWidth="16" 
            strokeOpacity="0.1"
            strokeLinecap="round"
            className="filter blur-md"
          />
          {/* Core Path */}
          <path 
            d={pathData} 
            fill="none" 
            stroke="url(#goldGradient)" 
            strokeWidth="3" 
            strokeDasharray="4 8"
            strokeLinecap="round"
          />
          <defs>
            <linearGradient id="goldGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#D4AF37" stopOpacity="0" />
              <stop offset="10%" stopColor="#D4AF37" stopOpacity="1" />
              <stop offset="90%" stopColor="#D4AF37" stopOpacity="1" />
              <stop offset="100%" stopColor="#D4AF37" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>

        {/* The Stations (Nodes) */}
        {nodes.map((node, index) => {
          const stepNumber = index + 1;
          const isCompleted = stepNumber < currentLevel;
          const isCurrent = stepNumber === currentLevel;
          const isLocked = stepNumber > currentLevel;
          
          const isMajor = stepNumber % 9 === 0; // Novena cycle (9 days)

          return (
            <div 
              key={node.id}
              ref={isCurrent ? activeRef : null}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group"
              style={{ left: node.x, top: node.y }}
              onClick={() => onDayClick(stepNumber)}
            >
              {/* Day Label (Floating) */}
              <div 
                className={`
                  absolute ${isMajor ? '-top-10' : 'top-1'} w-32 text-center pointer-events-none transition-all duration-500
                  ${node.x > 200 ? 'right-full mr-6' : 'left-full ml-6'}
                  ${isCurrent ? 'opacity-100 scale-110' : 'opacity-60 group-hover:opacity-100'}
                `}
              >
                <span className={`font-serif font-bold text-sm tracking-widest ${isCurrent ? 'text-angel-gold' : 'text-slate-400'}`}>
                   {isMajor ? 'NOVENA CYCLE' : `DAY ${stepNumber}`}
                </span>
                
                {isCurrent && isCooldown && (
                  <div className="flex items-center justify-center gap-1 mt-1 bg-black/60 backdrop-blur-md px-2 py-1 rounded-full border border-orange-500/30">
                     <Hourglass className="w-3 h-3 text-orange-500" />
                     <span className="text-[10px] text-orange-400 font-bold">{hoursRemaining}h</span>
                  </div>
                )}
              </div>

              {/* Visual Node */}
              <motion.div
                initial={false}
                whileHover={!isLocked ? { scale: 1.2 } : {}}
                whileTap={!isLocked ? { scale: 0.9 } : {}}
                className={`
                  relative flex items-center justify-center transition-all duration-500 cursor-pointer
                  ${isMajor ? 'w-20 h-20' : 'w-14 h-14'}
                `}
              >
                {/* Glow Effect for Current */}
                {isCurrent && !isCooldown && (
                  <div className="absolute inset-0 bg-angel-gold rounded-full blur-xl opacity-60 animate-pulse"></div>
                )}

                {/* Node Shape */}
                <div className={`
                   w-full h-full rounded-full flex items-center justify-center border-2 shadow-2xl backdrop-blur-sm
                   ${isCompleted ? 'bg-angel-gold border-white/50' : ''}
                   ${isCurrent ? 'bg-black/80 border-angel-gold shadow-[0_0_20px_#D4AF37]' : ''}
                   ${isLocked ? 'bg-slate-900/80 border-slate-700' : ''}
                `}>
                   
                   {isCompleted && <CheckCircle2 className="w-6 h-6 text-white" />}
                   
                   {isCurrent && (
                      isCooldown 
                        ? <Hourglass className="w-6 h-6 text-orange-400 opacity-80" /> 
                        : <Flame className="w-6 h-6 text-angel-gold fill-angel-gold animate-bounce" />
                   )}
                   
                   {isLocked && <Lock className="w-5 h-5 text-slate-600" />}
                </div>
                
                {/* Major Milestone Decoration */}
                {isMajor && !isLocked && (
                   <div className="absolute -inset-2 border border-angel-gold/30 rounded-full animate-spin-slow pointer-events-none"></div>
                )}

              </motion.div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
