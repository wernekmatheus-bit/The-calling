import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface Tab {
  id: string;
  label: string;
  content: React.ReactNode;
}

interface TabsProps {
  tabs: Tab[];
}

export const Tabs: React.FC<TabsProps> = ({ tabs }) => {
  const [activeTab, setActiveTab] = useState(tabs[0].id);

  return (
    <div className="w-full">
      <div className="flex border-b border-gray-200 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`relative px-6 py-3 text-sm font-medium transition-colors duration-200 font-sans tracking-wide
              ${activeTab === tab.id ? 'text-angel-gold' : 'text-gray-500 hover:text-gray-700'}
            `}
          >
            {tab.label}
            {activeTab === tab.id && (
              <motion.div
                layoutId="activeTab"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-angel-gold shadow-[0_0_8px_#D4AF37]"
              />
            )}
          </button>
        ))}
      </div>
      <div className="animate-in fade-in duration-300">
        {tabs.find((t) => t.id === activeTab)?.content}
      </div>
    </div>
  );
};