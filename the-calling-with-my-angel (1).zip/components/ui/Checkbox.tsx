
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check } from 'lucide-react';

interface CheckboxProps {
  checked: boolean;
  onChange: () => void;
  label: string;
}

export const Checkbox: React.FC<CheckboxProps> = ({ checked, onChange, label }) => {
  return (
    <div 
      onClick={onChange}
      className={`
        flex items-center gap-4 p-4 rounded-xl cursor-pointer group transition-all duration-300 relative overflow-hidden
        ${checked ? 'bg-angel-gold/5 border-angel-gold/10' : 'hover:bg-white/60 bg-white/40 border-transparent'}
        border
      `}
    >
      {/* Background glow animation on check */}
      <AnimatePresence>
        {checked && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-gradient-to-r from-angel-gold/10 to-transparent pointer-events-none"
          />
        )}
      </AnimatePresence>

      <div className="relative z-10">
        <motion.div
          initial={false}
          animate={{
            backgroundColor: checked ? "#D4AF37" : "transparent",
            borderColor: checked ? "#D4AF37" : "#E5E7EB",
            scale: checked ? 1.05 : 1
          }}
          whileTap={{ scale: 0.9 }}
          className="w-6 h-6 rounded-md border-2 flex items-center justify-center transition-colors duration-300 shadow-sm"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: checked ? 1 : 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            <Check className="w-4 h-4 text-white" strokeWidth={3} />
          </motion.div>
        </motion.div>
        
        {/* Particle burst placeholder (handled via simple scale/glow here for minimalism) */}
        {checked && (
            <div className="absolute inset-0 bg-angel-gold rounded-md animate-ping opacity-20 duration-500"></div>
        )}
      </div>
      
      <span className={`font-serif text-lg transition-all duration-300 relative z-10 ${checked ? 'text-angel-gold font-medium line-through decoration-angel-gold/50' : 'text-gray-800'}`}>
        {label}
      </span>
    </div>
  );
};
