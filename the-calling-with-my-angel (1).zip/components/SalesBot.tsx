import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, ExternalLink, ChevronRight, ChevronLeft } from 'lucide-react';
import { useTranslation } from '../lib/i18n_context';

export const SalesBot: React.FC = () => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState<'initial' | 'pitch'>('initial');

  const handleChoice = (choice: 'yes' | 'no') => {
    if (choice === 'yes') {
      setStep('pitch');
    } else {
      setIsOpen(false); // Close if not interested
      setTimeout(() => setStep('initial'), 500); // Reset for next time
    }
  };

  return (
    <>
      {/* Floating Action Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-gradient-to-tr from-angel-gold to-yellow-400 rounded-full shadow-[0_4px_20px_rgba(212,175,55,0.4)] flex items-center justify-center text-white border-2 border-white/50"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-7 h-7 fill-white/20" />}
        {!isOpen && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white animate-pulse"></span>
        )}
      </motion.button>

      {/* Popover Card */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed bottom-24 right-6 z-40 w-80 bg-white rounded-2xl shadow-2xl border border-angel-gold/20 overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-angel-gold to-yellow-600 p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center border border-white/40">
                <span className="font-serif text-white font-bold text-lg">A</span>
              </div>
              <div>
                <h4 className="font-bold text-white text-sm">{t('bot_title')}</h4>
                <p className="text-white/80 text-[10px] uppercase tracking-wider">{t('bot_role')}</p>
              </div>
            </div>

            {/* Content Body */}
            <div className="p-5">
              {step === 'initial' ? (
                <div className="space-y-4">
                  <p className="text-gray-700 font-serif italic text-lg leading-relaxed">
                    "{t('bot_initial_q')}"
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      onClick={() => handleChoice('no')}
                      className="py-2 px-4 rounded-lg border border-gray-200 text-gray-500 text-sm hover:bg-gray-50 transition-colors"
                    >
                      {t('bot_btn_well')}
                    </button>
                    <button 
                      onClick={() => handleChoice('yes')}
                      className="py-2 px-4 rounded-lg bg-angel-gold text-white text-sm font-semibold shadow-md hover:bg-yellow-600 transition-colors"
                    >
                      {t('bot_btn_tired')}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-gray-700 text-sm leading-relaxed">
                    {t('bot_pitch')}
                  </p>
                  
                  <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-100 flex items-center gap-3">
                     <div className="h-12 w-12 bg-white rounded border border-gray-200 flex items-center justify-center text-xs font-bold text-gray-400">IMG</div>
                     <div>
                       <p className="font-bold text-gray-800 text-sm">{t('bot_product_name')}</p>
                       <p className="text-xs text-green-600 font-bold">$49.99 <span className="text-gray-400 font-normal line-through">$89.99</span></p>
                     </div>
                  </div>

                  <a 
                    href="https://example.com/affiliate-link" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 w-full py-3 bg-gradient-to-r from-gray-900 to-gray-800 text-white rounded-lg font-bold text-sm shadow-lg hover:opacity-90 transition-opacity"
                  >
                    {t('bot_view_product')} <ExternalLink className="w-4 h-4" />
                  </a>
                  
                  <button 
                    onClick={() => setStep('initial')}
                    className="w-full text-center text-xs text-gray-400 hover:text-gray-600 flex items-center justify-center gap-1"
                  >
                    <ChevronLeft className="w-3 h-3" /> {t('bot_back')}
                  </button>
                </div>
              )}
            </div>

          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};