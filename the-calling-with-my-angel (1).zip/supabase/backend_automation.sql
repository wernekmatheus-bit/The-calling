-- 1. ENABLE EXTENSIONS
create extension if not exists "pg_net"; -- Required to make HTTP calls from SQL
create extension if not exists "pg_cron"; -- Required for scheduled jobs

-- 2. GENERIC WEBHOOK FUNCTION
-- This function sends a POST request to the Supabase Edge Function
create or replace function public.trigger_email_edge_function()
returns trigger as $$
declare
  payload jsonb;
begin
  -- Construct Payload based on trigger source
  if TG_TABLE_NAME = 'user_badges' then
    payload := jsonb_build_object(
      'event_type', 'BADGE_EARNED',
      'user_id', new.user_id,
      'badge_id', new.badge_id
    );
  elsif TG_TABLE_NAME = 'prayer_requests' then
    payload := jsonb_build_object(
      'event_type', 'PRAYER_RECEIVED',
      'request_id', new.id,
      'intercessors_count', new.intercessors
    );
  end if;

  -- Call Edge Function (Replace URL with actual function URL)
  -- Uses pg_net to be non-blocking
  perform net.http_post(
    url := 'https://PROJECT_REF.supabase.co/functions/v1/send-email',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer SERVICE_ROLE_KEY"}'::jsonb,
    body := payload
  );

  return new;
end;
$$ language plpgsql security definer;

-- 3. TRIGGERS

-- A. Trigger on New Badge (Gamification)
-- Assuming table user_badges(user_id, badge_id, created_at)
create trigger on_badge_earned
  after insert on public.user_badges
  for each row execute procedure public.trigger_email_edge_function();

-- B. Trigger on Prayer Intercession (Social)
-- Assuming table prayer_requests(id, intercessors, ...)
-- We only want to notify on milestones (e.g., 10, 50, 100 prayers)
create trigger on_prayer_update
  after update of intercessors on public.prayer_requests
  for each row
  when (new.intercessors IN (10, 50, 100) AND new.intercessors > old.intercessors)
  execute procedure public.trigger_email_edge_function();


-- 4. CRON JOB: RE-ENGAGEMENT (STREAK LOST)
-- Runs every day at 10 AM UTC
select cron.schedule(
  'check-lost-streaks',
  '0 10 * * *', 
  $$
    select net.http_post(
        url := 'https://PROJECT_REF.supabase.co/functions/v1/send-email',
        headers := '{"Content-Type": "application/json", "Authorization": "Bearer SERVICE_ROLE_KEY"}'::jsonb,
        body := jsonb_build_object(
            'event_type', 'STREAK_LOST_CHECK'
        )
    );
  $$
);