
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts"; // Assuming shared, but defining inline for safety below

declare const Deno: any;

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // 1. Handle CORS Preflight - IMMEDIATE RETURN
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: CORS_HEADERS });
  }

  try {
    // 2. Environment Check
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!supabaseUrl || !serviceRoleKey) {
      throw new Error("Server Misconfiguration: Missing SUPABASE_SERVICE_ROLE_KEY");
    }

    // 3. Body Parsing
    let body;
    try {
      body = await req.json();
    } catch {
      throw new Error("Invalid Request Body. Expected JSON.");
    }
    
    const { email } = body;
    if (!email) throw new Error("Email is required.");

    // 4. Admin Client Init
    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });

    const cleanEmail = email.trim().toLowerCase();

    // 5. Database Lookup (Whitelist)
    const { data: whitelistData, error: whitelistError } = await supabaseAdmin
      .from('whitelist_customers')
      .select('transaction_id')
      .eq('email', cleanEmail)
      .maybeSingle();

    if (whitelistError) {
      console.error("DB Error:", whitelistError);
      throw new Error("Database connection error.");
    }

    if (!whitelistData) {
      return new Response(JSON.stringify({ error: "Access Denied: Email not in whitelist." }), {
        status: 401, // Unauthorized
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      });
    }

    const securePassword = whitelistData.transaction_id || 'default-entry-token';

    // 6. Auth Handshake
    const { data: signInData, error: signInError } = await supabaseAdmin.auth.signInWithPassword({
      email: cleanEmail,
      password: securePassword,
    });

    // 7. Auto-Correction Logic (Sync Password if changed)
    if (signInError && (signInError.message.includes('Invalid login') || signInError.message.includes('not found'))) {
       
       const { data: userList } = await supabaseAdmin.auth.admin.listUsers();
       const existingUser = userList.users.find((u: any) => u.email?.toLowerCase() === cleanEmail);

       if (existingUser) {
          await supabaseAdmin.auth.admin.updateUserById(existingUser.id, { password: securePassword });
       } else {
          await supabaseAdmin.auth.admin.createUser({
            email: cleanEmail,
            password: securePassword,
            email_confirm: true,
            user_metadata: { source: 'silent_auth' }
          });
       }

       // Retry Login
       const { data: retryData, error: retryError } = await supabaseAdmin.auth.signInWithPassword({
         email: cleanEmail,
         password: securePassword,
       });
       
       if (retryError) throw retryError;
       
       return new Response(JSON.stringify(retryData.session), {
         headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
       });
    }

    if (signInError) throw signInError;

    // Success
    return new Response(JSON.stringify(signInData.session), {
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
    });

  } catch (error: any) {
    // CATCH-ALL: Returns JSON error instead of crashing, allowing Frontend to read the message
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
    });
  }
});
