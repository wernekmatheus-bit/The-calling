import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { Resend } from "npm:resend";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

declare const Deno: any;

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

interface RequestBody {
  event_type: 'BADGE_EARNED' | 'PRAYER_RECEIVED' | 'STREAK_LOST_CHECK';
  user_id?: string;
  [key: string]: any;
}

serve(async (req) => {
  try {
    const { event_type, ...payload }: RequestBody = await req.json();
    console.log(`Processing event: ${event_type}`, payload);

    switch (event_type) {
      
      case 'BADGE_EARNED': {
        // Fetch User Email
        const { data: user, error } = await supabase.auth.admin.getUserById(payload.user_id);
        if (error || !user.user) throw new Error("User not found");

        await resend.emails.send({
          from: 'The Calling <angels@yourdomain.com>',
          to: user.user.email!,
          subject: 'A New Virtue Has Been Recognized',
          html: `<p>Rejoice! You have earned a new badge on your path to sanctity.</p>`
        });
        break;
      }

      case 'PRAYER_RECEIVED': {
        // Logic to fetch prayer owner email would go here
        // ...
        break;
      }

      case 'STREAK_LOST_CHECK': {
        // 1. Find inactive users (Simple SQL query via Supabase RPC or direct select)
        // This is a simplified logic. In production, use specific timestamps.
        const { data: inactiveUsers, error } = await supabase
            .from('profiles')
            .select('id, last_access, auth_users(email)') // inner join
            .lt('last_access', new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString()) // older than 48h
            .limit(50); // Batch size

        if (inactiveUsers) {
             for (const p of inactiveUsers) {
                 // Send re-engagement email
                 await resend.emails.send({
                    from: 'The Calling <angels@yourdomain.com>',
                    to: p.auth_users.email,
                    subject: 'The flame flickers...',
                    html: `<p>Your prayer streak is at risk. Return to the altar.</p>`
                 });
             }
        }
        break;
      }

      default:
        throw new Error("Unknown event type");
    }

    return new Response(JSON.stringify({ status: "success" }), {
      headers: { "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});