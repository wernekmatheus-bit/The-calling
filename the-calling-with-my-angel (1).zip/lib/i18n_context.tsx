import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { LanguageCode } from '../types';

// Expanded dictionary with ALL Content Keys for ALL languages
const dictionary = {
  en: {
    appTitle: "The Calling With My Angel",
    welcome: "Welcome back",
    subtitle: "Enter the sanctuary",
    email: "Email Address",
    password: "Password",
    signIn: "Enter Sanctuary",
    access: "Enter Now",
    magicLink: "Enter Now",
    or: "or",
    footer: "By invitation only. A sacred space for spiritual growth.",
    logout: "Depart",
    error_whitelist: "Access Denied: This email has not been granted entry.",
    language_select: "Language",
    
    // Auth
    auth_check_email: "Checking access...",
    auth_link_sent: "Access Granted.",
    auth_link_desc: "Entering the sanctuary...",
    auth_back: "Try different email",

    // Navigation
    nav_dashboard: "Altar",
    nav_bible: "Scripture",
    nav_journey: "Journey",
    nav_community: "Community",
    nav_confess: "Confess",
    nav_profile: "Profile",
    nav_courses: "Courses",
    nav_status_label: "Status",
    open_video_course: "Open Video Course",

    // Dashboard
    dash_loading: "Loading Sanctuary...",
    dash_header: "Today's Commitment",
    dash_sub: "Complete your tasks to ascend.",
    dash_confess_card_title: "The Confessional",
    dash_confess_card_desc: "Unburden your soul in sacred anonymity.",
    dash_confess_card_btn: "Enter Sanctuary",
    dash_courses_title: "Sacred Studies",
    dash_courses_desc: "Access the ancient wisdom and video teachings.",
    dash_courses_btn: "Open Library",
    dash_empatia_title: "Sympathies",
    dash_empatia_desc: "Practices for Love, Prosperity & Protection.",
    dash_empatia_btn: "Open",
    
    // Dashboard Tags
    tag_simpatia: "Sympathy",
    tag_access: "Access",
    tag_private: "Private",

    task_morning_prayer: "Morning Prayer 🕊️",
    task_desc_morning: "Start the day connecting with the divine presence for 5 minutes.",
    
    task_sacred_study: "Sacred Study 📖",
    task_desc_study: "Read one chapter of wisdom to feed your intellect.",
    
    task_temple_care: "Temple Care (Workout) 🏃",
    task_desc_temple: "Honor the vessel God gave you with 30 mins of activity.",
    
    task_hard_task: "The Hard Task ⚔️",
    task_desc_hard: "Do the one thing you are avoiding today to build will.",
    
    task_gratitude: "Gratitude Log 🙏",
    task_desc_gratitude: "List 3 graces received today before sleeping.",
    
    // Hard Task Explanation
    hard_task_title: "What is 'The Hard Task'?",
    hard_task_desc: "It is an act of voluntary discipline to sharpen the spirit. Choose one act today that you are avoiding or that requires willpower.",
    hard_task_examples: "Examples: A cold shower, a difficult conversation, 30 minutes of deep work without phone, fasting from sugar.",
    hard_task_btn: "I Understand",

    msg_discipline: "Discipline Recorded",
    msg_offering_accepted: "Commitment Accepted",
    msg_offering_desc: "The Angels rejoice in your dedication!",
    verse_1_text: "You are the light of the world. A town built on a hill cannot be hidden.",
    verse_1_ref: "Matthew 5:14",
    verse_2_text: "For he will command his angels concerning you to guard you in all your ways.",
    verse_2_ref: "Psalm 91:11",
    verse_3_text: "Be strong and courageous. Do not be afraid; do not be discouraged.",
    verse_3_ref: "Joshua 1:9",

    // Chatbot
    chat_title: "Spiritual Guide",
    chat_subtitle: "Ask for guidance or strength",
    chat_placeholder: "Ask Seraphim...",
    chat_thinking: "Consulting the archives...",
    chat_empty_state: "Ask and it will be given to you; seek and you will find.",
    chat_product_rec: "Recommended for your energy",

    // Empatia (New Feature) - Now Simpatia
    empatia_title: "Sacred Sympathies",
    empatia_subtitle: "Choose your intention to receive divine alignment.",
    empatia_cat_love: "Love & Union",
    empatia_cat_prosperity: "Prosperity & Wealth",
    empatia_cat_protection: "Divine Protection",
    empatia_cat_health: "Health & Healing",
    
    // Empatia Subcategories
    empatia_sub_love_improve: "Strengthen Current Relationship",
    empatia_sub_love_new: "Attract New Love",
    empatia_sub_love_conquer: "Conquer Specific Heart",
    
    empatia_sub_pros_job: "New Employment",
    empatia_sub_pros_debt: "Clear Debts",
    empatia_sub_pros_flow: "Increase Abundance",

    empatia_sub_prot_env: "Cleansing the Home",
    empatia_sub_prot_evil: "Ward off Evil Eye",
    empatia_sub_prot_peace: "Inner Peace",

    empatia_checkout_title: "Unlock Sacred Sympathy",
    empatia_checkout_desc: "To perform this ancient Sympathy, a material sacrifice is required to prove your intent.",
    empatia_unlock_btn: "Unlock Sympathy ($19.90)",
    empatia_content_title: "Sympathy Revealed",
    empatia_content_step_1: "Preparation",
    empatia_content_step_2: "The Act",
    empatia_content_step_3: "A Oração",

    // Bible Reader
    bible_quiz_title: "What burdens your spirit?",
    bible_quiz_sub: "Select an area to receive divine guidance.",
    bible_topic_finance: "Finance & Prosperity",
    bible_topic_finance_desc: "Wisdom of Solomon for wealth.",
    bible_topic_love: "Love & Relationships",
    bible_topic_love_desc: "Divine understanding of union.",
    bible_topic_anxiety: "Anxiety & Fear",
    bible_topic_anxiety_desc: "Prayers for protection and peace.",
    bible_topic_wisdom: "Purpose & Direction",
    bible_topic_wisdom_desc: "Finding meaning in chaos.",
    bible_topic_family: "Family & Heritage",
    bible_topic_family_desc: "Roots of lineage and promises.",
    bible_btn_reveal: "Reveal My Path",
    bible_current_journey: "Current Journey",
    bible_continue_btn: "Mark Day Complete",
    bible_complete_toast: "Day Completed! +50 XP",
    bible_book_finished: "Book Completed! Starting next path...",
    bible_reset_btn: "Change Path",
    bible_leaderboard_text: "You are in the top 5% of readers today.",
    bible_streak_label: "Streak",
    bible_year_title: "Biblical Year",
    bible_chapters_read: "chapters read",
    bible_keep_fire: "Keep the holy fire burning",
    bible_reset_confirm: "Are you sure you want to choose a new path? Your progress on this book will be reset.",
    bible_chapter_indicator: "Chapter {current} of {total}",
    bible_select_book: "Select a Book",
    bible_loading_text: "Consulting the scriptures...",
    bible_chapters_count: "{count} Chapters",
    bible_next_btn: "Next",
    bible_prev_btn: "Prev",
    bible_reading_mode: "Reading Mode",
    
    // AI Modal
    ai_modal_title: "Divine Insight",
    ai_modal_desc: "Ask for a spiritual summary and practical application of this chapter.",
    ai_modal_btn: "Reveal Wisdom",
    ai_modal_thinking: "Consulting the archives...",
    ai_modal_error: "Could not connect to the divine archives.",

    // Bible Books
    bible_book_proverbs: "Proverbs",
    bible_book_song_of_solomon: "Song of Solomon",
    bible_book_psalms: "Psalms",
    bible_book_ecclesiastes: "Ecclesiastes",
    bible_book_genesis: "Genesis",
    bible_book_exodus: "Exodus",
    bible_book_leviticus: "Leviticus",
    bible_book_numbers: "Numbers",
    bible_book_deuteronomy: "Deuteronomy",
    bible_book_joshua: "Joshua",
    bible_book_matthew: "Matthew",
    bible_book_mark: "Mark",
    bible_book_luke: "Luke",
    bible_book_john: "John",
    bible_book_revelation: "Revelation",

    // Journey General
    journey_title: "Your Sacred Path",
    journey_phase_rest: "Resting Phase",
    journey_phase_open: "Path Open",
    journey_level: "Level",
    journey_day: "Day",
    journey_available_in: "Available in",
    journey_vow_title: "Daily Vow",
    journey_btn_fulfill: "I Have Fulfilled My Vow",
    journey_toast_fulfilled: "Vow Fulfilled",
    journey_toast_desc: "The path expands before you.",
    journey_wait_title: "The spirit needs rest.",
    journey_wait_desc: "The next seal opens in {hours} hours.",
    journey_leaderboard_title: "Ascended Souls",
    journey_task_label: "Sacred Task",
    journey_locked_label: "Upcoming Seal",
    journey_locked_desc: "Complete the previous days to unlock this mystery.",
    journey_tap_instruction: "Tap the glowing seal to view your task.",

    // JOURNEY DAYS (SPECIFIC)
    journey_d1_title: "The Awakening of the Soul",
    journey_d1_task: "Find a white candle. Light it in a dark room and stare at the flame for 5 minutes, asking your Guardian Angel to reveal their presence.",
    journey_d1_prayer: "Angel of God, my guardian dear, to whom God's love commits me here...",

    journey_d2_title: "The Cleansing of the Vessel",
    journey_d2_task: "Write down three regrets on a piece of paper. Burn the paper safely or tear it into small pieces and bury it, symbolizing the release of past burdens.",
    journey_d2_prayer: "Create in me a pure heart, O God, and renew a steadfast spirit within me.",

    journey_d3_title: "The Water of Life",
    journey_d3_task: "Drink a glass of water slowly, blessing each sip. Visualize the water cleansing your spirit from the inside out.",
    journey_d3_prayer: "Let your grace flow through me like a living river.",

    journey_d4_title: "The Act of Silence",
    journey_d4_task: "Spend 15 minutes in absolute silence. No phone, no music. Just listen to the silence of the room and your own breath.",
    journey_d4_prayer: "Speak Lord, for your servant is listening.",
    
    journey_generic_title: "The Path of Perseverance",
    journey_generic_task: "Recite Psalm 23 three times and offer a specific sacrifice of comfort (e.g., skip dessert, cold shower) for someone you love.",
    journey_generic_prayer: "The Lord is my shepherd, I lack nothing.",

    // Daily Prayers
    journey_prayer_1: "Lord, grant me the strength to accept the things I cannot change, the courage to change the things I can, and the wisdom to know the difference.",
    journey_prayer_2: "Divine Light, guide my steps today. Let my words be kind, my actions be just, and my heart be open to your grace.",
    journey_prayer_3: "In the silence of this morning, I seek your presence. Fill me with peace that I may share it with everyone I meet.",
    journey_prayer_4: "May I be a vessel of your love today. Protect me from shadows and lead me towards the eternal light.",
    journey_prayer_5: "Give me the eyes to see the beauty in every soul and the patience to understand what is hidden.",
    journey_prayer_6: "I surrender my worries to you. Let your will be done in my life, for I trust in your infinite plan.",
    journey_prayer_7: "Bless my work and my rest. Let everything I do be an offering of gratitude for the gift of life.",

    // Community
    comm_prayer_circle: "Sanctuary of Prayer",
    comm_angels_now: "Angels Interceding Now",
    comm_btn_enter: "Enter Prayer Circle (5 min)",
    comm_wall_title: "The Prayer Wall",
    comm_wall_sub: "Carry each other’s burdens, and in this way you will fulfill the law of Christ.",
    comm_intercessors: "Intercessors",
    comm_btn_pray: "Pray",
    comm_btn_sent: "Sent",
    comm_guardians: "Guardians of the Week",
    comm_top_intercessors: "Top Intercessors",
    comm_did_you_know: "Did you know?",
    comm_stat_desc: "The collective prayer of the community has reached 12,403 intercessions this month alone.",
    comm_amen: "Amen",
    comm_remains: "Remains",
    comm_return: "Return to Sanctuary",
    comm_be_first: "The week is young. Be the first.",
    comm_placeholder: "Share your burden or gratitude...",
    comm_ask_btn: "Ask for Intercession",
    comm_empty_wall: "The wall is silent. Be the first to speak.",
    comm_anonymous: "Post Anonymously",
    comm_anonymous_user: "Anonymous Soul", // NEW
    comm_add_friend: "Add Friend",
    comm_req_sent: "Request Sent",
    
    // Prayer Circle Quotes
    prayer_quote_1: "Where two or three gather in my name, there am I with them.",
    prayer_quote_2: "Prayer is the wing wherewith the soul flies to heaven.",
    prayer_quote_3: "Be still, and know that I am God.",
    prayer_quote_4: "The light of the body is the eye: if therefore thine eye be single, thy whole body shall be full of light.",
    prayer_quote_5: "In the silence of the heart, God speaks.",

    // Profile & Social - NEW MEDAL SYSTEM TRANSLATIONS
    prof_streak: "Consecutive Days",
    prof_intercessions: "Intercessions Made",
    prof_status: "Current Status",
    prof_lvl: "Lvl",
    prof_to_ascend: "to Next Medal",
    prof_max_level: "Max Medal",
    
    // RANKS
    prof_rank_novice: "Novice Spirit",
    prof_rank_desc_novice: "The journey of a thousand miles begins with a single prayer.",
    
    prof_rank_copper: "Copper Disciple",
    prof_rank_desc_copper: "Conducting the first sparks of divine energy.",
    
    prof_rank_bronze: "Bronze Guardian",
    prof_rank_desc_bronze: "Standing firm against the winds of doubt.",
    
    prof_rank_iron: "Iron Warrior",
    prof_rank_desc_iron: "Forged in the fires of persistence and faith.",
    
    prof_rank_silver: "Silver Sentinel",
    prof_rank_desc_silver: "Reflecting the pure light of the heavens.",
    
    prof_rank_gold: "Golden Seraph",
    prof_rank_desc_gold: "Radiating divine warmth to all who are near.",
    
    prof_rank_platinum: "Platinum Archangel",
    prof_rank_desc_platinum: "A pillar of the sanctuary, unshakeable and pure.",
    
    prof_rank_diamond: "Diamond Ascendant",
    prof_rank_desc_diamond: "A soul as clear and unbreakable as the eternal truth.",

    prof_quote: "The one who prays for others is heard for himself.",
    prof_courses_title: "My Enrollments",
    prof_tab_overview: "Overview",
    prof_tab_achievements: "Achievements",
    prof_tab_friends: "Friends",
    prof_tab_requests: "Requests",
    prof_edit_profile: "Edit Profile",
    prof_save_changes: "Save Changes",
    prof_change_photo: "Change Photo",
    prof_name_label: "Spiritual Name",
    prof_friends_empty: "No spiritual companions yet.",
    prof_requests_empty: "No pending requests.",
    prof_accept: "Accept",
    prof_reject: "Decline",
    prof_ach_scholar: "Scholar of the Word",
    prof_ach_warrior: "Prayer Warrior",
    prof_ach_pilgrim: "Dedicated Pilgrim",
    prof_ach_desc_scholar: "Read 5 Chapters",
    prof_ach_desc_warrior: "10 Intercessions",
    prof_ach_desc_pilgrim: "Reaching Level 5",

    // Confessional
    confess_title: "The Confessional",
    confess_return: "Return",
    confess_status: "Sacred Channel Active",
    confess_placeholder: "Confess your burden...",
    confess_wisdom_sealed: "Wisdom Sealed",
    confess_sacrifice_text: "This guidance requires a sacrifice of value to be received.",
    confess_unlock: "Unlock Offering",
    confess_initial_ai: "I am listening, my child. What burden do you carry today?",
    confess_typing: "Typing...",
    confess_wisdom_revealed: "Wisdom Revealed",

    // Courses List
    courses_title: "The Library of Light",
    courses_subtitle: "Ancient wisdom for the modern soul.",
    course_btn_start: "Enter Course",
    course_btn_locked: "Unlock Access ($49)",
    course_modules_count: "Modules",

    // UPDATED COURSES
    course_hermetic_title: "The 7 Hidden Hermetic Laws",
    course_hermetic_desc: "Master the universal laws that govern reality and manifest your divine purpose.",
    
    course_morning_title: "Millionaire’s Morning Ritual",
    course_morning_desc: "The sacred routine of kings and saints to align your spirit with abundance before dawn.",
    
    course_night_title: "Millionaire’s Night Ritual",
    course_night_desc: "Cleanse your spirit and program your subconscious for prosperity while you sleep.",
    
    course_michael_title: "Sacred Prayer to Saint Michael",
    course_michael_desc: "The ultimate spiritual defense. Invoke the Archangel for protection against all evil.",
    
    course_pio_healing_title: "Healing Journey With Padre Pio",
    course_pio_healing_desc: "Walk the path of the stigmatic saint to find miraculous healing for body and soul.",
    
    course_pio_lent_title: "Lent With Padre Pio",
    course_pio_lent_desc: "A 40-day journey of sacrifice and revelation through the eyes of the mystic.",


    // Course Viewer Defaults
    course_journey_begins: "The Journey Begins",
    course_wisdom: "Wisdom",
    course_artifacts: "Artifacts",
    course_about: "About this Lesson",
    course_no_artifacts: "No physical artifacts for this lesson. Focus on the internal spirit.",
    course_path_curriculum: "Path Curriculum",
    course_sacred_steps: "Sacred Steps",
    course_locked_desc: "This sacred seal unlocks in {days} days. Patience is a virtue.",
    course_upsell_title: "Ascend to the Next Level",
    course_upsell_desc: "You have completed the initial awakening. 'The Purification' awaits those who are ready.",
    course_upsell_btn: "Unlock The Purification",
    course_secure_checkout: "Secure Sanctuary Checkout",
    course_quote_silence: "\"True silence is not the absence of sound, but the presence of the Divine. Listen closely to what is not being said.\"",

    map_day: "DAY",
    bot_title: "Angelic Guide",
    bot_role: "Guardian",
    bot_initial_q: "I sense a weariness in your spirit. Is the burden of the world heavy today?",
    bot_btn_well: "I am well",
    bot_btn_tired: "I am weary",
    bot_pitch: "Even the strongest spirits need aid. This sacred essence has helped thousands restore their divine energy.",
    bot_product_name: "Angel Mastery Course",
    bot_view_product: "View Sacred Tool",
    bot_back: "Back",
  },
  
  pt: {
    appTitle: "O Chamado Com Meu Anjo",
    welcome: "Bem-vindo",
    subtitle: "Entre no santuário",
    email: "Endereço de Email",
    password: "Senha",
    signIn: "Entrar no Santuário",
    access: "Acessar Agora",
    magicLink: "Acessar Agora",
    or: "ou",
    footer: "Apenas por convite. Um espaço sagrado para crescimento espiritual.",
    logout: "Sair",
    error_whitelist: "Acesso Negado: Este email não possui permissão de entrada.",
    language_select: "Idioma",
    
    auth_check_email: "Verificando acesso...",
    auth_link_sent: "Acesso Permitido.",
    auth_link_desc: "Entrando no santuário...",
    auth_back: "Tentar outro email",

    nav_dashboard: "Altar",
    nav_bible: "Escritura",
    nav_journey: "Jornada",
    nav_community: "Comunidade",
    nav_confess: "Confessar",
    nav_profile: "Perfil",
    nav_courses: "Cursos",
    nav_status_label: "Status",
    open_video_course: "Abrir Curso em Vídeo",

    dash_loading: "Carregando Santuário...",
    dash_header: "Compromisso de Hoje", 
    dash_sub: "Complete seus compromissos para ascender.", 
    dash_confess_card_title: "O Confessionário",
    dash_confess_card_desc: "Desabafar sua alma em sagrado anonimato.",
    dash_confess_card_btn: "Entrar no Santuário",
    dash_courses_title: "Estudos Sagrados",
    dash_courses_desc: "Acesse a sabedoria antiga e os ensinamentos em vídeo.",
    dash_courses_btn: "Abrir Biblioteca",
    dash_empatia_title: "Simpatias", 
    dash_empatia_desc: "Simpatias para Amor, Prosperidade e Proteção.",
    dash_empatia_btn: "Abrir", 

    tag_simpatia: "Simpatia",
    tag_access: "Acesso",
    tag_private: "Privado",

    task_morning_prayer: "Oração Matinal 🕊️",
    task_desc_morning: "Inicie o dia conectando-se com a presença divina por 5 minutos.",
    
    task_sacred_study: "Estudo Sagrado 📖",
    task_desc_study: "Leia um capítulo de sabedoria para alimentar seu intelecto.",
    
    task_temple_care: "Cuidar do Templo (Treino) 🏃",
    task_desc_temple: "Honre o vaso que Deus lhe deu com 30 min de atividade.",
    
    task_hard_task: "A Tarefa Difícil ⚔️",
    task_desc_hard: "Faça a única coisa que você está evitando hoje para construir vontade.",
    
    task_gratitude: "Diario de Gratidão 🙏",
    task_desc_gratitude: "Liste 3 graças recebidas hoje antes de dormir.",
    
    // Hard Task Explanation
    hard_task_title: "O que é 'A Tarefa Difícil'?",
    hard_task_desc: "É um ato de disciplina voluntária para afiar o espírito. Escolha uma ação hoje que você está evitando ou que exija força de vontade.",
    hard_task_examples: "Exemplos: Um banho gelado, uma conversa difícil, 30 minutos de trabalho focado sem celular, jejum de açúcar.",
    hard_task_btn: "Entendido",

    msg_discipline: "Disciplina Registrada",
    msg_offering_accepted: "Compromisso Aceito", 
    msg_offering_desc: "Os Anjos se alegram com sua dedicação!",
    verse_1_text: "Vós sois a luz do mundo. Uma cidade edificada sobre um monte não pode ser escondida.",
    verse_1_ref: "Mateus 5:14",
    verse_2_text: "Porque aos seus anjos dará ordem a teu respeito, para te guardarem em todos os teus caminhos.",
    verse_2_ref: "Salmos 91:11",
    verse_3_text: "Sê forte e corajoso. Não temas; não te desanimes.",
    verse_3_ref: "Josué 1:9",

    chat_title: "Guia Espiritual",
    chat_subtitle: "Peça direção ou força",
    chat_placeholder: "Pergunte a Seraphim...",
    chat_thinking: "Consultando os arquivos...",
    chat_empty_state: "Pedi e vos será dado; buscai e achareis.",
    chat_product_rec: "Recomendado para sua energia",

    empatia_title: "Simpatias Sagradas",
    empatia_subtitle: "Escolha sua intenção para receber alinhamento divino.",
    empatia_cat_love: "Amor e União",
    empatia_cat_prosperity: "Prosperidade",
    empatia_cat_protection: "Proteção Divina",
    empatia_cat_health: "Saúde e Cura",
    
    empatia_sub_love_improve: "Melhorar Relacionamento Atual",
    empatia_sub_love_new: "Atrair Novo Amor",
    empatia_sub_love_conquer: "Conquistar Coração Específico",
    
    empatia_sub_pros_job: "Novo Emprego",
    empatia_sub_pros_debt: "Limpar Dívidas",
    empatia_sub_pros_flow: "Aumentar Abundância",

    empatia_sub_prot_env: "Limpeza do Lar",
    empatia_sub_prot_evil: "Afastar Mal-Olhado",
    empatia_sub_prot_peace: "Paz Interior",

    empatia_checkout_title: "Desbloquear Simpatia Sagrada",
    empatia_checkout_desc: "Para realizar esta antiga Simpatia, um sacrifício material é necessário para provar sua intenção.",
    empatia_unlock_btn: "Liberar Simpatia (R$ 19,90)",
    empatia_content_title: "Simpatia Revelada",
    empatia_content_step_1: "Preparação",
    empatia_content_step_2: "O Ato",
    empatia_content_step_3: "A Oração",

    bible_quiz_title: "O que aflige seu espírito?",
    bible_quiz_sub: "Selecione uma área para receber direção divina.",
    bible_topic_finance: "Finanças e Prosperidade",
    bible_topic_finance_desc: "Sabedoria de Salomão para riqueza.",
    bible_topic_love: "Amor e Relacionamentos",
    bible_topic_love_desc: "Entendimento divino da união.",
    bible_topic_anxiety: "Ansiedade e Medo",
    bible_topic_anxiety_desc: "Orações para proteção e paz.",
    bible_topic_wisdom: "Propósito e Direção",
    bible_topic_wisdom_desc: "Encontrando sentido no caos.",
    bible_topic_family: "Família e Herança",
    bible_topic_family_desc: "Raízes de linhagem e promessas.",
    bible_btn_reveal: "Revelar Meu Caminho",
    bible_current_journey: "Jornada Atual",
    bible_continue_btn: "Marcar Dia Concluído",
    bible_complete_toast: "Dia Concluído! +50 XP",
    bible_book_finished: "Livro Concluído! Iniciando novo caminho...",
    bible_reset_btn: "Trocar Caminho",
    bible_leaderboard_text: "Você está no top 5% dos leitores hoje.",
    bible_streak_label: "Sequência",
    bible_year_title: "Ano Bíblico",
    bible_chapters_read: "capítulos lidos",
    bible_keep_fire: "Mantenha o fogo santo ardendo",
    bible_reset_confirm: "Tem certeza que deseja escolher um novo caminho? Seu progresso neste livro será reiniciado.",
    bible_chapter_indicator: "Capítulo {current} de {total}",
    bible_select_book: "Selecionar Livro",
    bible_loading_text: "Consultando as escrituras...",
    bible_chapters_count: "{count} Capítulos",
    bible_next_btn: "Prox",
    bible_prev_btn: "Ant",
    bible_reading_mode: "Modo de Leitura",
    
    // AI Modal
    ai_modal_title: "Visão Divina",
    ai_modal_desc: "Peça um resumo espiritual e aplicação prática deste capítulo.",
    ai_modal_btn: "Revelar Sabedoria",
    ai_modal_thinking: "Consultando os arquivos...",
    ai_modal_error: "Não foi possível conectar aos arquivos divinos.",

    bible_book_proverbs: "Provérbios",
    bible_book_song_of_solomon: "Cânticos",
    bible_book_psalms: "Salmos",
    bible_book_ecclesiastes: "Eclesiastes",
    bible_book_genesis: "Gênesis",
    bible_book_exodus: "Êxodo",
    bible_book_leviticus: "Levítico",
    bible_book_numbers: "Números",
    bible_book_deuteronomy: "Deuteronômio",
    bible_book_joshua: "Josué",
    bible_book_matthew: "Mateus",
    bible_book_mark: "Marcos",
    bible_book_luke: "Lucas",
    bible_book_john: "João",
    bible_book_revelation: "Apocalipse",

    // JOURNEY TRANSLATIONS (FIXED)
    journey_title: "Seu Caminho Sagrado",
    journey_phase_rest: "Fase de Descanso",
    journey_phase_open: "Caminho Aberto",
    journey_level: "Nível",
    journey_day: "Dia",
    journey_available_in: "Disponível em",
    journey_vow_title: "Voto Diário",
    journey_btn_fulfill: "Eu Cumpri Meu Voto",
    journey_toast_fulfilled: "Voto Cumprido",
    journey_toast_desc: "O caminho se expande diante de você.",
    journey_wait_title: "O espírito precisa de descanso.",
    journey_wait_desc: "O próximo selo abre em {hours} horas.",
    journey_leaderboard_title: "Almas Ascendidas",
    journey_task_label: "Tarefa Sagrada",
    journey_locked_label: "Selo Futuro",
    journey_locked_desc: "Complete os dias anteriores para desbloquear este mistério.",
    journey_tap_instruction: "Toque no selo brilhante para ver sua tarefa.",

    // JOURNEY SPECIFIC DAYS
    journey_d1_title: "O Despertar da Alma",
    journey_d1_task: "Encontre uma vela branca. Acenda-a em um quarto escuro e olhe para a chama por 5 minutos, pedindo ao seu Anjo da Guarda que revele sua presença.",
    journey_d1_prayer: "Anjo de Deus, meu querido guardião, a quem o amor de Deus me confia aqui...",

    journey_d2_title: "A Limpeza do Vaso",
    journey_d2_task: "Escreva três arrependimentos em um papel. Queime o papel com segurança ou rasgue-o em pedaços pequenos e enterre-o, simbolizando a liberação de fardos passados.",
    journey_d2_prayer: "Cria em mim um coração puro, ó Deus, e renova dentro de mim um espírito inabalável.",

    journey_d3_title: "A Água da Vida",
    journey_d3_task: "Beba um copo de água lentamente, abençoando cada gole. Visualize a água limpando seu espírito de dentro para fora.",
    journey_d3_prayer: "Deixe tua graça fluir através de mim como um rio vivo.",

    journey_d4_title: "O Ato de Silêncio",
    journey_d4_task: "Passe 15 minutos em silêncio absoluto. Sem telefone, sem música. Apenas ouça o silêncio do quarto e sua própria respiração.",
    journey_d4_prayer: "Fala, Senhor, pois o teu servo ouve.",

    journey_generic_title: "O Caminho da Perseverança",
    journey_generic_task: "Recite o Salmo 23 três vezes e ofereça um sacrifício específico de conforto (ex: pular sobremesa, banho frio) por alguém que você ama.",
    journey_generic_prayer: "O Senhor é meu pastor, nada me faltará.",

    journey_prayer_1: "Senhor, concedei-me a serenidade para aceitar as coisas que não posso mudar, a coragem para mudar as coisas que posso, e a sabedoria para saber a diferença.",
    journey_prayer_2: "Luz Divina, guie meus passos hoje. Que minhas palavras sejam gentis, minhas ações justas e meu coração aberto à tua graça.",
    journey_prayer_3: "No silêncio desta manhã, busco tua presença. Enche-me de paz para que eu possa compartilhá-la com todos que encontrar.",
    journey_prayer_4: "Que eu seja um vaso do teu amor hoje. Protege-me das sombras e guia-me em direção à luz eterna.",
    journey_prayer_5: "Dá-me olhos para ver a beleza em cada alma e a paciência para entender o que está oculto.",
    journey_prayer_6: "Entrego minhas preocupações a ti. Seja feita a tua vontade em minha vida, pois confio em teu plano infinito.",
    journey_prayer_7: "Abençoa meu trabalho e meu descanso. Que tudo o que eu faça seja uma oferta de gratidão pelo dom da vida.",

    comm_prayer_circle: "Santuario de Oração",
    comm_angels_now: "Anjos Intercedendo Agora",
    comm_btn_enter: "Entrar na Roda (5 min)",
    comm_wall_title: "Mural de Oração",
    comm_wall_sub: "Carregai os fardos uns dos outros, e assim cumprireis a lei de Cristo.",
    comm_intercessors: "Intercessores",
    comm_btn_pray: "Orar",
    comm_btn_sent: "Enviado",
    comm_guardians: "Guardiões da Semana",
    comm_top_intercessors: "Top Intercessores",
    comm_did_you_know: "Você sabia?",
    comm_stat_desc: "A oração coletiva da comunidade atingiu 12.403 intercessões apenas este mês.",
    comm_amen: "Amém",
    comm_remains: "Restantes",
    comm_return: "Retornar ao Santuário",
    comm_be_first: "A semana é jovem. Seja o primeiro.",
    comm_placeholder: "Compartilhe seu fardo ou gratidão...",
    comm_ask_btn: "Pedir Intercessão",
    comm_empty_wall: "O mural está silencioso. Seja o primeiro a falar.",
    comm_anonymous: "Postar Anonimamente",
    comm_anonymous_user: "Alma Anônima", // NEW
    comm_add_friend: "Adicionar Amigo",
    comm_req_sent: "Solicitação Enviada",

    prayer_quote_1: "Onde estiverem dois ou três reunidos em meu nome, aí estou eu no meio deles.",
    prayer_quote_2: "A oração é a asa com a qual a alma voa para o céu.",
    prayer_quote_3: "Aquietai-vos, e sabei que eu sou Deus.",
    prayer_quote_4: "A candeia do corpo são os olhos; de sorte que, se os teus olhos forem bons, todo o teu corpo terá luz.",
    prayer_quote_5: "No silêncio do coração, Deus fala.",

    prof_streak: "Dias Consecutivos",
    prof_intercessions: "Intercessões Feitas",
    prof_status: "Status Atual",
    prof_lvl: "Nvl",
    prof_to_ascend: "para Próxima Medalha",
    prof_max_level: "Medalha Máxima",
    
    // RANKS - NEW GRANULAR SYSTEM
    prof_rank_novice: "Espírito Aprendiz",
    prof_rank_desc_novice: "A jornada de mil milhas começa com uma única oração.",
    
    prof_rank_copper: "Discípulo de Cobre",
    prof_rank_desc_copper: "Conduzindo as primeiras faíscas da energia divina.",
    
    prof_rank_bronze: "Guardião de Bronze",
    prof_rank_desc_bronze: "Mantendo-se firme contra os ventos da dúvida.",
    
    prof_rank_iron: "Guerreiro de Ferro",
    prof_rank_desc_iron: "Forjado no fogo da persistência e fé.",
    
    prof_rank_silver: "Sentinela de Prata",
    prof_rank_desc_silver: "Refletindo a luz pura dos céus.",
    
    prof_rank_gold: "Serafim Dourado",
    prof_rank_desc_gold: "Irradiando calor divino a todos que estão próximos.",
    
    prof_rank_platinum: "Arcanjo de Platina",
    prof_rank_desc_platinum: "Um pilar do santuário, inabalável e puro.",
    
    prof_rank_diamond: "Ascendente de Diamante",
    prof_rank_desc_diamond: "Uma alma tão clara e inquebrável quanto a verdade eterna.",

    prof_quote: "Aquele que ora pelos outros é ouvido por si mesmo.",
    prof_courses_title: "Minhas Inscrições",
    prof_tab_overview: "Visão Geral",
    prof_tab_achievements: "Conquistas",
    prof_tab_friends: "Amigos",
    prof_tab_requests: "Solicitações",
    prof_edit_profile: "Editar Perfil",
    prof_save_changes: "Salvar Alterações",
    prof_change_photo: "Alterar Foto",
    prof_name_label: "Nome Espiritual",
    prof_friends_empty: "Sem companheiros espirituais ainda.",
    prof_requests_empty: "Sem solicitações pendentes.",
    prof_accept: "Aceitar",
    prof_reject: "Recusar",
    prof_ach_scholar: "Erudito da Palavra",
    prof_ach_warrior: "Guerreiro de Oração",
    prof_ach_pilgrim: "Peregrino Dedicado",
    prof_ach_desc_scholar: "Leu 5 Capítulos",
    prof_ach_desc_warrior: "10 Intercessões",
    prof_ach_desc_pilgrim: "Alcançou Nível 5",

    confess_title: "O Confessionário",
    confess_return: "Retornar",
    confess_status: "Canal Sagrado Ativo",
    confess_placeholder: "Confesse seu fardo...",
    confess_wisdom_sealed: "Sabedoria Selada",
    confess_sacrifice_text: "Esta orientação requer um sacrifício de valor para ser recebida.",
    confess_unlock: "Oferenda de Desbloqueio",
    confess_initial_ai: "Estou ouvindo, meu filho. Qual fardo você carrega hoje?",
    confess_typing: "Digitando...",
    confess_wisdom_revealed: "Sabedoria Revelada",

    courses_title: "A Biblioteca de Luz",
    courses_subtitle: "Sabedoria antiga para a alma moderna.",
    course_awakening_title: "O Despertar",
    course_awakening_desc: "A fundação da conexão angelical. Aprenda a silenciar a mente e preparar o vaso.",
    course_purification_title: "A Purificação",
    course_purification_desc: "Técnicas avançadas para limpeza do espírito e quebra de correntes geracionais.",
    course_btn_start: "Entrar no Curso",
    course_btn_locked: "Desbloquear Acesso ($49)",
    course_modules_count: "Módulos",

    course_journey_begins: "A Jornada Começa",
    course_wisdom: "Sabedoria",
    course_artifacts: "Artefatos",
    course_about: "Sobre esta Lição",
    course_no_artifacts: "Sem artefatos físicos para esta lição. Foco no espírito interno.",
    course_path_curriculum: "Currículo do Caminho",
    course_sacred_steps: "Passos Sagrados",
    course_locked_desc: "Este selo sagrado abre em {days} dias. Paciência é uma virtude.",
    course_upsell_title: "Ascenda ao Próximo Nível",
    course_upsell_desc: "Você completou o despertar inicial. 'A Purificação' aguarda aqueles que estão prontos.",
    course_upsell_btn: "Desbloquear A Purificação",
    course_secure_checkout: "Checkout Seguro do Santuário",
    course_quote_silence: "\"O verdadeiro silêncio não é a ausência de som, mas a presença do Divino. Ouça atentamente o que não está sendo dito.\"",

    map_day: "DIA",
    bot_title: "Guia Angelical",
    bot_role: "Guardian",
    bot_initial_q: "Sinto um cansaço em seu espírito. O fardo do mundo está pesado hoje?",
    bot_btn_well: "Estou bem",
    bot_btn_tired: "Estou cansado",
    bot_pitch: "Mesmo os espíritos mais fortes precisam de ajuda. Esta essência sagrada ajudou milhares a restaurar sua energia divina.",
    bot_product_name: "Curso Maestria dos Anjos",
    bot_view_product: "Ver Ferramenta Sagrada",
    bot_back: "Voltar",
  },
  
  es: {
      appTitle: "El Llamado con Mi Ángel",
      welcome: "Bienvenido de nuevo",
      subtitle: "Entra al santuario",
      email: "Correo Electrónico",
      password: "Contraseña",
      signIn: "Entrar al Santuario",
      access: "Acceder Ahora",
      // ... (Fallback to keys or English for missing items to ensure app doesn't crash)
      nav_dashboard: "Altar",
      dash_header: "Compromiso de Hoy",
      dash_sub: "Completa tus tareas para ascender.",
      task_morning_prayer: "Oración Matutina 🕊️",
      task_sacred_study: "Estudio Sagrado 📖",
      task_temple_care: "Cuidado del Templo 🏃",
      task_hard_task: "La Tarea Difícil ⚔️",
      task_gratitude: "Diario de Gratitud 🙏",
      dash_empatia_title: "Simpatías",
      dash_empatia_desc: "Prácticas para Amor, Prosperidad y Protección.",
      dash_empatia_btn: "Abrir",
      tag_simpatia: "Simpatía",
      tag_access: "Acceso",
      tag_private: "Privado",
      
      // Journey
      journey_title: "Tu Camino Sagrado",
      journey_d1_title: "El Despertar del Alma",
      journey_d1_task: "Encuentra una vela blanca. Enciéndela en una habitación oscura y mira la llama durante 5 minutos, pidiendo a tu Ángel de la Guarda que revele su presencia.",
      journey_task_label: "Tarea Sagrada",
      journey_locked_label: "Sello Futuro",
      journey_tap_instruction: "Toca el sello brillante para ver tu tarea.",
      comm_anonymous_user: "Alma Anónima",
      chat_empty_state: "Pedid, y se os dará; buscad, y hallaréis.",
  }
};

interface I18nContextProps {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: keyof typeof dictionary['en'] | string, params?: Record<string, string | number>) => string;
}

const I18nContext = createContext<I18nContextProps | undefined>(undefined);

export const I18nProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<LanguageCode>('en');

  // Load language from LocalStorage on mount, OR detect browser language
  useEffect(() => {
    const saved = localStorage.getItem('app_language') as LanguageCode;
    
    if (saved && dictionary[saved]) {
      setLanguageState(saved);
    } else {
        // AUTOMATIC BROWSER DETECTION
        const browserLang = navigator.language.split('-')[0] as LanguageCode;
        if (dictionary[browserLang]) {
            setLanguageState(browserLang);
        } else {
            setLanguageState('en');
        }
    }
  }, []);

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
    localStorage.setItem('app_language', lang); // Persist selection
  };

  const t = (key: string, params?: Record<string, string | number>) => {
    // 1. Get dictionary for language
    const langDict = dictionary[language] as Record<string, string> | undefined;
    const enDict = dictionary['en'] as Record<string, string>;
    
    // 2. Find translation or fallback
    // Try current language -> Try English -> Return Key
    let translation = langDict?.[key] || enDict?.[key] || key;

    // 3. Replace parameters (e.g., {hours})
    if (params) {
      Object.entries(params).forEach(([paramKey, paramValue]) => {
        translation = translation.replace(`{${paramKey}}`, String(paramValue));
      });
    }

    return translation;
  };

  return (
    <I18nContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </I18nContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useTranslation must be used within an I18nProvider');
  }
  return context;
};