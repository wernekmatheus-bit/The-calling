
import { Crown, Shield, Sword, Sparkles } from 'lucide-react';

export interface Rank {
  id: string;
  titleKey: string;
  min: number;
  max: number;
  color: string;
  bg: string;
  icon: any;
  shadow?: string;
}

export const RANKS: Rank[] = [
  {
    id: 'novice',
    titleKey: 'prof_rank_novice',
    min: 0,
    max: 4,
    color: 'text-stone-400',
    bg: 'bg-stone-100',
    icon: Sparkles
  },
  {
    id: 'copper',
    titleKey: 'prof_rank_copper',
    min: 5,
    max: 14,
    color: 'text-orange-700',
    bg: 'bg-orange-100',
    icon: Shield
  },
  {
    id: 'bronze',
    titleKey: 'prof_rank_bronze',
    min: 15,
    max: 29,
    color: 'text-amber-700',
    bg: 'bg-amber-100',
    icon: Shield
  },
  {
    id: 'iron',
    titleKey: 'prof_rank_iron',
    min: 30,
    max: 49,
    color: 'text-slate-600',
    bg: 'bg-slate-200',
    icon: Sword
  },
  {
    id: 'silver',
    titleKey: 'prof_rank_silver',
    min: 50,
    max: 74,
    color: 'text-slate-400',
    bg: 'bg-slate-100',
    icon: Shield
  },
  {
    id: 'gold',
    titleKey: 'prof_rank_gold',
    min: 75,
    max: 104,
    color: 'text-yellow-500',
    bg: 'bg-yellow-50',
    icon: Crown,
    shadow: 'shadow-gold-glow'
  },
  {
    id: 'platinum',
    titleKey: 'prof_rank_platinum',
    min: 105,
    max: 149,
    color: 'text-cyan-500',
    bg: 'bg-cyan-50',
    icon: Crown,
    shadow: 'shadow-md'
  },
  {
    id: 'diamond',
    titleKey: 'prof_rank_diamond',
    min: 150,
    max: Infinity,
    color: 'text-blue-500',
    bg: 'bg-blue-50',
    icon: Sparkles,
    shadow: 'shadow-gold-glow animate-pulse'
  }
];

export const getRank = (count: number) => {
  const rank = RANKS.find(r => count >= r.min && count <= r.max) || RANKS[RANKS.length - 1];
  
  // Calculate Progress
  let progress = 0;
  let nextThreshold = rank.max + 1;
  
  if (rank.max === Infinity) {
    progress = 100;
  } else {
    const range = rank.max - rank.min + 1;
    const currentInRank = count - rank.min;
    progress = Math.min(100, (currentInRank / range) * 100);
  }

  return { rank, progress, nextThreshold };
};
