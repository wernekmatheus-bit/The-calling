// SECURITY CONFIGURATION
// ----------------------

// This is the "Universal Password" used by the frontend to authenticate whitelisted users automatically.
// Since we restrict access via the 'whitelist_customers' table, we simplify the UX by not requiring
// users to set their own passwords. The app handles this handshake invisibly.
//
// WARNING: If you change this, existing users will need to have their passwords reset in Supabase 
// or be deleted/recreated to match the new token.
export const SYSTEM_TOKEN = "sanctuary-entry-token-v2-fixed";

// Other global constants
export const APP_NAME = "The Calling";
export const SUPPORT_EMAIL = "angels@support.com";
