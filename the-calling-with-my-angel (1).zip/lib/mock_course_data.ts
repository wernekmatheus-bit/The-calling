import { subDays } from 'date-fns';

export interface Module {
  id: string;
  title: string;
  duration: string;
  videoUrl?: string; // Placeholder
  description: string;
  materials: { title: string; size: string }[];
}

export interface CourseData {
  id: string;
  title: string;
  modules: Module[];
}

export interface Enrollment {
  enrolledAt: Date;
}

// MOCK DATA GENERATOR
// Scenario: User enrolled 3 days ago.
// Logic: The last module of the current course requires 7 days. It should be LOCKED.

export const MOCK_ENROLLMENT: Enrollment = {
  enrolledAt: subDays(new Date(), 3) // 3 days ago
};

export const CURRENT_COURSE: CourseData = {
  id: '1',
  title: 'The Awakening',
  modules: [
    {
      id: 'm1',
      title: 'Module 1: The First Breath',
      duration: '12:40',
      description: 'Understanding the nature of the angelic hierarchy and your place within it.',
      materials: [{ title: 'Hierarchy Chart.pdf', size: '2.4 MB' }]
    },
    {
      id: 'm2',
      title: 'Module 2: Cleansing The Vessel',
      duration: '18:15',
      description: 'Preparing the body and mind for divine communication.',
      materials: [{ title: 'Fasting Guide.pdf', size: '1.1 MB' }]
    },
    {
      id: 'm3',
      title: 'Module 3: The Silent Prayer',
      duration: '14:20',
      description: 'Techniques for silent contemplation and listening.',
      materials: []
    },
    {
      id: 'm4',
      title: 'Module 4: The 7-Day Seal (Final)',
      duration: '22:00',
      description: 'This is the final seal of the Awakening phase. Requires 7 days of preparation.',
      materials: [{ title: 'The Seal Workbook.pdf', size: '5.0 MB' }]
    }
  ]
};

export const NEXT_COURSE: CourseData = {
  id: '2',
  title: 'The Purification',
  modules: [
    {
      id: 'n1',
      title: 'The Purification: Intro',
      duration: '10:00',
      description: 'Welcome to the next level of your journey.',
      materials: []
    }
  ]
};