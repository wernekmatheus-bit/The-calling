export const playAngelicChord = () => {
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    
    const ctx = new AudioContext();
    const now = ctx.currentTime;
    
    // E Major Chord (E4, G#4, B4, E5) + slight detuning for chorus effect
    const freqs = [329.63, 415.30, 493.88, 659.25]; 
    
    freqs.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.value = freq;
      
      // Envelope
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.1 / freqs.length, now + 0.1); // Attack
      gain.gain.exponentialRampToValueAtTime(0.001, now + 3); // Long Decay (Reverb-like)
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start(now);
      osc.stop(now + 3.1);
    });
  } catch (e) {
    console.error("Audio play failed", e);
  }
};