
import { createClient } from '@supabase/supabase-js';

// ==============================================================================
// CONFIGURAÇÃO DE CONEXÃO
// ==============================================================================

// URL do seu projeto
const supabaseUrl = process.env.REACT_APP_SUPABASE_URL || 'https://thheyseacdvqelualxqg.supabase.co'; 

// Chave Pública (Anon / Public)
// NOTA: Se o login falhar com "invalid key", vá em Settings > API e pegue a chave 'anon' que começa com "eyJ..."
const supabaseAnonKey = process.env.REACT_APP_SUPABASE_ANON_KEY || 'sb_publishable_Pz8Pm5zaGmkhxIC3pOYpjQ_VibqRs2I';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  }
});
