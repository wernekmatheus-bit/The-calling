
import React, { useEffect, useState, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { motion } from 'framer-motion';
import { 
  Flame, Loader2, PlayCircle, Edit2, Camera, X, BookOpen, Map, Zap, Medal, Sparkles, Check
} from 'lucide-react';
import { useTranslation } from '../lib/i18n_context';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Tabs } from '../components/ui/Tabs';
import { toast } from 'sonner';
import { getRank } from '../lib/gamification';

interface ProfileProps {
  onNavigate: (view: string) => void;
}

export const Profile: React.FC<ProfileProps> = ({ onNavigate }) => {
  const { t } = useTranslation();
  
  // State
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // SVG Configuration for Progress Circle
  const radius = 60;
  const circumference = 2 * Math.PI * radius;

  useEffect(() => {
    fetchProfileData();
  }, []);

  const fetchProfileData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        // Fetch Profile Data (including the new intercessions_count)
        const { data: profileData } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        const userData = {
          ...profileData,
          email: user.email,
          name: profileData?.name || user.email?.split('@')[0] || 'Seeker'
        };
        
        setProfile(userData);
        setEditName(userData.name);
        setAvatarUrl(userData.avatar_url || '');
      } else {
        // Fallback for Guest/Virtual Users
        setProfile({
          name: 'Guest Soul',
          current_streak: 1,
          intercessions_count: 12,
          xp: 0
        });
      }
    } catch (error) {
      console.error("Profile load failed", error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = async () => {
      try {
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
              await supabase.from('profiles').update({
                  name: editName,
                  avatar_url: avatarUrl
              }).eq('id', user.id);
              
              setProfile({ ...profile, name: editName, avatar_url: avatarUrl });
              setIsEditing(false);
              toast.success("Profile Updated");
          }
      } catch (e) {
          toast.error("Failed to update profile");
      }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}-${Math.random()}.${fileExt}`;
      const filePath = `${fileName}`;

      try {
          toast.loading("Uploading...");
          const { error: uploadError } = await supabase.storage
            .from('avatars')
            .upload(filePath, file);

          if (uploadError) throw uploadError;

          const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(filePath);
          setAvatarUrl(publicUrl);
          toast.dismiss();
          toast.success("Image Uploaded");
      } catch (error) {
          toast.dismiss();
          console.error(error);
          toast.error("Upload failed. Using random avatar.");
          setAvatarUrl(`https://ui-avatars.com/api/?name=${editName}&background=random&size=200`);
      }
  };

  const { rank, progress, nextThreshold } = getRank(profile?.intercessions_count || 0);
  const strokeDashoffset = circumference - (progress / 100) * circumference;
  const prayersNeeded = (nextThreshold) - (profile?.intercessions_count || 0);

  // --- ACHIEVEMENTS LOGIC ---
  const achievements = [
      {
          id: 'scholar',
          title: t('prof_ach_scholar'),
          desc: t('prof_ach_desc_scholar'),
          icon: BookOpen,
          unlocked: (profile?.bible_state?.completed_chapters?.length || 0) >= 5
      },
      {
          id: 'warrior',
          title: t('prof_ach_warrior'),
          desc: t('prof_ach_desc_warrior'),
          icon: Zap,
          unlocked: (profile?.intercessions_count || 0) >= 10
      },
      {
          id: 'pilgrim',
          title: t('prof_ach_pilgrim'),
          desc: t('prof_ach_desc_pilgrim'),
          icon: Map,
          unlocked: (profile?.level || 1) >= 5
      }
  ];

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <Loader2 className="w-10 h-10 text-angel-gold animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F9F7F2] pb-24 md:pb-12 pt-6 px-4 md:px-8 max-w-5xl mx-auto">
      
      {/* HEADER: AVATAR & RANK HERO */}
      <div className="glass-card rounded-3xl p-8 mb-8 relative overflow-hidden flex flex-col items-center justify-center text-center">
        
        {/* Ambient Background Glow based on Rank Color */}
        <div className={`absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 opacity-20 blur-[80px] rounded-full bg-gradient-to-br from-angel-gold/20 to-transparent pointer-events-none`}></div>

        <div className="absolute top-4 right-4 z-20">
            <button 
                onClick={() => setIsEditing(!isEditing)}
                className="p-2 rounded-full hover:bg-black/5 text-gray-500 transition-colors"
                title={t('prof_edit_profile')}
            >
                {isEditing ? <X className="w-5 h-5" /> : <Edit2 className="w-5 h-5" />}
            </button>
        </div>

        {/* Avatar with Progress Ring */}
        <div className="relative w-40 h-40 mb-6 flex items-center justify-center group">
          <svg className="absolute top-0 left-0 w-full h-full transform -rotate-90" viewBox="0 0 160 160">
             <circle cx="80" cy="80" r={radius} stroke="#e5e7eb" strokeWidth="4" fill="transparent" />
             <motion.circle
               initial={{ strokeDashoffset: circumference }}
               animate={{ strokeDashoffset }}
               transition={{ duration: 1.5, ease: "easeOut" }}
               cx="80" cy="80" r={radius}
               stroke="currentColor" strokeWidth="4" fill="transparent" strokeDasharray={circumference} strokeLinecap="round"
               className={`${rank.color} drop-shadow-md`}
             />
          </svg>

          <div className={`
             relative w-28 h-28 rounded-full overflow-hidden border-4 bg-white shadow-xl flex items-center justify-center z-10
             ${rank.id === 'diamond' ? 'border-cyan-200 shadow-gold-glow' : 'border-white'}
          `}>
             {profile?.avatar_url ? (
               <img src={profile.avatar_url} alt="Profile" className="w-full h-full object-cover" />
             ) : (
               <span className="font-serif text-4xl font-bold text-gray-300 select-none">
                 {(profile?.name || 'S').charAt(0).toUpperCase()}
               </span>
             )}
             
             {isEditing && (
                 <div 
                    className="absolute inset-0 bg-black/40 flex items-center justify-center cursor-pointer hover:bg-black/50 transition-colors z-20"
                    onClick={() => fileInputRef.current?.click()}
                 >
                     <Camera className="w-8 h-8 text-white" />
                     <input 
                        type="file" 
                        ref={fileInputRef} 
                        className="hidden" 
                        accept="image/*"
                        onChange={handleFileUpload}
                     />
                 </div>
             )}
          </div>
        </div>

        {/* Text Details / Edit Form */}
        {isEditing ? (
            <div className="flex flex-col gap-2 items-center w-full max-w-xs mb-6 z-20">
                <Input 
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    placeholder={t('prof_name_label')}
                    className="text-center font-serif text-xl"
                />
                <Button onClick={handleUpdateProfile} className="h-10 text-sm">
                    {t('prof_save_changes')}
                </Button>
            </div>
        ) : (
            <>
                <div className="flex items-center justify-center gap-2 mb-2">
                   <p className="text-gray-900 font-bold text-2xl font-serif tracking-tight">{profile?.name}</p>
                   {/* MEDAL NEXT TO NAME */}
                   <div className={`w-6 h-6 rounded-full ${rank.bg} flex items-center justify-center ${rank.shadow || ''}`} title={t(rank.titleKey)}>
                      <rank.icon className={`w-3.5 h-3.5 ${rank.color}`} />
                   </div>
                </div>
                
                <div className="flex items-center gap-2 mb-6">
                   <span className={`text-xs font-bold uppercase tracking-widest ${rank.color} px-3 py-1 rounded-full ${rank.bg}`}>
                     {t(rank.titleKey)}
                   </span>
                </div>
            </>
        )}

        {/* Next Medal Preview */}
        <div className="w-full max-w-sm">
           <div className="flex justify-between text-xs text-gray-400 uppercase font-bold tracking-widest mb-2">
              <span className="flex items-center gap-1">
                 <Medal className="w-3 h-3" /> 
                 Progress
              </span>
              
              {rank.max !== Infinity ? (
                 <span className="text-angel-gold flex items-center gap-1">
                    {prayersNeeded} {t('prof_to_ascend')}
                 </span>
              ) : (
                 <span>{t('prof_max_level')}</span>
              )}
           </div>
           
           <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden relative shadow-inner">
             {/* Removed external texture here */}
             <div className="absolute inset-0 opacity-10 bg-white/50"></div>
             <motion.div 
               className={`h-full ${rank.bg.replace('bg-', 'bg-gradient-to-r from-').replace('-100', '-300')} to-${rank.color.replace('text-', '')}`}
               initial={{ width: 0 }}
               animate={{ width: `${progress}%` }}
               transition={{ duration: 1 }}
             />
           </div>
        </div>
      </div>

      {/* TABS SECTION */}
      <div className="glass-card rounded-2xl p-6 min-h-[400px]">
          <Tabs 
            tabs={[
                {
                    id: 'overview',
                    label: t('prof_tab_overview'),
                    content: (
                        <div className="mt-6">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                                <motion.div whileHover={{ y: -5 }} className="bg-orange-50/50 p-6 rounded-2xl flex flex-col items-center justify-center text-center border border-orange-100">
                                    <Flame className="w-8 h-8 text-orange-500 mb-2" />
                                    <h3 className="text-2xl font-serif font-bold text-gray-900">{profile?.current_streak || 0}</h3>
                                    <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">{t('prof_streak')}</p>
                                </motion.div>
                                <motion.div whileHover={{ y: -5 }} className="bg-yellow-50/50 p-6 rounded-2xl flex flex-col items-center justify-center text-center border border-yellow-100">
                                    <Sparkles className="w-8 h-8 text-angel-gold mb-2" />
                                    <h3 className="text-2xl font-serif font-bold text-gray-900">{profile?.intercessions_count || 0}</h3>
                                    <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">{t('prof_intercessions')}</p>
                                </motion.div>
                                <motion.div whileHover={{ y: -5 }} className="bg-blue-50/50 p-6 rounded-2xl flex flex-col items-center justify-center text-center border border-blue-100">
                                    <div className={`w-8 h-8 rounded-full mb-2 ${rank.bg} shadow-sm flex items-center justify-center`}>
                                       <rank.icon className="w-4 h-4 text-white" />
                                    </div>
                                    <h3 className="text-lg font-serif font-bold text-gray-900 leading-tight px-2">{t(rank.titleKey)}</h3>
                                    <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold mt-1">{t('prof_status')}</p>
                                </motion.div>
                            </div>
                            
                            <motion.button
                                whileHover={{ scale: 1.01 }}
                                onClick={() => onNavigate('courses')}
                                className="w-full bg-white border border-gray-200 p-4 rounded-xl flex items-center justify-between group hover:border-angel-gold/30 transition-all"
                            >
                                <div className="flex items-center gap-4">
                                    <div className="w-10 h-10 bg-angel-gold/10 rounded-full flex items-center justify-center text-angel-gold">
                                        <PlayCircle className="w-5 h-5" />
                                    </div>
                                    <div className="text-left">
                                        <h3 className="font-serif font-bold text-gray-900">{t('prof_courses_title')}</h3>
                                    </div>
                                </div>
                                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center group-hover:bg-angel-gold group-hover:text-white transition-colors">
                                    <PlayCircle className="w-4 h-4" />
                                </div>
                            </motion.button>
                        </div>
                    )
                },
                {
                    id: 'achievements',
                    label: t('prof_tab_achievements'),
                    content: (
                        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                            {achievements.map(ach => (
                                <div key={ach.id} className={`p-4 rounded-xl border flex items-center gap-4 ${ach.unlocked ? 'bg-white border-angel-gold/30 shadow-sm' : 'bg-gray-50 border-gray-200 opacity-60 grayscale'}`}>
                                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${ach.unlocked ? 'bg-gradient-to-br from-angel-gold to-yellow-500 text-white' : 'bg-gray-200 text-gray-400'}`}>
                                        <ach.icon className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-gray-900">{ach.title}</h4>
                                        <p className="text-xs text-gray-500">{ach.desc}</p>
                                    </div>
                                    {ach.unlocked && <Check className="w-5 h-5 text-angel-gold ml-auto" />}
                                    {!ach.unlocked && <div className="w-5 h-5 ml-auto text-gray-400 text-xs font-bold uppercase">Locked</div>}
                                </div>
                            ))}
                        </div>
                    )
                }
            ]}
          />
      </div>

      {/* FOOTER QUOTE */}
      <div className="text-center opacity-60 mt-12">
        <p className="font-serif italic text-gray-500">
          "{t('prof_quote')}"
        </p>
        <div className="w-10 h-0.5 bg-angel-gold mx-auto mt-4 rounded-full"></div>
      </div>

    </div>
  );
};
