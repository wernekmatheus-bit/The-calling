
import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useTranslation } from '../lib/i18n_context';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { LanguageSwitcher } from '../components/LanguageSwitcher';
import { AlertCircle, Sparkles, ArrowRight, Zap } from 'lucide-react';
import { toast } from 'sonner';

interface AuthPageProps {
  onLoginSuccess: (email: string) => void;
  onGuestLogin?: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onLoginSuccess }) => {
  const { t } = useTranslation();
  
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<string>('');

  useEffect(() => {
    supabase.auth.signOut();
  }, []);

  const handleSilentAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setStatus('');

    const cleanEmail = email.trim().toLowerCase();

    if (!cleanEmail) {
      setError("Please enter your email address.");
      setLoading(false);
      return;
    }

    try {
      setStatus(t('auth_check_email') || "Consultando o Livro da Vida...");
      
      // 1. VERIFICAÇÃO DIRETA NO BANCO (Sem Edge Function)
      // Tenta encontrar o email na lista de permitidos
      const { data: whitelistUser, error: dbError } = await supabase
        .from('whitelist_customers')
        .select('transaction_id')
        .eq('email', cleanEmail)
        .maybeSingle();

      if (dbError) {
        console.error("Erro de Conexão:", dbError);
        // Se der erro 42P01, a tabela não existe. Se der 401, é permissão.
        if (dbError.code === '42501') {
             throw new Error("Erro de Permissão: Execute o script SQL atualizado no painel do Supabase.");
        }
        throw new Error("Falha na conexão. Verifique sua internet ou a chave API.");
      }

      if (!whitelistUser) {
        throw new Error(t('error_whitelist') || "Acesso Negado: Email não encontrado na lista.");
      }

      // 2. AUTENTICAÇÃO
      // Usamos o transaction_id como senha secreta
      const secretKey = whitelistUser.transaction_id || 'default-token';
      setStatus("Abrindo os portões...");

      // A. Tenta Login Normal
      const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
        email: cleanEmail,
        password: secretKey,
      });

      if (loginError) {
        // B. Se falhar o login, tenta criar a conta (Auto-Cadastro)
        if (loginError.message.includes('Invalid login') || loginError.message.includes('not found')) {
            setStatus("Registrando alma...");
            
            const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
              email: cleanEmail,
              password: secretKey,
              options: {
                data: { source: 'whitelist_auto' }
              }
            });

            if (signUpError) throw signUpError;
            
            // Se pedir confirmação de email
            if (signUpData.user && !signUpData.session) {
               throw new Error("A conta foi criada, mas o Supabase pede confirmação de email. Desative 'Confirm Email' no painel.");
            }
        } else {
           throw loginError;
        }
      }

      toast.success(t('auth_link_sent'), { icon: <Zap className="w-4 h-4 text-yellow-500"/> });
      // O App.tsx vai detectar a sessão automaticamente e redirecionar

    } catch (err: any) {
      console.error("Erro Auth:", err);
      setError(err.message || "Um erro inesperado ocorreu.");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center p-4 relative overflow-hidden bg-[#F9F7F2]">
      
      <div className="absolute top-6 right-6 z-50">
         <LanguageSwitcher />
      </div>

      <div className="absolute inset-0 z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[500px] h-[500px] rounded-full bg-yellow-200 opacity-20 blur-3xl"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] rounded-full bg-angel-gold opacity-10 blur-3xl"></div>
      </div>

      <div className="w-full max-w-md z-10 my-8">
        <div className="text-center mb-8">
           <div className="mx-auto h-16 w-16 bg-gradient-to-br from-angel-gold to-yellow-200 rounded-full flex items-center justify-center shadow-lg mb-4">
              <Sparkles className="h-8 w-8 text-white" />
           </div>
           <h1 className="text-3xl font-serif font-bold text-gray-900 tracking-tight text-shadow-sm">{t('appTitle')}</h1>
           <p className="text-angel-accent uppercase tracking-widest text-xs font-bold mt-2">{t('subtitle')}</p>
        </div>

        <div className="glass-card rounded-2xl p-8 shadow-2xl relative overflow-hidden">
          
          <h2 className="text-2xl font-serif text-gray-800 mb-6 text-center">
            {t('signIn')}
          </h2>
          
          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-md text-sm flex items-start gap-2 animate-in fade-in slide-in-from-top-2">
              <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSilentAuth} className="space-y-6">
            <Input 
              type="email" 
              label={t('email')}
              placeholder="client@gmail.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoFocus
              className="text-lg"
              disabled={loading}
            />

            <Button type="submit" isLoading={loading} className="mt-4 group h-12 text-lg">
              <span className="flex items-center gap-2">
                {loading ? (status || "Processando...") : t('access')}
                {!loading && <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform"/>}
              </span>
            </Button>
          </form>

        </div>
      </div>
    </div>
  );
};
