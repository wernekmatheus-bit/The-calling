
import React, { useState, useEffect } from 'react';
import { differenceInDays } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  PlayCircle, 
  Lock, 
  Hourglass, 
  Sparkles, 
  CheckCircle, 
  ChevronRight, 
  X,
  Loader2
} from 'lucide-react';
import { toast, Toaster } from 'sonner';

import { Tabs } from '../components/ui/Tabs';
import { Button } from '../components/ui/Button';
import { supabase } from '../lib/supabase';
import { useTranslation } from '../lib/i18n_context';

interface Module {
  id: string;
  title: any; // jsonb or string
  description: any; // jsonb or string
  duration: string;
  video_url: string;
  sort_order: number;
  unlock_days_required: number;
}

interface Course {
  id: string;
  title: any; // jsonb
  description: any; // jsonb
  modules: Module[];
}

export const CourseViewer: React.FC = () => {
  const { language, t } = useTranslation();
  
  // State
  const [course, setCourse] = useState<Course | null>(null);
  const [activeModule, setActiveModule] = useState<Module | null>(null);
  const [loading, setLoading] = useState(true);
  const [enrollmentDate, setEnrollmentDate] = useState<Date>(new Date());
  const [isUpsellOpen, setIsUpsellOpen] = useState(false);

  useEffect(() => {
    fetchCourseData();
  }, []);

  const fetchCourseData = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      // MOCK DATA STRUCTURING TO SATISFY REQUIREMENTS
      // Requirement: 4 Modules. 3 Open immediately. 4th locked for 7 days.
      // 5th item is Upsell (handled in render).
      
      const mockCourseId = 'awakening_v1';
      
      // 2. Get User Enrollment for ACCURATE Drip Logic
      let enrolledAt = new Date();
      if (user) {
        const { data: enrollment } = await supabase
          .from('user_enrollments')
          .select('enrolled_at')
          .eq('user_id', user.id)
          .eq('course_id', mockCourseId)
          .maybeSingle();

        if (enrollment) {
          enrolledAt = new Date(enrollment.enrolled_at);
        } else if (user) {
          // Auto-enroll logic for demo
          await supabase.from('user_enrollments').insert({ 
             user_id: user.id, 
             course_id: mockCourseId 
          });
        }
      }
      setEnrollmentDate(enrolledAt);

      // Construct Course Object with Translations
      const fullCourse: Course = {
        id: mockCourseId,
        title: { en: "The Awakening", pt: "O Despertar" },
        description: { en: "Foundation of connection.", pt: "Fundação da conexão." },
        modules: [
          {
            id: 'm1',
            sort_order: 1,
            title: { en: "The First Breath", pt: "Fundamentos da Respiração" },
            description: { en: "Learning to breathe with intention.", pt: "Aprendendo a respirar com intenção." },
            duration: "10 MIN",
            video_url: "",
            unlock_days_required: 0
          },
          {
            id: 'm2',
            sort_order: 2,
            title: { en: "Visualizing the Light", pt: "Visualizando a Luz" },
            description: { en: "Seeing with the third eye.", pt: "Vendo com o terceiro olho." },
            duration: "15 MIN",
            video_url: "",
            unlock_days_required: 0
          },
          {
            id: 'm3',
            sort_order: 3,
            title: { en: "Shadow Work", pt: "Trabalho com a Sombra" },
            description: { en: "Confronting internal demons.", pt: "Enfrentando seus demônios internos." },
            duration: "25 MIN",
            video_url: "",
            unlock_days_required: 0
          },
          {
            id: 'm4',
            sort_order: 4,
            title: { en: "The 7-Day Seal", pt: "O Selo de 7 Dias" },
            description: { en: "Final preparation for ascension.", pt: "Preparação final para a ascensão." },
            duration: "30 MIN",
            video_url: "",
            unlock_days_required: 7 // LOCKED FOR 7 DAYS
          }
        ]
      };

      setCourse(fullCourse);
      if (fullCourse.modules.length > 0) {
        setActiveModule(fullCourse.modules[0]);
      }

    } catch (error) {
      console.error("Course fetch error:", error);
      toast.error("Failed to load sacred teachings.");
    } finally {
      setLoading(false);
    }
  };

  const getLocalized = (json: any) => {
    if (!json) return '';
    if (typeof json === 'string') return json; // Handle string fallback
    return json[language] || json['en'] || 'Untitled';
  };

  // Logic: Locking
  const daysSinceEnrollment = differenceInDays(new Date(), enrollmentDate);

  const isModuleLocked = (module: Module) => {
    if (!module.unlock_days_required) return false;
    return daysSinceEnrollment < module.unlock_days_required;
  };

  const getDaysRemaining = (module: Module) => {
    return Math.max(0, (module.unlock_days_required || 0) - daysSinceEnrollment);
  };

  const handleModuleClick = (module: Module) => {
    if (isModuleLocked(module)) {
      const days = getDaysRemaining(module);
      toast.error("The Angels are preparing this lesson.", {
        description: t('course_locked_desc', { days }),
        icon: <Hourglass className="w-5 h-5 text-angel-gold" />,
        style: {
           background: '#fff',
           border: '1px solid #D4AF37',
           color: '#1A1A1A'
        }
      });
      return;
    }
    setActiveModule(module);
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <Loader2 className="w-10 h-10 text-angel-gold animate-spin" />
    </div>
  );

  if (!course || !activeModule) return (
    <div className="p-10 text-center text-gray-500 font-serif">The sanctuary is quiet. No teachings found.</div>
  );

  return (
    <div className="pb-24 md:pb-12 max-w-7xl mx-auto px-4 md:px-8 pt-6">
      <Toaster position="top-center" />

      {/* HEADER */}
      <div className="mb-8 border-b border-angel-gold/10 pb-6">
        <p className="text-angel-gold uppercase tracking-[0.2em] text-xs font-bold mb-2">{t('course_journey_begins')}</p>
        <h1 className="font-serif text-3xl md:text-5xl text-gray-900 font-bold tracking-tight">{getLocalized(course.title)}</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* LEFT COLUMN: PLAYER & TABS */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* VIDEO PLAYER */}
          <div className="w-full aspect-video bg-black rounded-2xl shadow-2xl overflow-hidden relative group border border-white/20">
             {/* Gradient Overlay */}
             <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-black/40 pointer-events-none z-10"></div>
             
             <div className="absolute inset-0 flex items-center justify-center z-20">
                <motion.div 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-24 h-24 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center border border-white/30 cursor-pointer shadow-[0_0_30px_rgba(255,255,255,0.1)] transition-all"
                >
                   <PlayCircle className="w-10 h-10 text-white fill-white/20 ml-1" />
                </motion.div>
             </div>
             
             <div className="absolute bottom-0 left-0 right-0 p-8 z-20 bg-gradient-to-t from-black/90 via-black/50 to-transparent">
                <p className="text-white font-serif text-2xl font-bold tracking-wide">{getLocalized(activeModule.title)}</p>
                <div className="flex items-center gap-2 mt-2">
                   <span className="text-angel-gold font-bold text-xs uppercase tracking-widest">{activeModule.duration}</span>
                   <span className="text-white/40 text-xs">•</span>
                   <span className="text-white/60 text-xs font-sans">Module {activeModule.sort_order}</span>
                </div>
             </div>
          </div>

          {/* TABS: SUMMARY & MATERIALS */}
          <div className="glass-card rounded-2xl p-8">
            <Tabs 
              tabs={[
                {
                  id: 'summary',
                  label: t('course_wisdom'),
                  content: (
                    <div className="prose prose-stone max-w-none mt-4">
                      <h3 className="font-serif text-xl mb-4 text-gray-900 font-bold">{t('course_about')}</h3>
                      <p className="text-gray-600 leading-relaxed font-sans text-base">{getLocalized(activeModule.description)}</p>
                      <div className="mt-8 p-6 bg-angel-gold/5 rounded-xl border border-angel-gold/20 flex gap-4 items-start">
                         <Sparkles className="w-5 h-5 text-angel-gold shrink-0 mt-1" />
                         <div>
                            <p className="text-sm text-angel-dark italic font-serif leading-relaxed">
                               {t('course_quote_silence')}
                            </p>
                         </div>
                      </div>
                    </div>
                  )
                },
                {
                  id: 'materials',
                  label: t('course_artifacts'),
                  content: (
                    <div className="space-y-4 mt-4">
                       <p className="text-gray-500 text-sm italic border-l-2 border-gray-200 pl-4">{t('course_no_artifacts')}</p>
                    </div>
                  )
                }
              ]}
            />
          </div>
        </div>

        {/* RIGHT COLUMN: MODULE LIST */}
        <div className="lg:col-span-1">
          {/* Changed sticky top value and max-height logic to prevent cutoff */}
          <div className="glass-card rounded-2xl overflow-hidden sticky top-8 border-angel-gold/10 flex flex-col max-h-[calc(100vh-100px)]">
            <div className="p-6 border-b border-gray-100 bg-white/40 backdrop-blur-md flex-shrink-0">
               <h3 className="font-serif font-bold text-gray-900 text-lg">{t('course_path_curriculum')}</h3>
               <p className="text-xs text-angel-gold uppercase tracking-widest font-bold mt-1">
                   {course.modules.length} {t('course_sacred_steps')}
               </p>
            </div>

            <div className="overflow-y-auto bg-white/30 flex-1">
              {course.modules.map((module, index) => {
                const isLocked = isModuleLocked(module);
                const isActive = activeModule.id === module.id;
                const daysLeft = getDaysRemaining(module);

                return (
                  <motion.div
                    key={module.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => handleModuleClick(module)}
                    className={`
                      p-5 border-b border-gray-50/50 transition-all duration-300 flex items-start gap-4 relative group
                      ${isActive ? 'bg-white shadow-sm' : 'hover:bg-white/50'}
                      ${isLocked ? 'opacity-50 cursor-not-allowed grayscale-[0.8]' : 'cursor-pointer'}
                    `}
                  >
                    {isActive && <div className="absolute left-0 top-0 bottom-0 w-1 bg-angel-gold"></div>}
                    
                    <div className="mt-1 shrink-0">
                      {isLocked ? (
                        <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center">
                           <Lock className="w-3 h-3 text-gray-400" />
                        </div>
                      ) : isActive ? (
                        <div className="w-6 h-6 bg-angel-gold rounded-full flex items-center justify-center shadow-lg shadow-angel-gold/30">
                           <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                        </div>
                      ) : (
                        <CheckCircle className="w-6 h-6 text-gray-300 group-hover:text-angel-gold/50 transition-colors" />
                      )}
                    </div>

                    <div className="flex-1">
                      <p className={`text-sm font-medium mb-1.5 font-serif leading-tight ${isActive ? 'text-angel-gold font-bold' : 'text-gray-800'}`}>
                        {getLocalized(module.title)}
                      </p>
                      <div className="flex items-center gap-2 text-[10px] text-gray-400 uppercase tracking-wider font-bold">
                         <span>{module.duration}</span>
                         {isLocked && (
                           <span className="text-orange-500/80 flex items-center gap-1 bg-orange-50 px-1.5 py-0.5 rounded-sm">
                             <Hourglass className="w-3 h-3" /> {daysLeft}d Lock
                           </span>
                         )}
                      </div>
                    </div>
                  </motion.div>
                );
              })}

              {/* UPSELL ITEM - RENDERED AS 5TH ITEM IN LIST */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                onClick={() => setIsUpsellOpen(true)}
                className="p-1 m-4 rounded-xl bg-gradient-to-r from-angel-gold via-yellow-300 to-angel-gold shadow-[0_0_15px_rgba(212,175,55,0.4)] cursor-pointer group relative overflow-hidden shrink-0"
              >
                <div className="absolute inset-0 bg-white/10 animate-pulse"></div>
                <div className="bg-white/95 rounded-lg p-4 relative z-10 h-full flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-angel-gold to-yellow-600 flex items-center justify-center shadow-md">
                     <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-[10px] font-bold text-angel-gold uppercase tracking-widest mb-0.5">{t('course_upsell_title')}</p>
                    <p className="text-sm font-serif font-bold text-gray-900 group-hover:text-angel-accent transition-colors">
                      The Purification
                    </p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-angel-gold ml-auto group-hover:translate-x-1 transition-transform" />
                </div>
              </motion.div>

            </div>
          </div>
        </div>
      </div>

      {/* UPSELL MODAL */}
      <AnimatePresence>
        {isUpsellOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsUpsellOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl overflow-hidden border border-angel-gold/30"
            >
              <button onClick={() => setIsUpsellOpen(false)} className="absolute top-4 right-4 p-2 text-white/80 hover:text-white z-20"><X className="w-6 h-6 drop-shadow-md" /></button>
              
              <div className="h-40 bg-gold-gradient relative flex items-center justify-center overflow-hidden">
                 {/* Removed external texture here */}
                 <div className="absolute inset-0 opacity-20 bg-white/20"></div>
                 <div className="w-20 h-20 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/40 shadow-inner z-10 animate-pulse-slow">
                    <Lock className="w-8 h-8 text-white" />
                 </div>
              </div>

              <div className="p-10 text-center">
                <h2 className="font-serif text-3xl font-bold text-gray-900 mb-3">{t('course_upsell_title')}</h2>
                <div className="w-16 h-1 bg-angel-gold mx-auto mb-6 rounded-full"></div>
                <p className="text-gray-600 mb-8 leading-relaxed font-sans text-sm px-4">
                  {t('course_upsell_desc')}
                </p>
                <div className="space-y-4">
                   <Button onClick={() => alert('Redirecting to stripe checkout...')} className="w-full py-4 text-base shadow-gold-glow">{t('course_upsell_btn')} ($49)</Button>
                   <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">{t('course_secure_checkout')}</p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
