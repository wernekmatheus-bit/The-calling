
import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from '../lib/i18n_context';
import { Lock, PlayCircle, Star, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

interface CoursesProps {
  onNavigate: (view: string) => void;
}

const AVAILABLE_COURSES = [
  // 1. The 7 Hidden Hermetic Laws (Upsell 01)
  {
    id: 'hermetic_laws',
    titleKey: 'course_hermetic_title',
    descKey: 'course_hermetic_desc',
    locked: false,
    modules: 7,
    image: 'https://images.unsplash.com/photo-1507842217343-583bb7270b66?q=80&w=2000&auto=format&fit=crop' // Library
  },
  // 2. Millionaire’s Morning Ritual (Upsell 02)
  {
    id: 'morning_ritual',
    titleKey: 'course_morning_title',
    descKey: 'course_morning_desc',
    locked: true,
    modules: 5,
    image: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?q=80&w=2070&auto=format&fit=crop' // Sunrise
  },
  // 3. Millionaire’s Night Ritual (Upsell 03)
  {
    id: 'night_ritual',
    titleKey: 'course_night_title',
    descKey: 'course_night_desc',
    locked: true,
    modules: 5,
    image: 'https://images.unsplash.com/photo-1532767153582-b1a0e5129d27?q=80&w=2000&auto=format&fit=crop' // Night Sky (Fixed)
  },
  // 4. Sacred Prayer to Saint Michael (Locked Content)
  {
    id: 'st_michael',
    titleKey: 'course_michael_title',
    descKey: 'course_michael_desc',
    locked: true,
    modules: 3,
    image: 'https://images.unsplash.com/photo-1555626907-7d722272a74c?q=80&w=2000&auto=format&fit=crop' // Statue/Angel (Fixed)
  },
  // 5. Healing Journey With Padre Pio (Locked Content)
  {
    id: 'padre_pio_healing',
    titleKey: 'course_pio_healing_title',
    descKey: 'course_pio_healing_desc',
    locked: true,
    modules: 4,
    image: 'https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?q=80&w=2000&auto=format&fit=crop' // Hands/Comfort (Fixed)
  },
  // 6. Lent With Padre Pio (Locked Content)
  {
    id: 'padre_pio_lent',
    titleKey: 'course_pio_lent_title',
    descKey: 'course_pio_lent_desc',
    locked: true,
    modules: 40,
    image: 'https://images.unsplash.com/photo-1504052434569-70ad5836ab65?q=80&w=2000&auto=format&fit=crop' // Cross/Desert (Fixed)
  }
];

export const Courses: React.FC<CoursesProps> = ({ onNavigate }) => {
  const { t } = useTranslation();

  const handleCourseClick = (courseId: string, isLocked: boolean) => {
    if (isLocked) {
      // Simulate Checkout Redirect
      const confirm = window.confirm("Unlock this sacred wisdom? Access fee: $49.");
      if (confirm) {
         toast.success("Redirecting to Secure Sanctuary Checkout...");
         // In production: window.location.href = 'stripe_link'
      }
    } else {
      // Open Course Viewer
      onNavigate('course'); 
    }
  };

  return (
    <div className="min-h-screen bg-[#F9F7F2] pb-24 md:pb-12 pt-6 px-4 md:px-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="text-center mb-10 mt-4">
         <div className="w-16 h-16 bg-gradient-to-tr from-angel-gold to-yellow-300 rounded-full mx-auto flex items-center justify-center shadow-gold-glow mb-4">
            <PlayCircle className="w-8 h-8 text-white" />
         </div>
         <h1 className="font-serif text-3xl md:text-4xl font-bold text-gray-900 mb-2">{t('courses_title')}</h1>
         <p className="text-gray-500 text-sm max-w-lg mx-auto font-sans">
           {t('courses_subtitle')}
         </p>
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {AVAILABLE_COURSES.map((course, idx) => (
          <motion.div
            key={course.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`
              relative group rounded-2xl overflow-hidden shadow-xl bg-white border border-gray-100 transition-all duration-300
              ${course.locked ? 'hover:shadow-2xl' : 'hover:scale-[1.02] cursor-pointer'}
            `}
            onClick={() => handleCourseClick(course.id, course.locked)}
          >
            {/* Image Cover */}
            <div className="h-48 overflow-hidden relative">
               <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent z-10"></div>
               <img 
                 src={course.image} 
                 alt="Course" 
                 className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 ${course.locked ? 'grayscale-[0.5]' : ''}`}
               />
               
               {/* Badge */}
               <div className="absolute top-4 right-4 z-20">
                 {course.locked ? (
                   <div className="w-8 h-8 bg-black/60 backdrop-blur-md rounded-full flex items-center justify-center border border-white/20">
                      <Lock className="w-4 h-4 text-white" />
                   </div>
                 ) : (
                   <div className="w-8 h-8 bg-angel-gold rounded-full flex items-center justify-center shadow-lg">
                      <PlayCircle className="w-4 h-4 text-white" />
                   </div>
                 )}
               </div>
            </div>

            {/* Content */}
            <div className="p-6">
               <div className="flex justify-between items-start mb-2">
                  <h3 className="font-serif text-xl font-bold text-gray-900 group-hover:text-angel-gold transition-colors line-clamp-2 min-h-[3.5rem]">
                    {t(course.titleKey)}
                  </h3>
                  <div className="flex items-center gap-1 text-[10px] uppercase font-bold text-gray-400 bg-gray-100 px-2 py-1 rounded shrink-0">
                     <Star className="w-3 h-3 fill-gray-400" /> {course.modules}
                  </div>
               </div>
               
               <p className="text-gray-600 text-sm leading-relaxed mb-6 font-sans line-clamp-3 min-h-[4.5rem]">
                 {t(course.descKey)}
               </p>

               <button 
                 className={`
                   w-full py-3 px-4 rounded-lg font-bold text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2
                   ${course.locked 
                     ? 'bg-gray-900 text-white hover:bg-gray-800' 
                     : 'bg-gradient-to-r from-angel-gold to-yellow-500 text-white shadow-gold-glow hover:opacity-90'}
                 `}
               >
                 {course.locked ? (
                   <><Sparkles className="w-4 h-4 text-yellow-400" /> {t('course_btn_locked')}</>
                 ) : (
                   <><PlayCircle className="w-4 h-4" /> {t('course_btn_start')}</>
                 )}
               </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
