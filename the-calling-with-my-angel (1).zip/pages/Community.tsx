
import React from 'react';
import { PrayerFeed } from '../components/PrayerFeed';
import { Leaderboard } from '../components/Leaderboard';
import { PrayerCircle } from '../components/PrayerCircle';
import { useTranslation } from '../lib/i18n_context';

export const Community: React.FC = () => {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-[#F9F7F2] pb-24 md:pb-12 pt-6 px-4 md:px-8 max-w-7xl mx-auto">
      
      <div className="mt-6">
        {/* 1. HERO: REALTIME PRAYER CIRCLE */}
        <section className="mb-8">
          <PrayerCircle />
        </section>

        {/* 2. MAIN GRID CONTENT */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* LEFT COLUMN (Mobile Order 2): MAIN FEED */}
          <div className="lg:col-span-2 order-2 lg:order-1">
            <PrayerFeed />
          </div>

          {/* RIGHT COLUMN (Mobile Order 1): LEADERBOARD & STATS */}
          <div className="lg:col-span-1 order-1 lg:order-2 space-y-6">
            <div className="sticky top-24">
                <Leaderboard />
                
                {/* Extra Widget: Community Quote */}
                <div className="mt-6 p-6 rounded-2xl bg-gradient-to-br from-gray-900 to-gray-800 text-white shadow-xl relative overflow-hidden hidden lg:block">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-angel-gold opacity-10 rounded-full blur-2xl -mr-10 -mt-10"></div>
                  <h4 className="font-serif font-bold text-lg mb-2 text-angel-gold">{t('comm_did_you_know')}</h4>
                  <p className="text-sm text-gray-300 leading-relaxed">
                    {t('comm_stat_desc')}
                  </p>
                </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
