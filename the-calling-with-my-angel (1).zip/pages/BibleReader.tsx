import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Loader2, 
  Sparkles, 
  ChevronLeft, 
  ChevronRight,
  X,
  BookOpen,
  Map as MapIcon
} from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from '../lib/i18n_context';
import { triggerDivineCelebration } from '../lib/confetti';
import { BibleState } from '../types';
import { GoogleGenAI } from "@google/genai";
import { Button } from '../components/ui/Button';

// Metadata for Bible Books (Simplified MVP Order)
const BIBLE_BOOKS_METADATA: Record<string, number> = {
  "Genesis": 50,
  "Exodus": 40,
  "Leviticus": 27,
  "Numbers": 36,
  "Deuteronomy": 34,
  "Joshua": 24,
  "Psalms": 150,
  "Proverbs": 31,
  "Ecclesiastes": 12,
  "Song of Solomon": 8,
  "Matthew": 28,
  "Mark": 16,
  "Luke": 24,
  "John": 21,
  "Revelation": 22
};

const DEFAULT_BIBLE_STATE: BibleState = {
  topic_id: 'general',
  book_name: 'Genesis',
  current_chapter: 1,
  total_chapters: 50,
  completed_chapters: [],
  last_read_at: new Date().toISOString()
};

export const BibleReader: React.FC = () => {
  const { t, language } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [loadingContent, setLoadingContent] = useState(false);
  const [state, setState] = useState<BibleState>(DEFAULT_BIBLE_STATE);
  const [chapterContent, setChapterContent] = useState<string>('');
  
  // UI States - explicitly false to prevent blocking overlay
  const [showAiModal, setShowAiModal] = useState(false);
  const [showBookSelector, setShowBookSelector] = useState(false);
  const [aiThinking, setAiThinking] = useState(false);
  const [aiResponse, setAiResponse] = useState<string>('');
  
  // 1. Initial Load from Supabase
  useEffect(() => {
    fetchState();
  }, []);

  // 2. Fetch Content whenever Book, Chapter, or Language changes
  useEffect(() => {
    if (!loading) {
        fetchChapterContent();
    }
  }, [state.book_name, state.current_chapter, language, loading]);

  // Helper to read/write from LocalStorage for speed
  const getCachedContent = (book: string, chapter: number, lang: string) => {
      try {
          const key = `bible_cache_${book}_${chapter}_${lang}`;
          return localStorage.getItem(key);
      } catch (e) {
          return null;
      }
  };

  const setCachedContent = (book: string, chapter: number, lang: string, content: string) => {
      try {
          const key = `bible_cache_${book}_${chapter}_${lang}`;
          localStorage.setItem(key, content);
      } catch (e) {
          // ignore quote exceeded errors
      }
  };

  const fetchState = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('bible_state')
          .eq('id', user.id)
          .single();
        
        if (profile?.bible_state) {
          const loadedState = profile.bible_state as BibleState;
          const currentTotal = BIBLE_BOOKS_METADATA[loadedState.book_name] || 50;
          
          setState({ 
              ...DEFAULT_BIBLE_STATE, 
              ...loadedState,
              total_chapters: currentTotal
          });
        } else {
             await supabase.from('profiles').update({
                 bible_state: DEFAULT_BIBLE_STATE
             }).eq('id', user.id);
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const getBookName = (key: string) => {
      // Constructs key like 'bible_book_genesis'
      const tKey = `bible_book_${key.toLowerCase().replace(/ /g, '_')}`;
      return t(tKey) === tKey ? key : t(tKey);
  };

  const fetchChapterContent = async () => {
      // 1. Check LocalStorage Cache First (Instant Load)
      const cached = getCachedContent(state.book_name, state.current_chapter, language);
      if (cached) {
          setChapterContent(cached);
          return;
      }

      setLoadingContent(true);
      try {
          if (!process.env.API_KEY) throw new Error("API Key missing");
          
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          
          const languageNames: Record<string, string> = {
            'pt': 'Portuguese',
            'es': 'Spanish',
            'en': 'English',
            'fr': 'French',
            'it': 'Italian',
            'de': 'German'
          };
          const targetLang = languageNames[language] || 'English';

          const prompt = `
            You are a Bible API. 
            Output ONLY the full text of the Holy Bible for:
            Book: ${state.book_name}
            Chapter: ${state.current_chapter}
            Language: ${targetLang}
            
            Do not add introductions, explanations, or markdown formatting like **bold**. 
            Just provide the verses clearly formatted.
          `;

          const response = await ai.models.generateContent({
              model: 'gemini-3-flash-preview',
              contents: prompt
          });

          const text = response.text || t('chat_empty_state');
          setChapterContent(text);
          
          // Save to Persistent Cache
          setCachedContent(state.book_name, state.current_chapter, language, text);

      } catch (error) {
          console.error("Content generation failed", error);
          setChapterContent("Could not retrieve the sacred text at this moment. Please check your connection.");
      } finally {
          setLoadingContent(false);
      }
  };

  const saveProgress = async (newState: BibleState) => {
      setState(newState);
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
          await supabase.from('profiles').update({
              bible_state: newState
          }).eq('id', user.id);
      }
  };

  const markCurrentAsComplete = async () => {
      if (!state.completed_chapters.includes(state.current_chapter)) {
          triggerDivineCelebration();
      }

      const newCompleted = Array.from(new Set([...state.completed_chapters, state.current_chapter]));
      
      return {
          ...state,
          completed_chapters: newCompleted,
          last_read_at: new Date().toISOString()
      };
  };

  const handleNext = async () => {
     let updatedState = await markCurrentAsComplete();
     
     if (updatedState.current_chapter < updatedState.total_chapters) {
         updatedState.current_chapter += 1;
         await saveProgress(updatedState);
         window.scrollTo({ top: 0, behavior: 'smooth' });
     } else {
         const books = Object.keys(BIBLE_BOOKS_METADATA);
         const currentIdx = books.indexOf(updatedState.book_name);
         
         if (currentIdx < books.length - 1) {
             const nextBookName = books[currentIdx + 1];
             const nextTotal = BIBLE_BOOKS_METADATA[nextBookName];
             
             updatedState = {
                 ...updatedState,
                 book_name: nextBookName,
                 current_chapter: 1,
                 total_chapters: nextTotal,
                 completed_chapters: [] 
             };
             
             toast.success(t('bible_book_finished'), { icon: <BookOpen className="w-4 h-4" /> });
             await saveProgress(updatedState);
             window.scrollTo({ top: 0, behavior: 'smooth' });
         } else {
             toast.success("You have reached the end of the available scriptures.");
         }
     }
  };

  const handlePrev = () => {
     if (state.current_chapter > 1) {
         const newState = { ...state, current_chapter: state.current_chapter - 1 };
         saveProgress(newState);
         window.scrollTo({ top: 0, behavior: 'smooth' });
     }
  };

  const handleBookSelect = async (bookName: string) => {
      const total = BIBLE_BOOKS_METADATA[bookName];
      const newState: BibleState = {
          ...state,
          book_name: bookName,
          current_chapter: 1,
          total_chapters: total,
          completed_chapters: [] 
      };
      
      setShowBookSelector(false);
      
      await saveProgress(newState);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      toast.success(t('bible_reset_confirm').split('?')[0]); 
  };

  const handleAskAI = async () => {
      if (!process.env.API_KEY) return;

      setAiThinking(true);
      setAiResponse('');
      
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `Provide a short, spiritually uplifting insight and summary for ${state.book_name} Chapter ${state.current_chapter} in ${language === 'pt' ? 'Portuguese' : 'English'}. Focus on practical application.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt
        });
        
        setAiResponse(response.text || "The heavens are silent momentarily.");
      } catch (e) {
        setAiResponse(t('ai_modal_error'));
      } finally {
        setAiThinking(false);
      }
  };

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="animate-spin text-angel-gold w-8 h-8" /></div>;

  return (
    <div className="min-h-screen bg-[#F9F7F2] pb-24 md:pb-12 pt-6 px-4 md:px-8 max-w-4xl mx-auto font-serif">
       {/* Header */}
       <div className="flex items-center justify-between mb-8 sticky top-0 bg-[#F9F7F2]/90 backdrop-blur-sm py-4 z-10 border-b border-angel-gold/10">
           <div>
               <div 
                 onClick={() => setShowBookSelector(true)}
                 className="flex items-center gap-2 cursor-pointer group"
               >
                 <h1 className="text-3xl font-bold text-gray-900 group-hover:text-angel-gold transition-colors">
                    {getBookName(state.book_name)}
                 </h1>
                 <MapIcon className="w-5 h-5 text-gray-300 group-hover:text-angel-gold" />
               </div>
               
               <p className="text-angel-gold uppercase tracking-widest text-xs font-sans font-bold mt-1">
                   {t('bible_chapter_indicator', { current: state.current_chapter, total: state.total_chapters })}
               </p>
           </div>
           
           <div className="flex gap-2">
                <button 
                    onClick={() => setShowBookSelector(true)}
                    className="p-3 bg-white border border-gray-200 rounded-full shadow-sm hover:border-angel-gold text-gray-400 hover:text-angel-gold transition-all"
                    title={t('bible_select_book')}
                >
                    <BookOpen className="w-5 h-5" />
                </button>
                <button 
                    onClick={() => setShowAiModal(true)}
                    className="p-3 bg-white border border-angel-gold/30 rounded-full shadow-sm hover:shadow-gold-glow transition-all group"
                    title={t('ai_modal_title')}
                >
                    <Sparkles className="w-5 h-5 text-angel-gold group-hover:scale-110 transition-transform" />
                </button>
           </div>
       </div>

       {/* Reader Content */}
       <div className="glass-card min-h-[500px] p-8 md:p-12 rounded-2xl shadow-xl bg-white mb-8 border-t-4 border-angel-gold relative">
           {loadingContent ? (
               <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/50 backdrop-blur-sm z-10 rounded-2xl">
                   <Loader2 className="w-10 h-10 text-angel-gold animate-spin mb-4" />
                   <p className="text-sm text-gray-400 font-sans animate-pulse">{t('bible_loading_text')}</p>
               </div>
           ) : (
               <motion.div
                 key={`${state.book_name}-${state.current_chapter}`} 
                 initial={{ opacity: 0, y: 10 }}
                 animate={{ opacity: 1, y: 0 }}
                 transition={{ duration: 0.5 }}
                 className="leading-loose text-lg text-gray-800 whitespace-pre-wrap font-serif"
               >
                   {chapterContent}
               </motion.div>
           )}
       </div>

       {/* Controls */}
       <div className="flex items-center justify-between gap-4">
           <Button 
               variant="outline" 
               onClick={handlePrev} 
               disabled={state.current_chapter <= 1 || loadingContent} 
               className="w-32"
           >
               <ChevronLeft className="w-4 h-4 mr-2" /> {t('bible_prev_btn')}
           </Button>

           <div className="hidden md:flex flex-col items-center">
               <span className="text-xs text-gray-400 uppercase tracking-widest">{t('bible_reading_mode')}</span>
           </div>

           <Button 
               onClick={handleNext} 
               disabled={loadingContent}
               className="w-32 shadow-gold-glow"
           >
               {t('bible_next_btn')} <ChevronRight className="w-4 h-4 ml-2" />
           </Button>
       </div>

       {/* AI Modal */}
       <AnimatePresence>
           {showAiModal && (
               <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                   <motion.div 
                     initial={{ opacity: 0 }}
                     animate={{ opacity: 1 }}
                     exit={{ opacity: 0 }}
                     onClick={() => setShowAiModal(false)}
                     className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                   />
                   <motion.div 
                     initial={{ opacity: 0, scale: 0.9 }}
                     animate={{ opacity: 1, scale: 1 }}
                     exit={{ opacity: 0, scale: 0.9 }}
                     className="bg-white rounded-2xl p-6 max-w-lg w-full relative shadow-2xl border border-angel-gold/20 z-10"
                   >
                       <button onClick={() => setShowAiModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                           <X className="w-5 h-5" />
                       </button>
                       <h3 className="text-xl font-bold mb-4 flex items-center gap-2 font-serif text-gray-900">
                           <Sparkles className="w-5 h-5 text-angel-gold" /> {t('ai_modal_title')}
                       </h3>
                       
                       <div className="min-h-[150px] bg-gray-50 rounded-xl p-6 mb-6 font-sans text-gray-700 leading-relaxed border border-gray-100 max-h-[60vh] overflow-y-auto">
                           {aiThinking ? (
                               <div className="flex items-center justify-center h-full gap-2 text-gray-400 py-10">
                                   <Loader2 className="animate-spin w-4 h-4 text-angel-gold" /> {t('ai_modal_thinking')}
                               </div>
                           ) : aiResponse ? (
                               aiResponse
                           ) : (
                               <div className="flex flex-col items-center justify-center h-full text-center py-6">
                                   <p className="text-sm text-gray-500 mb-4">{t('ai_modal_desc')}</p>
                                   <Button onClick={handleAskAI} className="w-auto shadow-gold-glow">
                                       {t('ai_modal_btn')}
                                   </Button>
                               </div>
                           )}
                       </div>
                   </motion.div>
               </div>
           )}
       </AnimatePresence>

       {/* Book Selector Modal */}
       <AnimatePresence>
           {showBookSelector && (
               <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
                   <motion.div 
                     initial={{ opacity: 0 }}
                     animate={{ opacity: 1 }}
                     exit={{ opacity: 0 }}
                     onClick={() => setShowBookSelector(false)}
                     className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                   />
                   <motion.div 
                     initial={{ opacity: 0, scale: 0.9 }}
                     animate={{ opacity: 1, scale: 1 }}
                     exit={{ opacity: 0, scale: 0.9 }}
                     className="bg-[#F9F7F2] rounded-2xl p-6 max-w-3xl w-full max-h-[80vh] flex flex-col shadow-2xl relative z-10"
                   >
                       <button onClick={() => setShowBookSelector(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                           <X className="w-5 h-5" />
                       </button>
                       
                       <div className="mb-6 text-center">
                           <h3 className="font-serif text-2xl font-bold text-gray-900 mb-2">{t('bible_select_book')}</h3>
                           <div className="w-16 h-1 bg-angel-gold mx-auto rounded-full"></div>
                       </div>

                       <div className="overflow-y-auto grid grid-cols-2 md:grid-cols-3 gap-3 p-2">
                           {Object.keys(BIBLE_BOOKS_METADATA).map(book => (
                               <button
                                   key={book}
                                   onClick={() => handleBookSelect(book)}
                                   className={`
                                     p-4 rounded-xl text-left border transition-all duration-200
                                     ${state.book_name === book 
                                        ? 'bg-angel-gold text-white border-angel-gold shadow-md' 
                                        : 'bg-white border-gray-200 text-gray-700 hover:border-angel-gold hover:text-angel-gold hover:shadow-sm'}
                                   `}
                               >
                                   <p className="font-serif font-bold text-lg">{getBookName(book)}</p>
                                   <p className={`text-xs uppercase tracking-widest font-bold mt-1 ${state.book_name === book ? 'text-white/80' : 'text-gray-400'}`}>
                                       {t('bible_chapters_count', { count: BIBLE_BOOKS_METADATA[book] })}
                                   </p>
                               </button>
                           ))}
                       </div>
                   </motion.div>
               </div>
           )}
       </AnimatePresence>

    </div>
  );
};
