
import React, { useState, useRef, useEffect } from 'react';
import { Send, Lock, Sparkles, ChevronLeft, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '../components/ui/Button';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import { useTranslation } from '../lib/i18n_context';

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  is_locked: boolean;
  created_at: string;
}

export const Confessional: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const { t } = useTranslation();
  
  // State
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [loading, setLoading] = useState(true);
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchHistory();
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        // Fallback for demo if not logged in (Mock Init)
        setMessages([
          { id: '1', sender: 'ai', text: t('confess_initial_ai'), is_locked: false, created_at: new Date().toISOString() }
        ]);
        setLoading(false);
        return;
      }

      // Fetch from Supabase
      const { data, error } = await supabase
        .from('confessions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: true });

      if (error && error.code !== 'PGRST116') {
         // Silently fail to mock if table doesn't exist yet in MVP
         setMessages([
          { id: '1', sender: 'ai', text: t('confess_initial_ai'), is_locked: false, created_at: new Date().toISOString() }
        ]);
      } else if (data && data.length > 0) {
        setMessages(data);
      } else {
         setMessages([
          { id: '1', sender: 'ai', text: t('confess_initial_ai'), is_locked: false, created_at: new Date().toISOString() }
        ]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async () => {
    if (!inputValue.trim()) return;
    const text = inputValue.trim();
    setInputValue('');

    // 1. Optimistic UI Update
    const tempId = Date.now().toString();
    const newMsg: Message = { id: tempId, sender: 'user', text: text, is_locked: false, created_at: new Date().toISOString() };
    setMessages(prev => [...prev, newMsg]);
    setIsTyping(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        // Real Insert
        await supabase.from('confessions').insert({
          user_id: user.id,
          sender: 'user',
          text: text,
          is_locked: false
        });

        // SIMULATE AI REPLY (Since we don't have Edge Function connected in this prompt)
        setTimeout(async () => {
          setIsTyping(false);
          // NOTE: AI text is usually generated in English by default unless configured otherwise.
          // For now, we assume AI replies in English or we rely on the prompt to instruct language.
          const aiText = "The path to redemption requires shedding your earthly attachments. To clear this path, you must first perform the Act of Surrender...";
          
          // Insert AI Message (Locked)
          const { data: aiMsgData } = await supabase.from('confessions').insert({
            user_id: user.id,
            sender: 'ai',
            text: aiText,
            is_locked: true
          }).select().single();

          const finalAiMsg = aiMsgData || { 
             id: (Date.now() + 1).toString(), 
             sender: 'ai', 
             text: aiText, 
             is_locked: true, 
             created_at: new Date().toISOString() 
          };

          setMessages(prev => [...prev, finalAiMsg]);
        }, 2000);
      } else {
        // Virtual Mode Simulation
        setTimeout(() => {
          setIsTyping(false);
          setMessages(prev => [...prev, {
            id: (Date.now() + 1).toString(),
            sender: 'ai',
            text: "The path to redemption requires shedding your earthly attachments. I sense a deep blockage in your spirit regarding this matter. To clear this path, you must first perform the Act of Surrender...",
            is_locked: true,
            created_at: new Date().toISOString()
          }]);
        }, 2000);
      }

    } catch (error) {
      console.error("Failed to send", error);
    }
  };

  const handleUnlock = async (messageId: string) => {
    // Mock Payment Process / DB Update
    const confirm = window.confirm("Make Offering ($5) to unlock this wisdom?");
    if (confirm) {
      try {
        // Optimistic Update
        setMessages(prev => prev.map(m => m.id === messageId ? { ...m, is_locked: false } : m));
        
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
           await supabase
             .from('confessions')
             .update({ is_locked: false })
             .eq('id', messageId)
             .eq('user_id', user.id);
        }
        
        toast.success(t('confess_wisdom_revealed'));
      } catch (err) {
        toast.error("Transaction Failed");
      }
    }
  };

  return (
    <div className="w-full h-full min-h-screen bg-[#0a0a0a] text-slate-300 font-serif flex flex-col pb-24 md:pb-0">
      
      {/* Sacred Header */}
      <header className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-black/40 backdrop-blur-md sticky top-0 z-10">
        <div className="w-8">
           {/* Optional: Add back button here if needed, currently empty to center title */}
        </div>
        <div className="flex flex-col items-center">
          <h1 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-600 to-yellow-400 tracking-wider drop-shadow-sm">{t('confess_title')}</h1>
          <span className="text-[9px] text-slate-600 uppercase tracking-[0.3em]">{t('confess_status')}</span>
        </div>
        <div className="w-8" /> 
      </header>

      {/* Chat Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-8 scroll-smooth"
        style={{ backgroundImage: 'radial-gradient(circle at center, rgba(30, 25, 10, 0.3) 0%, rgba(0,0,0,0) 70%)' }}
      >
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 text-yellow-600 animate-spin opacity-50" />
          </div>
        ) : (
          messages.map((msg) => (
            <motion.div 
              key={msg.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`
                 max-w-[85%] relative rounded-2xl px-6 py-5 shadow-2xl border
                 ${msg.sender === 'user' 
                   ? 'bg-slate-900/80 border-slate-700/50 text-slate-100 rounded-tr-sm' 
                   : 'bg-black/60 border-yellow-900/30 text-yellow-50/90 rounded-tl-sm'}
              `}>
                
                {/* Message Content */}
                <div className={msg.is_locked ? 'blur-sm select-none opacity-40 transition-all duration-700' : 'filter-none transition-all duration-700'}>
                  <p className="leading-relaxed text-lg font-serif tracking-wide">{msg.text}</p>
                </div>

                {/* PAYWALL OVERLAY */}
                {msg.is_locked && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 rounded-2xl backdrop-blur-sm border border-yellow-500/30 p-4 text-center z-10">
                    <motion.div 
                      animate={{ boxShadow: ['0 0 0px rgba(234, 179, 8, 0)', '0 0 20px rgba(234, 179, 8, 0.3)', '0 0 0px rgba(234, 179, 8, 0)'] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="w-12 h-12 rounded-full bg-black border border-yellow-600 flex items-center justify-center mb-3"
                    >
                      <Lock className="w-5 h-5 text-yellow-500" />
                    </motion.div>
                    <h3 className="text-yellow-500 font-bold mb-1 font-serif text-lg">{t('confess_wisdom_sealed')}</h3>
                    <p className="text-xs text-slate-400 mb-5 font-sans max-w-[200px] leading-relaxed">
                      {t('confess_sacrifice_text')}
                    </p>
                    <Button 
                      onClick={() => handleUnlock(msg.id)}
                      className="bg-gradient-to-r from-yellow-700 to-yellow-600 text-white border-none py-2 px-8 text-xs uppercase tracking-widest font-bold hover:from-yellow-600 hover:to-yellow-500 shadow-lg shadow-yellow-900/40"
                    >
                      {t('confess_unlock')}
                    </Button>
                  </div>
                )}
                
                {/* Timestamp */}
                <span className="text-[9px] text-slate-600 absolute bottom-2 right-4 opacity-50">
                  {new Date(msg.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                </span>
              </div>
            </motion.div>
          ))
        )}

        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex justify-start">
             <div className="bg-black/40 border border-white/5 rounded-2xl px-6 py-4 flex gap-1.5">
                <span className="w-1.5 h-1.5 bg-yellow-600/60 rounded-full animate-bounce delay-0"></span>
                <span className="w-1.5 h-1.5 bg-yellow-600/60 rounded-full animate-bounce delay-150"></span>
                <span className="w-1.5 h-1.5 bg-yellow-600/60 rounded-full animate-bounce delay-300"></span>
             </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-4 bg-black/90 border-t border-white/10 backdrop-blur-xl">
        <div className="max-w-4xl mx-auto relative flex items-center gap-4">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={t('confess_placeholder')}
            className="w-full bg-white/5 border border-white/10 text-slate-200 rounded-full px-6 py-4 focus:outline-none focus:border-yellow-600/50 focus:ring-1 focus:ring-yellow-600/50 transition-all placeholder:text-slate-600 font-serif tracking-wide"
            autoFocus
          />
          <button 
            onClick={handleSend}
            disabled={!inputValue.trim()}
            className="p-4 rounded-full bg-gradient-to-br from-yellow-700 to-yellow-600 hover:to-yellow-500 text-white disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-lg shadow-yellow-900/20 active:scale-95"
          >
            <Send className="w-5 h-5 ml-0.5" />
          </button>
        </div>
      </div>

    </div>
  );
};
