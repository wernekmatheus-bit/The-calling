
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Heart, 
  Coins, 
  Shield, 
  Sparkles, 
  ArrowRight, 
  ChevronLeft, 
  ChevronRight,
  Lock, 
  CheckCircle,
  Activity
} from 'lucide-react';
import { useTranslation } from '../lib/i18n_context';
import { Button } from '../components/ui/Button';
import { toast } from 'sonner';

// Mock Categories
const EMPATIA_CATEGORIES = [
  { id: 'love', icon: Heart, labelKey: 'empatia_cat_love', color: 'text-rose-500', bg: 'bg-rose-50' },
  { id: 'prosperity', icon: Coins, labelKey: 'empatia_cat_prosperity', color: 'text-amber-500', bg: 'bg-amber-50' },
  { id: 'protection', icon: Shield, labelKey: 'empatia_cat_protection', color: 'text-blue-500', bg: 'bg-blue-50' },
  { id: 'health', icon: Activity, labelKey: 'empatia_cat_health', color: 'text-emerald-500', bg: 'bg-emerald-50' },
];

const EMPATIA_SUBS = {
  love: [
    { id: 'improve', labelKey: 'empatia_sub_love_improve' },
    { id: 'new', labelKey: 'empatia_sub_love_new' },
    { id: 'conquer', labelKey: 'empatia_sub_love_conquer' },
  ],
  prosperity: [
    { id: 'job', labelKey: 'empatia_sub_pros_job' },
    { id: 'debt', labelKey: 'empatia_sub_pros_debt' },
    { id: 'flow', labelKey: 'empatia_sub_pros_flow' },
  ],
  protection: [
    { id: 'env', labelKey: 'empatia_sub_prot_env' },
    { id: 'evil', labelKey: 'empatia_sub_prot_evil' },
    { id: 'peace', labelKey: 'empatia_sub_prot_peace' },
  ],
  health: [
    { id: 'peace', labelKey: 'empatia_sub_prot_peace' } // Fallback reuse for demo
  ]
};

interface EmpatiaProps {
  onNavigate: (view: string) => void;
}

export const Empatia: React.FC<EmpatiaProps> = ({ onNavigate }) => {
  const { t } = useTranslation();
  
  // State Machine: 'categories' -> 'subcategories' -> 'checkout' -> 'unlocked'
  const [step, setStep] = useState<'categories' | 'subcategories' | 'checkout' | 'unlocked'>('categories');
  const [selectedCat, setSelectedCat] = useState<string | null>(null);
  const [selectedSub, setSelectedSub] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleCatSelect = (id: string) => {
    setSelectedCat(id);
    setStep('subcategories');
  };

  const handleSubSelect = (id: string) => {
    setSelectedSub(id);
    setStep('checkout');
  };

  const handleUnlock = async () => {
    setLoading(true);
    // Simulate API Call / Checkout
    setTimeout(() => {
        setLoading(false);
        setStep('unlocked');
        toast.success(t('msg_offering_accepted'), {
            icon: <Sparkles className="w-4 h-4 text-angel-gold" />
        });
    }, 1500);
  };

  const getActiveCat = () => EMPATIA_CATEGORIES.find(c => c.id === selectedCat);

  return (
    <div className="min-h-screen bg-[#F9F7F2] pb-24 md:pb-12 pt-6 px-4 md:px-8 max-w-2xl mx-auto">
       
       {/* HEADER */}
       <div className="text-center mb-8 relative">
          {step !== 'categories' && (
              <button 
                onClick={() => setStep(step === 'subcategories' ? 'categories' : step === 'checkout' ? 'subcategories' : 'categories')}
                className="absolute left-0 top-1 p-2 bg-white rounded-full shadow-sm hover:bg-gray-50 text-gray-500"
              >
                  <ChevronLeft className="w-5 h-5" />
              </button>
          )}
          <h1 className="font-serif text-3xl font-bold text-gray-900">{t('empatia_title')}</h1>
          <p className="text-gray-500 text-sm mt-2">{t('empatia_subtitle')}</p>
       </div>

       <AnimatePresence mode='wait'>
         
         {/* STEP 1: CATEGORIES */}
         {step === 'categories' && (
            <motion.div 
                key="cat"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="grid grid-cols-1 gap-4"
            >
                {EMPATIA_CATEGORIES.map((cat) => (
                    <div 
                        key={cat.id}
                        onClick={() => handleCatSelect(cat.id)}
                        className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-6 cursor-pointer hover:border-angel-gold/30 hover:shadow-md transition-all group"
                    >
                        <div className={`w-14 h-14 rounded-full ${cat.bg} flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform`}>
                            <cat.icon className={`w-7 h-7 ${cat.color}`} />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-serif text-xl font-bold text-gray-800">{t(cat.labelKey)}</h3>
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-angel-gold" />
                    </div>
                ))}
            </motion.div>
         )}

         {/* STEP 2: SUBCATEGORIES */}
         {step === 'subcategories' && selectedCat && (
             <motion.div 
                key="sub"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
             >
                <div className={`w-16 h-16 mx-auto rounded-full ${getActiveCat()?.bg} flex items-center justify-center mb-6`}>
                    {(() => {
                        const Icon = getActiveCat()?.icon || Sparkles;
                        return <Icon className={`w-8 h-8 ${getActiveCat()?.color}`} />;
                    })()}
                </div>

                <div className="grid gap-3">
                    {/* @ts-ignore - dynamic key access */}
                    {(EMPATIA_SUBS[selectedCat] || []).map((sub: any) => (
                        <button
                            key={sub.id}
                            onClick={() => handleSubSelect(sub.id)}
                            className="w-full text-left p-5 bg-white rounded-xl border border-gray-200 hover:border-angel-gold hover:bg-angel-gold/5 transition-all font-serif font-bold text-gray-800 flex justify-between items-center group"
                        >
                            {t(sub.labelKey)}
                            <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-angel-gold" />
                        </button>
                    ))}
                </div>
             </motion.div>
         )}

         {/* STEP 3: CHECKOUT / SALES */}
         {step === 'checkout' && (
             <motion.div 
                key="checkout"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-3xl p-8 shadow-2xl border border-angel-gold/20 text-center relative overflow-hidden"
             >
                <div className="absolute top-0 right-0 w-32 h-32 bg-angel-gold/10 rounded-full blur-3xl -mr-10 -mt-10"></div>
                
                <div className="w-20 h-20 mx-auto bg-gradient-to-br from-angel-gold to-yellow-500 rounded-full flex items-center justify-center shadow-gold-glow mb-6 animate-pulse-slow">
                    <Lock className="w-8 h-8 text-white" />
                </div>

                <h2 className="font-serif text-2xl font-bold text-gray-900 mb-4">{t('empatia_checkout_title')}</h2>
                <p className="text-gray-600 mb-8 leading-relaxed">
                    {t('empatia_checkout_desc')}
                </p>

                <div className="bg-gray-50 p-4 rounded-xl mb-8 text-left border border-gray-100">
                    <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-gray-500 font-bold uppercase">{t('empatia_title')}</span>
                        <span className="font-serif font-bold text-gray-900">R$ 19,90</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-800">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        {selectedCat && t(EMPATIA_CATEGORIES.find(c => c.id === selectedCat)?.labelKey || '')}
                    </div>
                </div>

                <Button onClick={handleUnlock} isLoading={loading} className="w-full py-4 text-base shadow-gold-glow">
                    {t('empatia_unlock_btn')}
                </Button>
                
                <p className="text-[10px] text-gray-400 mt-4 uppercase tracking-widest font-bold">Secure Sanctuary Payment</p>
             </motion.div>
         )}

         {/* STEP 4: UNLOCKED CONTENT */}
         {step === 'unlocked' && (
             <motion.div 
                key="unlocked"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-3xl p-8 shadow-xl border border-gray-100"
             >
                <div className="flex items-center gap-3 mb-6 border-b border-gray-100 pb-4">
                    <Sparkles className="w-6 h-6 text-angel-gold" />
                    <h2 className="font-serif text-2xl font-bold text-gray-900">{t('empatia_content_title')}</h2>
                </div>

                <div className="space-y-6">
                    <div>
                        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{t('empatia_content_step_1')}</h3>
                        <p className="text-gray-700 leading-relaxed font-serif">
                            {t('journey_d1_task')} {/* Using generic placeholder text for demo */}
                        </p>
                    </div>
                    
                    <div>
                        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{t('empatia_content_step_2')}</h3>
                        <p className="text-gray-700 leading-relaxed font-serif">
                            Light a white candle and focus on the flame. Visualize your intent clearly as if it has already happened.
                        </p>
                    </div>

                    <div className="bg-angel-gold/5 p-4 rounded-xl border border-angel-gold/20">
                         <h3 className="text-xs font-bold text-angel-gold uppercase tracking-widest mb-2">{t('empatia_content_step_3')}</h3>
                         <p className="font-serif italic text-gray-800">
                            "Divine spirit, align my path with the highest good. Let what is mine come to me."
                         </p>
                    </div>
                </div>

                <Button onClick={() => onNavigate('dashboard')} variant="outline" className="w-full mt-8">
                    {t('comm_return')}
                </Button>
             </motion.div>
         )}

       </AnimatePresence>
    </div>
  );
};
