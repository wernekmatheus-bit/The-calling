
import React, { useState, useEffect } from 'react';
import { useTranslation } from '../lib/i18n_context';
import { Flame, Bell, ShieldCheck, Key, Lock, ArrowRight, PlayCircle, Leaf, Sparkles, Info, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Toaster, toast } from 'sonner';
import { Checkbox } from '../components/ui/Checkbox';
import { triggerDivineCelebration } from '../lib/confetti';
import { playAngelicChord } from '../lib/audio';
import { supabase } from '../lib/supabase';
import { format } from 'date-fns';
import { getRank } from '../lib/gamification';
import { Button } from '../components/ui/Button';

interface ChecklistItem {
  id: number;
  labelKey: string;
  descKey: string; 
  checked: boolean;
}

const DEFAULT_TASKS = [
  { id: 1, labelKey: "task_morning_prayer", descKey: "task_desc_morning" },
  { id: 2, labelKey: "task_sacred_study", descKey: "task_desc_study" },
  { id: 3, labelKey: "task_temple_care", descKey: "task_desc_temple" },
  { id: 4, labelKey: "task_hard_task", descKey: "task_desc_hard" },
  { id: 5, labelKey: "task_gratitude", descKey: "task_desc_gratitude" },
];

interface DashboardProps {
  onNavigate: (view: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { t } = useTranslation();
  
  // State
  const [verseIndex, setVerseIndex] = useState(0);
  const [profile, setProfile] = useState<any>(null);
  const [checklist, setChecklist] = useState<ChecklistItem[]>(
    DEFAULT_TASKS.map(t => ({ ...t, checked: false }))
  );
  const [loading, setLoading] = useState(true);
  const [showHardTaskInfo, setShowHardTaskInfo] = useState(false); // Modal State

  // Effects
  useEffect(() => {
    setVerseIndex(Math.floor(Math.random() * 3) + 1); // 1, 2, or 3
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      // Prioritize Real Data
      if (user) {
        // 1. Fetch Profile
        const { data: profileData, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .maybeSingle();
        
        // Defensive: If intercessions_count missing, default to 0 to prevent crash
        const safeProfile = profileData ? { ...profileData, intercessions_count: profileData.intercessions_count ?? 0 } : null;

        setProfile(safeProfile || { 
          current_streak: 0, 
          xp: 0, 
          intercessions_count: 0,
          name: user.email?.split('@')[0] || 'Seeker' 
        });

        // 2. Fetch Today's Log
        const today = format(new Date(), 'yyyy-MM-dd');
        const { data: logData } = await supabase
          .from('daily_checklist_logs')
          .select('tasks_completed')
          .eq('user_id', user.id)
          .eq('log_date', today)
          .maybeSingle();

        if (logData && logData.tasks_completed) {
          const savedIds: number[] = logData.tasks_completed;
          setChecklist(prev => prev.map(item => ({
            ...item,
            checked: savedIds.includes(item.id)
          })));
        }
      } else {
        // Fallback for Gatekeeper/Email-only login (Virtual)
        const cachedProfile = localStorage.getItem('virtual_profile');
        setProfile(cachedProfile ? JSON.parse(cachedProfile) : {
           name: 'Devotee',
           avatar_url: null,
           current_streak: 12,
           intercessions_count: 5,
           xp: 1500
        });
        
        const today = format(new Date(), 'yyyy-MM-dd');
        const saved = localStorage.getItem(`checklist_${today}`);
        if (saved) {
           const savedIds = JSON.parse(saved);
           setChecklist(prev => prev.map(item => ({
            ...item,
            checked: savedIds.includes(item.id)
          })));
        }
      }

    } catch (error) {
      console.error('Error fetching dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleTask = async (id: number) => {
    // 1. Optimistic Update
    let newChecklist = [...checklist];
    let isNowChecked = false;

    setChecklist(prev => {
      newChecklist = prev.map(item => {
        if (item.id === id) {
          isNowChecked = !item.checked;
          return { ...item, checked: !item.checked };
        }
        return item;
      });
      return newChecklist;
    });

    // Calculate Completion
    const completedTasks = newChecklist.filter(i => i.checked);
    const progress = completedTasks.length;
    const isFullCompletion = progress === newChecklist.length;

    if (isFullCompletion && isNowChecked) {
      handleCompletion();
    } else if (isNowChecked) {
      // Small feedback for single task
      toast.success(t('msg_discipline'), { 
          duration: 1500,
          style: { border: '1px solid #e5e7eb', background: 'rgba(255,255,255,0.9)' }
      });
    }

    // 2. Database Update
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const completedIds = completedTasks.map(t => t.id);
      const today = format(new Date(), 'yyyy-MM-dd');

      if (user) {
        // Real DB Save
        const { error } = await supabase
          .from('daily_checklist_logs')
          .upsert({
            user_id: user.id,
            log_date: today,
            tasks_completed: completedIds
          }, { onConflict: 'user_id, log_date' });
        if (error) throw error;
      } else {
        // Virtual Mode Save
        localStorage.setItem(`checklist_${today}`, JSON.stringify(completedIds));
      }

    } catch (error) {
       console.error("Failed to save progress", error);
       toast.error("Could not save progress to the cloud.");
    }
  };

  const handleCompletion = () => {
    triggerDivineCelebration();
    playAngelicChord();
    toast.success(t('msg_offering_accepted'), {
      description: t('msg_offering_desc'),
      icon: <ShieldCheck className="w-5 h-5 text-angel-gold" />,
      style: {
        background: 'rgba(255, 255, 255, 0.95)',
        backdropFilter: 'blur(10px)',
        border: '1px solid #D4AF37',
        color: '#1A1A1A',
        fontFamily: 'Playfair Display',
        fontSize: '1.1rem'
      }
    });
  };

  const progress = checklist.filter(i => i.checked).length;
  const progressPercentage = (progress / checklist.length) * 100;
  const streak = profile?.current_streak || 0;
  
  // Calculate Rank
  const { rank } = getRank(profile?.intercessions_count || 0);

  if (loading) return (
    <div className="min-h-[50vh] flex items-center justify-center">
      <div className="animate-pulse flex flex-col items-center gap-4">
        <div className="h-16 w-16 rounded-full bg-angel-gold/20 flex items-center justify-center">
           <Flame className="w-8 h-8 text-angel-gold opacity-50" />
        </div>
        <div className="text-angel-gold/60 font-serif tracking-widest text-sm uppercase">{t('dash_loading')}</div>
      </div>
    </div>
  );

  return (
    <div className="pb-24 md:pb-12 max-w-7xl mx-auto">
      <Toaster position="top-center" />
      
      {/* HEADER & STREAK WIDGET */}
      <header className="px-6 pt-8 md:pt-10 flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-full border-2 border-white shadow-premium bg-gray-200 overflow-hidden flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-300 relative group cursor-pointer transition-transform hover:scale-105">
             <div className="absolute inset-0 bg-angel-gold/0 group-hover:bg-angel-gold/10 transition-colors duration-300"></div>
             {profile?.avatar_url ? (
               <img src={profile.avatar_url} alt="User" className="w-full h-full object-cover" />
             ) : (
               <span className="font-serif font-bold text-gray-500 text-xl">
                 {(profile?.name || 'A').charAt(0).toUpperCase()}
               </span>
             )}
          </div>
          <div>
            <p className="text-[10px] text-angel-gold uppercase font-bold tracking-[0.2em] mb-1 opacity-0 animate-in fade-in duration-700">{t('welcome')}</p>
            <div className="flex items-center gap-2">
                <p className="font-serif font-bold text-2xl text-gray-900 tracking-tight">{profile?.name || 'Seeker'}</p>
                {/* MEDAL BADGE - Added here for visibility */}
                <div className={`w-5 h-5 rounded-full ${rank.bg} flex items-center justify-center ${rank.shadow || ''}`} title={t(rank.titleKey)}>
                    <rank.icon className={`w-3 h-3 ${rank.color}`} />
                </div>
            </div>
            {/* Rank Text */}
             <p className={`text-[10px] font-bold uppercase tracking-wide ${rank.color} mt-0.5`}>
                 {t(rank.titleKey)}
             </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="glass-card px-5 py-2 rounded-full flex items-center gap-3 border-angel-gold/20 shadow-sm transition-all hover:shadow-gold-glow/20">
            <div className="relative">
                <Flame 
                  className={`w-5 h-5 ${streak > 0 ? 'text-orange-500 fill-orange-500 animate-pulse' : 'text-gray-300'}`} 
                />
                {streak > 5 && (
                    <div className="absolute inset-0 bg-orange-400 blur-lg opacity-40 animate-pulse"></div>
                )}
            </div>
            <div className="flex flex-col leading-none">
              <span className="font-sans font-bold text-gray-900 text-sm">{streak}</span>
              <span className="text-[9px] uppercase text-gray-400 font-bold tracking-wider">{t('prof_streak')}</span>
            </div>
          </div>
        </div>
      </header>

      {/* HERO SECTION (Daily Wisdom) */}
      <section className="px-4 md:px-8 mb-8">
        <div className="relative h-72 rounded-3xl overflow-hidden shadow-2xl group border border-white/50">
          <div className="absolute inset-0">
            {/* UPDATED: More reliable Unsplash ID */}
            <img 
              src="https://images.unsplash.com/photo-1499209974431-9dddcece7f88?q=80&w=2000&auto=format&fit=crop" 
              alt="Sky" 
              className="w-full h-full object-cover transition-transform duration-[2s] group-hover:scale-105 saturate-[0.8]"
            />
            <div className="absolute inset-0 bg-slate-900/30 backdrop-blur-[1px]"></div>
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
          </div>
          
          <div className="relative h-full flex flex-col items-center justify-center text-center p-8 z-10 max-w-4xl mx-auto">
             <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1 }}
             >
                <h2 className="font-serif text-3xl md:text-5xl text-white italic leading-tight mb-6 drop-shadow-lg">
                  "{t(`verse_${verseIndex}_text`)}"
                </h2>
                <span className="inline-block px-5 py-1.5 border border-white/30 rounded-full text-white/90 font-bold text-xs tracking-[0.2em] uppercase bg-black/20 backdrop-blur-md">
                  {t(`verse_${verseIndex}_ref`)}
                </span>
             </motion.div>
          </div>
        </div>
      </section>

      {/* SHORTCUTS GRID */}
      <section className="px-4 md:px-8 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          
           {/* NEW FEATURE: EMPATIA (SIMPATIA) */}
          <motion.div 
            onClick={() => onNavigate('empatia')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="relative rounded-2xl overflow-hidden cursor-pointer shadow-xl group border border-rose-100 bg-white lg:col-span-1"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-rose-500/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
            <div className="p-6">
               <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-rose-400 to-rose-600 flex items-center justify-center shadow-md group-hover:scale-110 transition-transform duration-500">
                     <Leaf className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex items-center gap-1 text-[10px] uppercase font-bold text-rose-500 bg-rose-50 px-2 py-1 rounded-full border border-rose-100">
                     {t('tag_simpatia')}
                  </div>
               </div>
               <h3 className="font-serif text-xl font-bold text-gray-900 mb-1">{t('dash_empatia_title')}</h3>
               <p className="text-gray-500 text-sm font-sans mb-4">{t('dash_empatia_desc')}</p>
               <div className="flex items-center text-xs font-bold uppercase tracking-widest text-rose-500 group-hover:underline">
                  {t('dash_empatia_btn')} <ArrowRight className="w-3 h-3 ml-1" />
               </div>
            </div>
          </motion.div>

          {/* CARD 1: COURSES */}
          <motion.div 
            onClick={() => onNavigate('courses')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="relative rounded-2xl overflow-hidden cursor-pointer shadow-xl group border border-angel-gold/10 bg-white"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-angel-gold/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
            <div className="p-6">
               <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 rounded-full bg-angel-gold flex items-center justify-center shadow-gold-glow group-hover:scale-110 transition-transform duration-500">
                     <PlayCircle className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex items-center gap-1 text-[10px] uppercase font-bold text-angel-gold bg-angel-gold/5 px-2 py-1 rounded-full">
                     {t('tag_access')}
                  </div>
               </div>
               <h3 className="font-serif text-xl font-bold text-gray-900 mb-1">{t('dash_courses_title')}</h3>
               <p className="text-gray-500 text-sm font-sans mb-4">{t('dash_courses_desc')}</p>
               <div className="flex items-center text-xs font-bold uppercase tracking-widest text-angel-gold group-hover:underline">
                  {t('dash_courses_btn')} <ArrowRight className="w-3 h-3 ml-1" />
               </div>
            </div>
          </motion.div>

          {/* CARD 2: CONFESSIONAL */}
          <motion.div 
            onClick={() => onNavigate('confessional')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="relative rounded-2xl overflow-hidden cursor-pointer shadow-xl group border border-slate-200 bg-gradient-to-br from-slate-900 to-slate-800 text-white lg:col-span-1 md:col-span-2 lg:col-auto"
          >
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-yellow-500/10 rounded-full blur-3xl -ml-10 -mb-10"></div>
            <div className="p-6">
               <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center border border-white/20 group-hover:scale-110 transition-transform duration-500">
                     <Key className="w-6 h-6 text-yellow-100" />
                  </div>
                  <div className="flex items-center gap-1 text-[10px] uppercase font-bold text-yellow-200 bg-yellow-500/10 px-2 py-1 rounded-full border border-yellow-500/20">
                     {t('tag_private')}
                  </div>
               </div>
               <h3 className="font-serif text-xl font-bold text-white mb-1">{t('dash_confess_card_title')}</h3>
               <p className="text-slate-400 text-sm font-sans mb-4">{t('dash_confess_card_desc')}</p>
               <div className="flex items-center text-xs font-bold uppercase tracking-widest text-yellow-200 group-hover:text-white transition-colors">
                  {t('dash_confess_card_btn')} <ArrowRight className="w-3 h-3 ml-1" />
               </div>
            </div>
          </motion.div>

        </div>
      </section>

      {/* CORE FEATURE: THE DAILY RITUAL (OFFERING/COMPROMISSO) */}
      <section className="px-4 md:px-8">
        <div className="glass-card rounded-3xl p-8 relative overflow-hidden border border-white shadow-xl">
          {/* Decorative background element */}
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-angel-gold/5 rounded-full blur-3xl pointer-events-none"></div>

          <div className="flex items-end justify-between mb-8 relative z-10">
            <div>
               <h3 className="font-serif text-3xl font-bold text-gray-900 mb-1">{t('dash_header')}</h3>
               <p className="text-gray-500 text-sm font-sans tracking-wide">{t('dash_sub')}</p>
            </div>
            <div className="text-right">
              <span className="font-serif text-4xl font-bold text-angel-gold">{progress}</span>
              <span className="text-gray-400 text-xl font-serif">/{checklist.length}</span>
            </div>
          </div>

          {/* Progress Bar (Dopamine Enhanced) */}
          <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden mb-10 shadow-inner relative">
             <div className="absolute inset-0 bg-gray-100 z-0"></div>
             <motion.div 
               className="h-full bg-gold-gradient shadow-gold-glow relative z-10"
               initial={{ width: 0 }}
               animate={{ width: `${progressPercentage}%` }}
               transition={{ duration: 0.8, ease: "circOut" }}
             >
                {/* Shimmer Effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent w-full h-full -skew-x-12 animate-shimmer" style={{ backgroundSize: '200% 100%' }}></div>
             </motion.div>
          </div>

          {/* Checklist with Descriptions */}
          <div className="space-y-4 relative z-10">
            {checklist.map((item) => (
              <motion.div 
                key={item.id}
                whileTap={{ scale: 0.99 }}
                layout
                className="relative"
              >
                <div className="flex items-center gap-2">
                    <div className="flex-1 group">
                        <Checkbox 
                          label={t(item.labelKey)} // TRANSLATION HERE
                          checked={item.checked}
                          onChange={() => toggleTask(item.id)}
                        />
                        {/* DESCRIPTION BELOW THE LABEL */}
                        <div className="pl-16 pr-4 -mt-2 mb-2">
                            <p className={`text-xs font-sans transition-colors duration-300 ${item.checked ? 'text-gray-300 line-through' : 'text-gray-500'}`}>
                                {t(item.descKey)}
                            </p>
                        </div>
                    </div>
                    {/* INFO ICON FOR HARD TASK (ID 4) */}
                    {item.id === 4 && (
                        <button 
                            onClick={() => setShowHardTaskInfo(true)}
                            className="p-3 bg-gray-100 hover:bg-gray-200 rounded-xl text-gray-500 transition-colors self-start mt-2"
                        >
                            <Info className="w-5 h-5" />
                        </button>
                    )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* HARD TASK INFO MODAL */}
      <AnimatePresence>
        {showHardTaskInfo && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => setShowHardTaskInfo(false)}
                    className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                />
                
                <motion.div
                    initial={{ scale: 0.9, y: 20 }}
                    animate={{ scale: 1, y: 0 }}
                    exit={{ scale: 0.9, y: 20 }}
                    className="bg-white rounded-2xl p-8 max-w-md w-full relative shadow-2xl z-10 border border-angel-gold/20"
                >
                    <button onClick={() => setShowHardTaskInfo(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                        <X className="w-5 h-5" />
                    </button>

                    <div className="flex justify-center mb-6">
                        <div className="w-16 h-16 bg-gradient-to-tr from-gray-800 to-gray-600 rounded-full flex items-center justify-center shadow-lg">
                            <Sparkles className="w-8 h-8 text-white" />
                        </div>
                    </div>

                    <h3 className="text-2xl font-serif font-bold text-center text-gray-900 mb-4">{t('hard_task_title')}</h3>
                    
                    <div className="space-y-4 text-gray-600 font-sans leading-relaxed text-sm">
                        <p>{t('hard_task_desc')}</p>
                        <div className="bg-gray-50 p-4 rounded-xl border-l-4 border-angel-gold italic text-gray-700">
                            "{t('hard_task_examples')}"
                        </div>
                    </div>

                    <Button onClick={() => setShowHardTaskInfo(false)} className="mt-8 w-full shadow-gold-glow">
                        {t('hard_task_btn')}
                    </Button>
                </motion.div>
            </div>
        )}
      </AnimatePresence>

    </div>
  );
};
