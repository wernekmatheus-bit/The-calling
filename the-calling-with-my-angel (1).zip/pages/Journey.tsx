
import React, { useState, useEffect } from 'react';
import { JourneyMap } from '../components/JourneyMap';
import { useTranslation } from '../lib/i18n_context';
import { supabase } from '../lib/supabase';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Sparkles, Scroll, ArrowRight, Hourglass, Calendar, Book, Feather, Flame, Droplets, Info } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { toast } from 'sonner';
import { differenceInHours } from 'date-fns';
import { triggerDivineCelebration } from '../lib/confetti';
import { playAngelicChord } from '../lib/audio';

// Helper to safely get translated content for any day
const useNovenaContent = (day: number) => {
  const { t } = useTranslation();

  // Defines the structure of content for specific days
  const specificDays: Record<number, any> = {
    1: {
      title: t('journey_d1_title'),
      task: t('journey_d1_task'),
      prayer: t('journey_d1_prayer'),
      // Updated Image (Candle)
      image: "https://images.unsplash.com/photo-1603205335198-72e796eb00a3?q=80&w=2070&auto=format&fit=crop",
      icon: Flame
    },
    2: {
      title: t('journey_d2_title'),
      task: t('journey_d2_task'),
      prayer: t('journey_d2_prayer'),
      // Updated Image (Writing/Paper)
      image: "https://images.unsplash.com/photo-1516410339967-0c7d42426372?q=80&w=2070&auto=format&fit=crop",
      icon: Feather
    },
    3: {
      title: t('journey_d3_title'),
      task: t('journey_d3_task'),
      prayer: t('journey_d3_prayer'),
      // Updated Image (Water/Nature)
      image: "https://images.unsplash.com/photo-1548839140-29a749e1cf4d?q=80&w=1888&auto=format&fit=crop",
      icon: Droplets
    },
    4: {
      title: t('journey_d4_title'),
      task: t('journey_d4_task'),
      prayer: t('journey_d4_prayer'),
      // Updated Image (Silence/Fog)
      image: "https://images.unsplash.com/photo-1490730141103-6cac27aaab94?q=80&w=2000&auto=format&fit=crop",
      icon: Book
    }
  };

  // Fallback for days not explicitly defined yet
  if (specificDays[day]) {
    return specificDays[day];
  } else {
    return {
      title: `${t('journey_generic_title')} - ${t('journey_day')} ${day}`,
      task: t('journey_generic_task'),
      prayer: t('journey_generic_prayer'),
      // Updated Image (Scroll/Old Paper)
      image: "https://images.unsplash.com/photo-1507643179173-39db74c239d8?q=80&w=2000&auto=format&fit=crop",
      icon: Scroll
    };
  }
};

export const Journey: React.FC = () => {
  const { t } = useTranslation();
  
  // State
  const [currentLevel, setCurrentLevel] = useState(1);
  const [lastCompletedAt, setLastCompletedAt] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  
  // UX State
  const [viewedDay, setViewedDay] = useState<number>(1); // For Side Panel
  const [isMobileModalOpen, setIsMobileModalOpen] = useState(false);
  
  // Logic
  const [hoursSinceLast, setHoursSinceLast] = useState(0);
  const cooldownHours = 20; 
  const isCooldown = hoursSinceLast < cooldownHours && lastCompletedAt !== null;
  const hoursRemaining = Math.max(0, cooldownHours - hoursSinceLast);

  const activeContent = useNovenaContent(viewedDay);

  useEffect(() => {
    fetchProgress();
  }, []);

  const fetchProgress = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        let { data, error } = await supabase
          .from('journey_progress')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        if (!data) {
          const { data: newData } = await supabase
            .from('journey_progress')
            .insert({ user_id: user.id, current_day: 1 })
            .select()
            .single();
          data = newData;
        }

        setCurrentLevel(data.current_day);
        setViewedDay(data.current_day); // Default view to current active day
        setLastCompletedAt(data.last_completed_at);
        calculateCooldown(data.last_completed_at);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const calculateCooldown = (lastDateStr: string | null) => {
    if (!lastDateStr) {
      setHoursSinceLast(999);
      return;
    }
    const last = new Date(lastDateStr);
    const now = new Date();
    try {
        const diff = differenceInHours(now, last);
        setHoursSinceLast(diff);
    } catch (e) {
        setHoursSinceLast(999);
    }
  };

  const handleDayClick = (day: number) => {
    // If click future day
    if (day > currentLevel) {
      toast.error(t('journey_locked_label'), { 
          description: t('journey_locked_desc'),
          icon: <Hourglass className="w-4 h-4 text-gray-400" />
      });
      return;
    }
    
    // Set view
    setViewedDay(day);
    
    // Mobile UX: Open Modal if clicking a day
    if (window.innerWidth < 768) {
        setIsMobileModalOpen(true);
    }
  };

  const handleCompleteTask = async () => {
    if (viewedDay !== currentLevel) return;
    if (isCooldown) {
       toast(t('journey_wait_title'), { description: t('journey_wait_desc', { hours: hoursRemaining }) });
       return;
    }

    const prevLevel = currentLevel;
    const newLevel = currentLevel + 1;
    const now = new Date().toISOString();

    setCurrentLevel(newLevel);
    setLastCompletedAt(now);
    calculateCooldown(now); 
    setViewedDay(newLevel); // Auto-advance view
    setIsMobileModalOpen(false); // Close mobile modal

    triggerDivineCelebration();
    playAngelicChord();
    toast.success(t('journey_toast_fulfilled'));

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase
          .from('journey_progress')
          .update({
            current_day: newLevel,
            last_completed_at: now
          })
          .eq('user_id', user.id);
      }
    } catch (error) {
      console.error(error);
      setCurrentLevel(prevLevel); // Revert on fail
    }
  };

  return (
    <div className="h-screen bg-[#0a0a0a] overflow-hidden flex flex-col md:flex-row">
      
      {/* 1. MAP SECTION (Left / Full on Mobile) */}
      <div className="flex-1 relative h-full overflow-y-auto overflow-x-hidden">
         {/* Floating Header */}
         <div className="absolute top-0 left-0 w-full p-6 z-20 pointer-events-none">
            <h1 className="font-serif text-3xl font-bold text-white drop-shadow-md">{t('journey_title')}</h1>
            <p className="text-sm text-angel-gold uppercase tracking-[0.2em] mt-1 font-bold">{t('journey_level')} {currentLevel}</p>
         </div>

         <JourneyMap 
            currentLevel={currentLevel} 
            totalSteps={45} 
            onDayClick={handleDayClick}
            isCooldown={isCooldown}
            hoursRemaining={hoursRemaining}
         />

         {/* Mobile Bottom Instruction (Visible if Modal Closed) */}
         <div className="md:hidden fixed bottom-20 left-0 w-full px-4 pointer-events-none z-10">
            <motion.div 
               initial={{ y: 50, opacity: 0 }}
               animate={{ y: 0, opacity: 1 }}
               className="bg-black/80 backdrop-blur-md p-4 rounded-xl border border-angel-gold/30 text-center pointer-events-auto shadow-2xl"
               onClick={() => setIsMobileModalOpen(true)}
            >
               <div className="flex items-center justify-center gap-2 mb-1">
                   <Info className="w-4 h-4 text-angel-gold" />
                   <span className="text-angel-gold text-xs font-bold uppercase tracking-widest">{t('journey_task_label')}</span>
               </div>
               <p className="text-white font-serif text-lg leading-tight truncate">{activeContent.title}</p>
               <p className="text-gray-400 text-xs mt-1">{t('journey_tap_instruction')}</p>
            </motion.div>
         </div>
      </div>

      {/* 2. SIDE PANEL (Desktop Only - Sticky) */}
      <div className="hidden md:flex w-[400px] h-full bg-[#F9F7F2] border-l border-gray-900 shadow-2xl flex-col relative z-30">
         
         {/* Hero Image */}
         <div className="h-48 relative overflow-hidden bg-black">
            <img src={activeContent.image} className="w-full h-full object-cover opacity-80" alt="Day Theme" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#F9F7F2] to-transparent"></div>
            <div className="absolute bottom-4 left-6">
               <span className="bg-angel-gold text-white px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest rounded-sm">
                  {t('journey_day')} {viewedDay}
               </span>
               <h2 className="font-serif text-2xl font-bold text-gray-900 leading-tight mt-1">{activeContent.title}</h2>
            </div>
         </div>

         {/* Content Scroll */}
         <div className="flex-1 overflow-y-auto p-8">
            <div className="mb-8">
                <div className="w-10 h-10 bg-angel-gold/10 rounded-full flex items-center justify-center mb-4 text-angel-gold">
                   <activeContent.icon className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-gray-900 uppercase tracking-widest text-xs mb-3 border-b border-angel-gold/20 pb-2">{t('journey_task_label')}</h3>
                <p className="font-serif text-lg text-gray-800 leading-relaxed">
                   {activeContent.task}
                </p>
            </div>

            <div className="mb-6 bg-white p-6 rounded-xl border border-gray-100 shadow-sm italic text-gray-600 font-serif">
                "{activeContent.prayer}"
            </div>

            {/* Status Status */}
            {viewedDay < currentLevel && (
               <div className="flex items-center gap-2 text-green-600 font-bold text-sm bg-green-50 p-3 rounded-lg justify-center">
                  <Sparkles className="w-4 h-4" /> {t('journey_toast_fulfilled')}
               </div>
            )}
            
            {viewedDay > currentLevel && (
               <div className="flex items-center gap-2 text-gray-400 font-bold text-sm bg-gray-100 p-3 rounded-lg justify-center">
                  <Hourglass className="w-4 h-4" /> {t('journey_locked_label')}
               </div>
            )}
         </div>

         {/* Action Footer */}
         {viewedDay === currentLevel && (
            <div className="p-6 border-t border-gray-200 bg-white">
                {isCooldown ? (
                    <div className="text-center">
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">{t('journey_wait_title')}</p>
                        <p className="text-angel-gold font-serif">{t('journey_wait_desc', { hours: hoursRemaining })}</p>
                    </div>
                ) : (
                    <Button onClick={handleCompleteTask} className="w-full py-4 text-md shadow-gold-glow">
                        <span className="flex items-center gap-2">
                           {t('journey_btn_fulfill')} <ArrowRight className="w-4 h-4" />
                        </span>
                    </Button>
                )}
            </div>
         )}
      </div>

      {/* 3. MOBILE MODAL (Overlay) */}
      <AnimatePresence>
        {isMobileModalOpen && (
          <div className="md:hidden fixed inset-0 z-50 flex items-end justify-center sm:items-center p-0 sm:p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="relative w-full bg-[#F9F7F2] rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
            >
               {/* Mobile Modal Header Image */}
               <div className="h-40 relative bg-black shrink-0">
                  <img src={activeContent.image} className="w-full h-full object-cover opacity-70" alt="Theme" />
                  <button 
                    onClick={() => setIsMobileModalOpen(false)}
                    className="absolute top-4 right-4 bg-black/40 text-white p-2 rounded-full backdrop-blur-md"
                  >
                    <X className="w-5 h-5" />
                  </button>
                  <div className="absolute bottom-4 left-6 text-white">
                     <span className="bg-angel-gold text-black px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest rounded-sm">
                        {t('journey_day')} {viewedDay}
                     </span>
                     <h2 className="font-serif text-2xl font-bold leading-tight mt-1">{activeContent.title}</h2>
                  </div>
               </div>

               <div className="p-6 overflow-y-auto">
                    <div className="w-10 h-10 bg-angel-gold/10 rounded-full flex items-center justify-center mb-4 text-angel-gold">
                       <activeContent.icon className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-gray-900 uppercase tracking-widest text-xs mb-3 border-b border-angel-gold/20 pb-2">{t('journey_task_label')}</h3>
                    <p className="font-serif text-lg text-gray-800 leading-relaxed mb-6">
                       {activeContent.task}
                    </p>
                    <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm italic text-gray-600 font-serif text-sm">
                        "{activeContent.prayer}"
                    </div>
               </div>

               {viewedDay === currentLevel && !isCooldown && (
                  <div className="p-4 border-t border-gray-200 bg-white pb-8">
                      <Button onClick={handleCompleteTask} className="w-full py-3 shadow-gold-glow">
                        {t('journey_btn_fulfill')}
                      </Button>
                  </div>
               )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
